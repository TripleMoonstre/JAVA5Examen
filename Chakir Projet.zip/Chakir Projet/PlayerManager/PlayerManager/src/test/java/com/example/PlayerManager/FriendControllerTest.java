package com.example.PlayerManager;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;

import com.example.PlayerManager.Controllers.FriendController;
import com.example.PlayerManager.DTO.FriendDTO;
import com.example.PlayerManager.Services.IFriendService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.List;

@WebMvcTest(FriendController.class)
public class FriendControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IFriendService friendService;

    @Test
    public void testAddFriend() throws Exception {
        FriendDTO friendDTO = new FriendDTO(1L, 1L, 2L);
        when(friendService.addFriend(any(FriendDTO.class))).thenReturn(friendDTO);

        String requestBody = "{\"idPlayer\":1, \"idFriend\":2}";

        mockMvc.perform(post("/api/friends")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idPlayer").value(1L))
                .andExpect(jsonPath("$.idFriend").value(2L));
    }

    @Test
    public void testGetAllFriends() throws Exception {
        List<FriendDTO> friends = Arrays.asList(
                new FriendDTO(1L, 1L, 2L),
                new FriendDTO(2L, 1L, 3L)
        );

        when(friendService.getAllFriends()).thenReturn(friends);

        mockMvc.perform(get("/api/friends"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].idPlayer").value(1L))
                .andExpect(jsonPath("$[0].idFriend").value(2L))
                .andExpect(jsonPath("$[1].idPlayer").value(1L))
                .andExpect(jsonPath("$[1].idFriend").value(3L));
    }

    @Test
    public void testDeleteFriend() throws Exception {
        doNothing().when(friendService).deleteFriendByPlayers(1L, 2L);

        mockMvc.perform(delete("/api/friends/delete/1/2"))
                .andExpect(status().isOk());

        verify(friendService, times(1)).deleteFriendByPlayers(1L, 2L);
    }
}