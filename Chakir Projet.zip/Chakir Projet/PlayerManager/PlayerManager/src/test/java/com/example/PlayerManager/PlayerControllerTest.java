package com.example.PlayerManager;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;

import com.example.PlayerManager.Controllers.PlayerController;
import com.example.PlayerManager.DTO.PlayerDTO;
import com.example.PlayerManager.Services.IPlayerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.List;

@WebMvcTest(PlayerController.class)
public class PlayerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IPlayerService playerService;

    @Test
    public void testCreatePlayer() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(1L);
        playerDTO.setName("Player One");
        playerDTO.setSurname("Surname One");
        playerDTO.setEmail("playerone@example.com");
        playerDTO.setLevel(5);
        playerDTO.setTotalPoint(100);

        when(playerService.createPlayer(any(PlayerDTO.class))).thenReturn(playerDTO);

        String requestBody = "{" +
                "\"id\":1, " +
                "\"name\":\"Player One\", " +
                "\"surname\":\"Surname One\", " +
                "\"email\":\"playerone@example.com\", " +
                "\"level\":5, " +
                "\"totalPoint\":100" +
                "}";

        mockMvc.perform(post("/api/players")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("Player One"))
                .andExpect(jsonPath("$.surname").value("Surname One"))
                .andExpect(jsonPath("$.email").value("playerone@example.com"))
                .andExpect(jsonPath("$.level").value(5))
                .andExpect(jsonPath("$.totalPoint").value(100));
    }

    @Test
    public void testGetPlayerById() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(1L);
        playerDTO.setName("Player One");
        playerDTO.setSurname("Surname One");
        playerDTO.setEmail("playerone@example.com");
        playerDTO.setLevel(5);
        playerDTO.setTotalPoint(100);

        when(playerService.getPlayerById(1L)).thenReturn(playerDTO);

        mockMvc.perform(get("/api/players/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("Player One"))
                .andExpect(jsonPath("$.surname").value("Surname One"))
                .andExpect(jsonPath("$.email").value("playerone@example.com"))
                .andExpect(jsonPath("$.level").value(5))
                .andExpect(jsonPath("$.totalPoint").value(100));
    }

    @Test
    public void testGetAllPlayers() throws Exception {
        List<PlayerDTO> players = Arrays.asList(
                new PlayerDTO(1L, "Player One", "Surname One", "playerone@example.com", 5, 100),
                new PlayerDTO(2L, "Player Two", "Surname Two", "playertwo@example.com", 10, 200)
        );

        when(playerService.getAllPlayers()).thenReturn(players);

        mockMvc.perform(get("/api/players"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].name").value("Player One"))
                .andExpect(jsonPath("$[0].surname").value("Surname One"))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].name").value("Player Two"))
                .andExpect(jsonPath("$[1].surname").value("Surname Two"));
    }

    @Test
    public void testUpdatePlayer() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(1L);
        playerDTO.setName("Updated Player");
        playerDTO.setSurname("Updated Surname");

        when(playerService.updatePlayer(eq(1L), any(PlayerDTO.class))).thenReturn(playerDTO);

        String requestBody = "{" +
                "\"name\":\"Updated Player\", " +
                "\"surname\":\"Updated Surname\"" +
                "}";

        mockMvc.perform(put("/api/players/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("Updated Player"))
                .andExpect(jsonPath("$.surname").value("Updated Surname"));
    }

    @Test
    public void testDeletePlayer() throws Exception {
        doNothing().when(playerService).deletePlayerById(1L);

        mockMvc.perform(delete("/api/players/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void testCheckPlayerExistence() throws Exception {
        when(playerService.checkPlayerExistence(1L)).thenReturn(true);

        mockMvc.perform(get("/api/players/1/exist"))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    public void testUpdatePlayerStats() throws Exception {
        doNothing().when(playerService).updatePlayerStats(1L, 10);

        String requestBody = "10";

        mockMvc.perform(put("/api/players/1/updateScore")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk());
    }
}
