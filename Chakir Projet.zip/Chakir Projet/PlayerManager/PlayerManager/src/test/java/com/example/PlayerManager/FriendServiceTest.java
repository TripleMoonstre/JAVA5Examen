package com.example.PlayerManager;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.PlayerManager.DTO.FriendDTO;
import com.example.PlayerManager.Entities.Friend;
import com.example.PlayerManager.Entities.Player;
import com.example.PlayerManager.DAO.IFriendDAO;
import com.example.PlayerManager.DAO.IPlayerDAO;
import com.example.PlayerManager.Services.Implem.FriendService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class FriendServiceTest {

    @Mock
    private IFriendDAO friendDAO;

    @Mock
    private IPlayerDAO playerDAO;

    @InjectMocks
    private FriendService friendService;

    @Test
    public void testAddFriend() {
        Player player1 = new Player("Player1", "Surname1", "player1@example.com", 5, 100);
        Player player2 = new Player("Player2", "Surname2", "player2@example.com", 3, 50);
        player1.setId(1L);
        player2.setId(2L);

        Friend friend1 = new Friend(1L, 2L);
        Friend friend2 = new Friend(2L, 1L);

        when(playerDAO.findById(1L)).thenReturn(player1);
        when(playerDAO.findById(2L)).thenReturn(player2);
        when(friendDAO.save(any(Friend.class))).thenReturn(friend1).thenReturn(friend2);

        FriendDTO friendDTO = new FriendDTO(0L, 1L, 2L);
        FriendDTO result = friendService.addFriend(friendDTO);

        assertNotNull(result);
        assertEquals(1L, result.getIdPlayer());
        assertEquals(2L, result.getIdFriend());
        verify(friendDAO, times(2)).save(any(Friend.class));
    }

    @Test
    public void testGetAllFriends() {
        Friend friend1 = new Friend(1L, 2L);
        Friend friend2 = new Friend(2L, 1L);

        when(friendDAO.findAll()).thenReturn(Arrays.asList(friend1, friend2));

        List<FriendDTO> result = friendService.getAllFriends();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getIdPlayer());
        assertEquals(2L, result.get(0).getIdFriend());
        verify(friendDAO, times(1)).findAll();
    }

}
