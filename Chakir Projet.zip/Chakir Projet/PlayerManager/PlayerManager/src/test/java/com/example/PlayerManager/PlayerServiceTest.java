package com.example.PlayerManager;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.PlayerManager.DTO.PlayerDTO;
import com.example.PlayerManager.Entities.Friend;
import com.example.PlayerManager.Entities.Player;
import com.example.PlayerManager.DAO.IPlayerDAO;
import com.example.PlayerManager.DAO.IFriendDAO;
import com.example.PlayerManager.Services.Implem.FriendService;
import com.example.PlayerManager.Services.Implem.PlayerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

@ExtendWith(MockitoExtension.class)
public class PlayerServiceTest {

    @Mock
    private IPlayerDAO playerDAO = mock(IPlayerDAO.class);

    @Mock
    private IFriendDAO friendDAO = mock(IFriendDAO.class);

    @Mock
    private FriendService friendService = mock(FriendService.class);

    @InjectMocks
    private PlayerService playerService = new PlayerService();

    @Test
    public void testCreatePlayer() {
        Player player = new Player("Player One", "Surname One", "playerone@example.com", 5, 100);
        when(playerDAO.save(any(Player.class))).thenReturn(player);

        PlayerDTO playerDTO = new PlayerDTO(0L, "Player One", "Surname One", "playerone@example.com", 5, 100);

        PlayerDTO result = playerService.createPlayer(playerDTO);

        assertNotNull(result);
        assertEquals("Player One", result.getName());
        assertEquals("Surname One", result.getSurname());
        assertEquals("playerone@example.com", result.getEmail());
        assertEquals(5, result.getLevel());
        assertEquals(100, result.getTotalPoint());
        verify(playerDAO, times(1)).save(any(Player.class));
    }

    @Test
    public void testGetPlayerById() {
        Player player = new Player("Player One", "Surname One", "playerone@example.com", 5, 100);
        player.setId(1L);

        Friend friend = new Friend(1L, 2L);
        Player friendPlayer = new Player("Friend One", "Friend Surname", "friend@example.com", 3, 50);
        friendPlayer.setId(2L);

        when(playerDAO.findById(1L)).thenReturn(player);
        when(friendDAO.findAll()).thenReturn(List.of(friend));
        when(playerDAO.findById(2L)).thenReturn(friendPlayer);

        PlayerDTO result = playerService.getPlayerById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(1, result.getFriends().size());
        assertEquals("Friend One", result.getFriends().get(0).getName());
        verify(playerDAO, times(1)).findById(1L);
        verify(friendDAO, times(1)).findAll();
    }

    @Test
    public void testGetAllPlayers() {
        Player player1 = new Player("Player One", "Surname One", "playerone@example.com", 5, 100);
        player1.setId(1L);
        Player player2 = new Player("Player Two", "Surname Two", "playertwo@example.com", 10, 200);
        player2.setId(2L);

        Friend friend = new Friend(1L, 2L);

        when(playerDAO.findAll()).thenReturn(List.of(player1, player2));
        when(friendDAO.findAll()).thenReturn(List.of(friend));
        when(playerDAO.findById(2L)).thenReturn(player2);

        List<PlayerDTO> result = playerService.getAllPlayers();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getFriends().size());
        assertEquals("Player Two", result.get(0).getFriends().get(0).getName());
        verify(playerDAO, times(1)).findAll();
        verify(friendDAO, times(1)).findAll();
    }

    @Test
    public void testUpdatePlayer() {
        Player existingPlayer = new Player("Old Name", "Old Surname", "old@example.com", 1, 50);
        existingPlayer.setId(1L);

        Player updatedPlayer = new Player("Updated Name", "Updated Surname", "updated@example.com", 5, 100);
        updatedPlayer.setId(1L);

        when(playerDAO.findById(1L)).thenReturn(existingPlayer);
        when(playerDAO.save(any(Player.class))).thenReturn(updatedPlayer);

        PlayerDTO playerDTO = new PlayerDTO(1L, "Updated Name", "Updated Surname", "updated@example.com", 5, 100);

        PlayerDTO result = playerService.updatePlayer(1L, playerDTO);

        assertNotNull(result);
        assertEquals("Updated Name", result.getName());
        assertEquals("Updated Surname", result.getSurname());
        assertEquals("updated@example.com", result.getEmail());
        assertEquals(5, result.getLevel());
        assertEquals(100, result.getTotalPoint());
        verify(playerDAO, times(1)).findById(1L);
        verify(playerDAO, times(1)).save(any(Player.class));
    }

    @Test
    public void testDeletePlayerById() {
        doNothing().when(friendService).deleteAllFriends(1L);
        doNothing().when(playerDAO).deleteById(1L);

        playerService.deletePlayerById(1L);

        verify(friendService, times(1)).deleteAllFriends(1L);
        verify(playerDAO, times(1)).deleteById(1L);
    }

    @Test
    public void testCheckPlayerExistence() {
        Player player = new Player("Player One", "Surname One", "playerone@example.com", 5, 100);
        player.setId(1L);

        when(playerDAO.findById(1L)).thenReturn(player);

        boolean exists = playerService.checkPlayerExistence(1L);

        assertTrue(exists);
        verify(playerDAO, times(1)).findById(1L);
    }

    @Test
    public void testUpdatePlayerStats() {
        Player player = new Player("Player One", "Surname One", "playerone@example.com", 5, 100);
        player.setId(1L);

        when(playerDAO.findById(1L)).thenReturn(player);

        playerService.updatePlayerStats(1L, 50);

        assertEquals(150, player.getTotalPoint());
        verify(playerDAO, times(1)).findById(1L);
        verify(playerDAO, times(1)).save(any(Player.class));
    }
}
