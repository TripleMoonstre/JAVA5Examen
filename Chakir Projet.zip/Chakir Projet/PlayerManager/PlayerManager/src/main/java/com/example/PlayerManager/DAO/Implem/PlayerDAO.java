package com.example.PlayerManager.DAO.Implem;

import com.example.PlayerManager.DAO.IPlayerDAO;
import com.example.PlayerManager.Entities.Player;
import com.example.PlayerManager.Repositories.IPlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Component // Indique que cette classe est un composant Spring géré par le conteneur.
public class PlayerDAO implements IPlayerDAO {

    @Autowired // Injecte automatiquement le repository IPlayerRepository.
    private IPlayerRepository playerRepository;

    @Override
    public Player save(Player player) {
        return playerRepository.save(player); // Sauvegarde ou met à jour un joueur.
    }

    @Override
    public Player findById(long id) {
        return playerRepository.findById(id) // Recherche un joueur par ID.
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, // Renvoie une exception HTTP 404 si le joueur n'est pas trouvé.
                        "Player not found with id: " + id
                ));
    }

    @Override
    public List<Player> findAll() {
        return playerRepository.findAll(); // Retourne tous les joueurs.
    }

    @Override
    public void deleteById(long id) {
        playerRepository.deleteById(id); // Supprime un joueur par ID.
    }
}
