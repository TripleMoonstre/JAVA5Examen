package com.example.PlayerManager.DAO;

import com.example.PlayerManager.Entities.Friend;

import java.util.List;

public interface IFriendDAO {
    Friend save(Friend friend);
    List<Friend> findAll();
    void deleteById(long id);
}