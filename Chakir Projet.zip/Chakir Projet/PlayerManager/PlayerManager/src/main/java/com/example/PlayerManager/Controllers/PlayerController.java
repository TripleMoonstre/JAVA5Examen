package com.example.PlayerManager.Controllers;

import com.example.PlayerManager.DTO.PlayerDTO;
import com.example.PlayerManager.Services.IPlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Indique que cette classe est un contrôleur REST.
@RequestMapping("/api/players") // Mappe les requêtes HTTP vers "/api/players".
public class PlayerController {

    @Autowired // Injecte automatiquement le service IPlayerService.
    private IPlayerService playerService;

    @PostMapping // Gère les requêtes POST pour créer un joueur.
    public PlayerDTO createPlayer(@RequestBody PlayerDTO playerDTO) {
        return playerService.createPlayer(playerDTO); // Appelle le service pour créer un nouveau joueur.
    }

    @GetMapping("/{id}") // Récupère un joueur par son ID.
    public PlayerDTO getPlayerById(@PathVariable long id) {
        return playerService.getPlayerById(id); // Appelle le service pour obtenir un joueur spécifique.
    }

    @GetMapping // Récupère la liste de tous les joueurs.
    public List<PlayerDTO> getAllPlayers() {
        return playerService.getAllPlayers(); // Appelle le service pour obtenir tous les joueurs.
    }

    @PutMapping("/{id}") // Met à jour un joueur par son ID.
    public PlayerDTO updatePlayer(@PathVariable long id, @RequestBody PlayerDTO playerDTO) {
        return playerService.updatePlayer(id, playerDTO); // Appelle le service pour mettre à jour un joueur.
    }

    @DeleteMapping("/{id}") // Supprime un joueur par son ID.
    public void deletePlayer(@PathVariable long id) {
        playerService.deletePlayerById(id); // Appelle le service pour supprimer un joueur.
    }

    // Vérifie si un joueur existe.
    @GetMapping("/{id}/exist") // Endpoint spécifique pour vérifier l'existence d'un joueur.
    public boolean checkPlayerExistence(@PathVariable long id) {
        return playerService.checkPlayerExistence(id); // Appelle le service pour vérifier l'existence.
    }

    // Met à jour les statistiques d'un joueur, ici le score.
    @PutMapping("/{id}/updateScore") // Endpoint spécifique pour mettre à jour le score d'un joueur.
    public void updatePlayerStats(@PathVariable long id, @RequestBody int scoreToAdd) {
        playerService.updatePlayerStats(id, scoreToAdd); // Appelle le service pour ajouter au score du joueur.
    }
}
