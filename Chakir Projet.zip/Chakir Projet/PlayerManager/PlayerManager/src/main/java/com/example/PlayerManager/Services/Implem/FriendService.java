package com.example.PlayerManager.Services.Implem;

import com.example.PlayerManager.DAO.IFriendDAO;
import com.example.PlayerManager.DAO.IPlayerDAO;
import com.example.PlayerManager.DTO.FriendDTO;
import com.example.PlayerManager.Entities.Friend;
import com.example.PlayerManager.Entities.Player;
import com.example.PlayerManager.Services.IFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service // Indique que cette classe est un service Spring géré par le conteneur.
public class FriendService implements IFriendService {

    @Autowired // Injecte automatiquement le DAO pour les amitiés.
    private IFriendDAO friendDAO;

    @Autowired // Injecte automatiquement le DAO pour les joueurs.
    private IPlayerDAO playerDAO;

    @Override
    public FriendDTO addFriend(FriendDTO friendDTO) {
        Player player1 = playerDAO.findById(friendDTO.getIdPlayer()); // Récupère le premier joueur.
        Player player2 = playerDAO.findById(friendDTO.getIdFriend()); // Récupère le second joueur.

        // Création de deux relations d'amitié bidirectionnelles.
        Friend friend1 = new Friend(player1.getId(), player2.getId());
        Friend friend2 = new Friend(player2.getId(), player1.getId());

        // Sauvegarde des relations dans le DAO.
        friendDAO.save(friend1);
        friendDAO.save(friend2);

        return new FriendDTO(friend1.getId(), friend1.getIdPlayer(), friend1.getIdFriend()); // Retourne un DTO basé sur friend1.
    }

    @Override
    public List<FriendDTO> getAllFriends() {
        return friendDAO.findAll().stream() // Récupère toutes les amitiés.
                .map(friend -> new FriendDTO(friend.getId(), friend.getIdPlayer(), friend.getIdFriend())) // Transforme chaque entité en DTO.
                .collect(Collectors.toList());
    }

    @Override
    public void deleteFriendByPlayers(long idPlayer1, long idPlayer2) {
        // Recherche des relations d'amitié bidirectionnelles.
        Friend friend1 = friendDAO.findAll().stream()
                .filter(friend -> (friend.getIdPlayer() == idPlayer1 && friend.getIdFriend() == idPlayer2))
                .findFirst().orElse(null);

        Friend friend2 = friendDAO.findAll().stream()
                .filter(friend -> (friend.getIdPlayer() == idPlayer2 && friend.getIdFriend() == idPlayer1))
                .findFirst().orElse(null);

        // Suppression des relations si elles existent.
        if (friend1 != null) {
            friendDAO.deleteById(friend1.getId());
        }
        if (friend2 != null) {
            friendDAO.deleteById(friend2.getId());
        }
    }

    @Override
    public void deleteAllFriends(long idPlayer) {
        // Récupération des relations où le joueur est idPlayer1.
        List<Friend> friendsAsPlayer1 = friendDAO.findAll().stream()
                .filter(friend -> friend.getIdPlayer() == idPlayer)
                .collect(Collectors.toList());

        // Récupération des relations où le joueur est idPlayer2.
        List<Friend> friendsAsPlayer2 = friendDAO.findAll().stream()
                .filter(friend -> friend.getIdFriend() == idPlayer)
                .collect(Collectors.toList());

        // Suppression de toutes les relations récupérées.
        friendsAsPlayer1.forEach(friend -> friendDAO.deleteById(friend.getId()));
        friendsAsPlayer2.forEach(friend -> friendDAO.deleteById(friend.getId()));
    }
}
