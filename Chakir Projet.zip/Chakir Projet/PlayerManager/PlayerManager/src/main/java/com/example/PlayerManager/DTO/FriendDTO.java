package com.example.PlayerManager.DTO;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FriendDTO {
    private long id;
    private long idPlayer;
    private long idFriend;
}

