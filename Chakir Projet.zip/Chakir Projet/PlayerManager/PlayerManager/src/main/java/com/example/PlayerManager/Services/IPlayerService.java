package com.example.PlayerManager.Services;

import com.example.PlayerManager.DTO.PlayerDTO;

import java.util.List;

public interface IPlayerService {
    PlayerDTO createPlayer(PlayerDTO playerDTO);
    PlayerDTO getPlayerById(long id);
    List<PlayerDTO> getAllPlayers();
    PlayerDTO updatePlayer(long id, PlayerDTO playerDTO);
    void deletePlayerById(long id);
    // Nouvelle méthode pour vérifier si un joueur existe
    boolean checkPlayerExistence(long id);
    // Méthode pour mettre à jour les statistiques du joueur

    void updatePlayerStats(long playerId, int scoreToAdd);
}
