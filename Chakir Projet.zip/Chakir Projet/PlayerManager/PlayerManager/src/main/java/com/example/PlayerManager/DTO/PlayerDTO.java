package com.example.PlayerManager.DTO;

import lombok.*;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PlayerDTO {

    private long id;
    private String name;
    private String surname;
    private String email;
    private int level;
    private int totalPoint;
    private List<PlayerFriendDTO> friends;


    public PlayerDTO(long id, String name, String surname, String email, int level, int totalPoint) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.level = level;
        this.totalPoint = totalPoint;
    }
}

