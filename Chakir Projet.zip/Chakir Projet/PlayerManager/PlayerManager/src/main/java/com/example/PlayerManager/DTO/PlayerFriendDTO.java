package com.example.PlayerManager.DTO;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PlayerFriendDTO {
    private long id;
    private String name; // Pseudo
}
