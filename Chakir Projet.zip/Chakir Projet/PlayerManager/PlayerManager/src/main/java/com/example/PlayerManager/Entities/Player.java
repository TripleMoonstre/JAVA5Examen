package com.example.PlayerManager.Entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "players")
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "players_seq")
    @SequenceGenerator(name = "players_seq", sequenceName = "players_seq", allocationSize = 1)
    private long id;

    @Column(name = "name")
    private String name;

    @Column(name = "surname")
    private String surname;

    @Column(name = "email")
    private String email;

    @Column(name = "level")
    private int level;

    @Column(name = "total_point")
    private int totalPoint;

    public Player(String name, String surname, String email, int level, int totalPoint) {
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.level = level;
        this.totalPoint = totalPoint;
    }
}
