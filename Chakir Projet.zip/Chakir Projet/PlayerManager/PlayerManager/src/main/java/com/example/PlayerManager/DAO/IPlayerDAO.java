package com.example.PlayerManager.DAO;

import com.example.PlayerManager.Entities.Player;

import java.util.List;

public interface IPlayerDAO {
    Player save(Player player);
    Player findById(long id); // Retour direct d'un Player
    List<Player> findAll();
    void deleteById(long id);
}