package com.example.PlayerManager.Services;

import com.example.PlayerManager.DTO.FriendDTO;

import java.util.List;

public interface IFriendService {

    // Ajouter une amitié entre deux joueurs
    FriendDTO addFriend(FriendDTO friendDTO);

    // Obtenir la liste de toutes les amitiés
    List<FriendDTO> getAllFriends();

    // Supprimer l'amitié entre deux joueurs (dans les deux sens)
    void deleteFriendByPlayers(long idPlayer1, long idPlayer2);

    void deleteAllFriends(long idPlayer);
}
