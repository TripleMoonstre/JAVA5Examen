package com.example.PlayerManager.Services.Implem;

import com.example.PlayerManager.DAO.IFriendDAO;
import com.example.PlayerManager.DAO.IPlayerDAO;
import com.example.PlayerManager.DTO.PlayerDTO;
import com.example.PlayerManager.DTO.PlayerFriendDTO;
import com.example.PlayerManager.Entities.Friend;
import com.example.PlayerManager.Entities.Player;
import com.example.PlayerManager.Services.IPlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service // Indique que cette classe est un service Spring géré par le conteneur.
public class PlayerService implements IPlayerService {

    @Autowired // Injecte automatiquement le DAO pour les joueurs.
    private IPlayerDAO playerDAO;

    @Autowired // Injecte automatiquement le DAO pour les amis.
    private IFriendDAO friendDAO;

    @Autowired // Injecte le service pour gérer les amitiés.
    private FriendService friendService;

    @Override
    public PlayerDTO createPlayer(PlayerDTO playerDTO) {
        // Conversion du DTO en entité et sauvegarde du joueur.
        Player player = new Player(playerDTO.getName(), playerDTO.getSurname(), playerDTO.getEmail(),
                playerDTO.getLevel(), playerDTO.getTotalPoint());
        Player savedPlayer = playerDAO.save(player);
        return convertToDTO(savedPlayer); // Retourne un DTO du joueur sauvegardé.
    }

    @Override
    public PlayerDTO getPlayerById(long id) {
        Player player = playerDAO.findById(id); // Recherche le joueur par ID.
        if (player == null) return null;

        PlayerDTO playerDTO = convertToDTO(player); // Convertit l'entité en DTO.
        List<PlayerFriendDTO> friendDetails = new ArrayList<>();

        // Ajout des détails des amis pour le joueur.
        for (Friend friend : friendDAO.findAll()) {
            if (friend.getIdPlayer() == id) {
                Player friendPlayer = playerDAO.findById(friend.getIdFriend());
                if (friendPlayer != null) {
                    friendDetails.add(new PlayerFriendDTO(friendPlayer.getId(), friendPlayer.getName()));
                }
            }
        }

        playerDTO.setFriends(friendDetails); // Ajoute les informations d'amis au DTO.
        return playerDTO;
    }

    @Override
    public List<PlayerDTO> getAllPlayers() {
        List<PlayerDTO> playerDTOs = new ArrayList<>();
        List<Friend> allFriends = friendDAO.findAll(); // Récupère toutes les relations d'amitié.

        // Parcourt tous les joueurs pour créer leurs DTOs.
        for (Player player : playerDAO.findAll()) {
            PlayerDTO playerDTO = convertToDTO(player);
            List<PlayerFriendDTO> friendDetails = new ArrayList<>();

            for (Friend friend : allFriends) {
                if (friend.getIdPlayer() == player.getId()) {
                    Player friendPlayer = playerDAO.findById(friend.getIdFriend());
                    if (friendPlayer != null) {
                        friendDetails.add(new PlayerFriendDTO(friendPlayer.getId(), friendPlayer.getName()));
                    }
                }
            }

            playerDTO.setFriends(friendDetails); // Ajoute les informations d'amis au DTO.
            playerDTOs.add(playerDTO);
        }

        return playerDTOs; // Retourne la liste des DTOs des joueurs.
    }

    @Override
    public PlayerDTO updatePlayer(long id, PlayerDTO playerDTO) {
        Player existingPlayer = playerDAO.findById(id); // Recherche le joueur existant.

        // Mise à jour des propriétés du joueur.
        existingPlayer.setName(playerDTO.getName());
        existingPlayer.setSurname(playerDTO.getSurname());
        existingPlayer.setEmail(playerDTO.getEmail());
        existingPlayer.setLevel(playerDTO.getLevel());
        existingPlayer.setTotalPoint(playerDTO.getTotalPoint());

        Player updatedPlayer = playerDAO.save(existingPlayer); // Sauvegarde les modifications.
        return convertToDTO(updatedPlayer); // Retourne le DTO du joueur mis à jour.
    }

    @Override
    public void deletePlayerById(long id) {
        friendService.deleteAllFriends(id); // Supprime toutes les relations d'amitié du joueur.
        playerDAO.deleteById(id); // Supprime le joueur.
    }

    public PlayerDTO convertToDTO(Player player) {
        // Convertit une entité Player en PlayerDTO.
        return new PlayerDTO(player.getId(), player.getName(), player.getSurname(),
                player.getEmail(), player.getLevel(), player.getTotalPoint());
    }

    // Nouvelle méthode pour vérifier si un joueur existe.
    public boolean checkPlayerExistence(long id) {
        Player player = playerDAO.findById(id); // Recherche le joueur.
        return player != null; // Retourne true si le joueur existe, sinon false.
    }

    @Override
    public void updatePlayerStats(long playerId, int scoreToAdd) {
        Player player = playerDAO.findById(playerId); // Recherche le joueur.

        if (player == null) {
            throw new RuntimeException("Player with ID " + playerId + " does not exist."); // Lève une exception si le joueur n'existe pas.
        }

        // Mise à jour du score total.
        player.setTotalPoint(player.getTotalPoint() + scoreToAdd);
        playerDAO.save(player); // Sauvegarde les modifications.
    }
}
