package com.example.PlayerManager.Entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "friends")
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Friend {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "friends_seq")
    @SequenceGenerator(name = "friends_seq", sequenceName = "friends_seq", allocationSize = 1)
    @Column(name = "id_friendship")
    private long id;

    @Column(name = "id_player")
    private long idPlayer;

    @Column(name = "id_friend")
    private long idFriend;

    public Friend(long idPlayer, long idFriend) {
        this.idPlayer = idPlayer;
        this.idFriend = idFriend;
    }
}


