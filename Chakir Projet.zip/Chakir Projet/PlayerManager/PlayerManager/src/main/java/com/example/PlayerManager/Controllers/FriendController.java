package com.example.PlayerManager.Controllers;

import com.example.PlayerManager.DTO.FriendDTO;
import com.example.PlayerManager.Services.IFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Indique que cette classe est un contrôleur REST.
@RequestMapping("/api/friends") // Mappe les requêtes HTTP vers "/api/friends".
public class FriendController {

    @Autowired // Injecte automatiquement le service IFriendService.
    private IFriendService friendService;

    // Ajout d'un nouvel ami entre deux joueurs.
    @PostMapping // Gère les requêtes POST avec un body contenant les IDs des joueurs.
    public FriendDTO addFriend(@RequestBody FriendDTO friendDTO) {
        return friendService.addFriend(friendDTO); // Appelle le service pour ajouter une relation d'amitié.
    }

    @GetMapping // Récupère toutes les relations d'amitié.
    public List<FriendDTO> getAllFriends() {
        return friendService.getAllFriends(); // Appelle le service pour obtenir la liste complète.
    }

    // Supprime une relation d'amitié entre deux joueurs.
    @DeleteMapping("/delete/{idPlayer1}/{idPlayer2}") // Gère les requêtes DELETE avec deux IDs en paramètres.
    public void deleteFriend(@PathVariable long idPlayer1, @PathVariable long idPlayer2) {
        friendService.deleteFriendByPlayers(idPlayer1, idPlayer2); // Appelle le service pour supprimer la relation.
    }
}
