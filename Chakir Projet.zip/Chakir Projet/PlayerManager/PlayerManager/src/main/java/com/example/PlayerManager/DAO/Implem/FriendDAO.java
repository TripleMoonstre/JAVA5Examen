package com.example.PlayerManager.DAO.Implem;

import com.example.PlayerManager.DAO.IFriendDAO;
import com.example.PlayerManager.Entities.Friend;
import com.example.PlayerManager.Repositories.IFriendRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component // Indique que cette classe est un composant Spring géré par le conteneur.
public class FriendDAO implements IFriendDAO {

    @Autowired // Injecte automatiquement le repository IFriendRepository.
    private IFriendRepository friendRepository;

    @Override
    public Friend save(Friend friend) {
        return friendRepository.save(friend); // Sauvegarde ou met à jour une relation d'amitié.
    }

    @Override
    public List<Friend> findAll() {
        return friendRepository.findAll(); // Retourne toutes les relations d'amitié.
    }

    @Override
    public void deleteById(long id) {
        friendRepository.deleteById(id); // Supprime une relation d'amitié par ID.
    }
}
