package com.example.GameManager.DAO.Implem;

import com.example.GameManager.DAO.IGameDAO;
import com.example.GameManager.Entities.Game;
import com.example.GameManager.Repositories.IGameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Component // Indique que cette classe est un composant Spring géré par le conteneur.
public class GameDAO implements IGameDAO {

    @Autowired // Injecte automatiquement le repository IGameRepository.
    private IGameRepository gameRepository;

    @Override
    public Game save(Game game) {
        return gameRepository.save(game); // Sauvegarde ou met à jour un jeu.
    }

    @Override
    public Game update(Game game) {
        return gameRepository.save(game); // `save` agit comme `saveOrUpdate` ici.
    }

    @Override
    public void deleteById(long id) {
        gameRepository.deleteById(id); // Supprime un jeu par son ID.
    }

    @Override
    public Game findById(long id) {
        return gameRepository.findById(id).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, // Renvoie une exception HTTP 404 si le jeu n'est pas trouvé.
                "Game not found with id: " + id
        ));
    }

    @Override
    public List<Game> findAll() {
        return gameRepository.findAll(); // Retourne la liste de tous les jeux.
    }
}
