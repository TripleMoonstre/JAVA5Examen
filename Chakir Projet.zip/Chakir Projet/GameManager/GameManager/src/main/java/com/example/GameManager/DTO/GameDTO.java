package com.example.GameManager.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GameDTO {
    private long id;
    private Date date;
    private String gameType;
    private long maxScore;
    private long idHost;
}
