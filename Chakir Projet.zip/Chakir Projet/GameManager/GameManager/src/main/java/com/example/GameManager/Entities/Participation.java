package com.example.GameManager.Entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "participations")
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Participation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "participations_seq")
    @SequenceGenerator(name = "participations_seq", sequenceName = "participations_seq", allocationSize = 1)
    private long id;

    @Column(name = "id_game")
    private long idGame;

    @Column(name = "id_player")
    private long idPlayer;

    @Column(name = "score")
    private int score;

    @Column(name = "victory")
    private boolean victory;
}

