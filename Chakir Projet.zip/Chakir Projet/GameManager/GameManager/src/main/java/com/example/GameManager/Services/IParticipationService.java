package com.example.GameManager.Services;

import com.example.GameManager.DTO.ParticipationDTO;

import java.util.List;

public interface IParticipationService {
    ParticipationDTO createParticipation(ParticipationDTO participationDTO);
    ParticipationDTO getParticipationById(long id);
    List<ParticipationDTO> getAllParticipations();
    ParticipationDTO updateParticipation(long id, ParticipationDTO participationDTO);
    void deleteParticipationById(long id);
}
