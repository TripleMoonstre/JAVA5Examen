package com.example.GameManager.Repositories;

import com.example.GameManager.Entities.Participation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IParticipationRepository extends JpaRepository<Participation, Long> {
    List<Participation> findByIdGame(long gameId);
}