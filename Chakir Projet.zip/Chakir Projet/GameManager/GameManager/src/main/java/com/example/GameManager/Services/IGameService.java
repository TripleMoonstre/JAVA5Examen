package com.example.GameManager.Services;

import com.example.GameManager.DTO.GameDTO;
import java.util.List;

public interface IGameService {
    GameDTO createGame(GameDTO gameDTO);
    GameDTO updateGame(long id, GameDTO gameDTO);
    void deleteGameById(long id);
    GameDTO getGameById(long id);
    List<GameDTO> getAllGames();
    void endGame(long gameId);
}
