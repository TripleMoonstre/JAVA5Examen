package com.example.GameManager.Services.Implem;

import com.example.GameManager.DAO.IGameDAO;
import com.example.GameManager.DAO.Implem.ParticipationDAO;
import com.example.GameManager.DTO.GameDTO;
import com.example.GameManager.DTO.ParticipationDTO;
import com.example.GameManager.Entities.Game;
import com.example.GameManager.Entities.Participation;
import com.example.GameManager.Repositories.IGameRepository;
import com.example.GameManager.Services.IGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GameService implements IGameService {

    @Autowired
    private IGameDAO gameDAO;

    @Autowired
    private ParticipationDAO participationDAO;

    @Autowired
    private RestTemplate restTemplate;

    private static final String PLAYER_EXISTS_URL = "http://localhost:8080/api/players/{id}/exist";
    private static final String UPDATE_PLAYER_STATS_URL = "http://localhost:8080/api/players/{id}/updateScore";




    @Override
    public GameDTO createGame(GameDTO gameDTO) {
        // Vérifier si le hostId existe via l'API des joueurs
        long hostId = gameDTO.getIdHost();

        Boolean hostExists = restTemplate.getForObject(PLAYER_EXISTS_URL, Boolean.class, hostId);

        if (hostExists == null || !hostExists) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Host with ID " + hostId + " does not exist.");
        }

        // Si le hostId existe, créer la partie
        Game game = toEntity(gameDTO);
        Game savedGame = gameDAO.save(game);
        return toDTO(savedGame);
    }

    @Override
    public GameDTO updateGame(long id, GameDTO gameDTO) {
        // Trouver le jeu existant par ID
        Game existingGame = gameDAO.findById(id);

        // Mettre à jour les champs uniquement si de nouvelles valeurs sont fournies
        if (gameDTO.getDate() != null) {
            existingGame.setDate(gameDTO.getDate());
        }
        if (gameDTO.getGameType() != null && !gameDTO.getGameType().isEmpty()) {
            existingGame.setGameType(gameDTO.getGameType());
        }
        if (gameDTO.getMaxScore() != 0) {
            existingGame.setMaxScore(gameDTO.getMaxScore());
        }
        if (gameDTO.getIdHost() != 0) {
            existingGame.setIdHost(gameDTO.getIdHost());
        }

        // Sauvegarder les modifications dans la base de données
        Game updatedGame = gameDAO.update(existingGame);

        // Retourner le DTO mis à jour
        return toDTO(updatedGame);
    }


    @Override
    public void deleteGameById(long id) {
        // Vérifier si la partie existe
        Game game = gameDAO.findById(id);


        // Récupérer toutes les participations associées au gameId
        List<Participation> participations = participationDAO.findByGameId(id);

        // Supprimer toutes les participations associées
        for (Participation participation : participations) {
            participationDAO.deleteById(participation.getId());
        }

        // Supprimer la partie
        gameDAO.deleteById(id);
    }

    @Override
    public GameDTO getGameById(long id) {
        Game game = gameDAO.findById(id);
        return game != null ? toDTO(game) : null;
    }

    @Override
    public List<GameDTO> getAllGames() {
        List<Game> games = gameDAO.findAll();
        return games.stream().map(this::toDTO).collect(Collectors.toList());
    }


    @Override
    public void endGame(long gameId) {
        // Vérifier si la game existe
        Game game = gameDAO.findById(gameId);


        // Récupérer les participations pour cette game
        List<Participation> participations = participationDAO.findByGameId(gameId);
        for (Participation participation : participations) {
            long playerId = participation.getIdPlayer();

            try {
                // Vérifier si le joueur existe via l'API
                Boolean playerExists = restTemplate.getForObject(PLAYER_EXISTS_URL, Boolean.class, playerId);
                System.out.println(playerExists);

                if (playerExists != null && playerExists) {
                    // Si le joueur existe, mettre à jour ses statistiques
                    updatePlayerStats(playerId, participation.getScore());
                } else {
                    System.out.println("Player with ID " + playerId + " does not exist. Skipping.");
                }
            } catch (HttpClientErrorException | HttpServerErrorException e) {
                // En cas d'erreur 404 (non trouvé) ou d'autres erreurs, afficher un message et passer au joueur suivant
                System.out.println("Error checking player existence for ID " + playerId + ": " + e.getMessage() + ". Skipping.");
            }
        }
    }

    public void updatePlayerStats(long playerId, int scoreToAdd) {
        try {
            // Appel pour mettre à jour le score du joueur
            restTemplate.put(UPDATE_PLAYER_STATS_URL, scoreToAdd, playerId);
        } catch (Exception e) {
            System.out.println("Error updating stats for player with ID " + playerId + ": " + e.getMessage());
        }
    }

    // Méthode pour convertir une entité Participation en DTO
    public ParticipationDTO convertParticipationToDTO(Participation participation) {
        return new ParticipationDTO(
                participation.getId(),
                participation.getIdGame(),
                participation.getIdPlayer(),
                participation.getScore(),
                participation.isVictory()
        );
    }


    // Mapper: Entity -> DTO
    public GameDTO toDTO(Game game) {
        return new GameDTO(
                game.getId(),
                game.getDate(),
                game.getGameType(),
                game.getMaxScore(),
                game.getIdHost()
        );
    }

    // Mapper: DTO -> Entity
    public Game toEntity(GameDTO gameDTO) {
        return new Game(
                gameDTO.getId(),
                gameDTO.getDate(),
                gameDTO.getGameType(),
                gameDTO.getMaxScore(),
                gameDTO.getIdHost()
        );
    }
}
