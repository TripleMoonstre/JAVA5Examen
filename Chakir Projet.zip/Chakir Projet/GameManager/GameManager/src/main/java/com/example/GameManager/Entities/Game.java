package com.example.GameManager.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name ="games")
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "games_seq")
    @SequenceGenerator(name = "games_seq", sequenceName = "games_seq", allocationSize = 1)
    private long id;

    @Column(name="date")
    private Date date;

    @Column(name="game_type")
    private String gameType;

    @Column(name="max_score")
    private long maxScore;

    @Column(name="id_host")
    private long idHost;


}
