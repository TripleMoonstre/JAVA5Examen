package com.example.GameManager.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration // Indique que cette classe est une configuration Spring.
public class RestTemplateConfig {

    @Bean // Définit un bean pour l'injection de dépendances.
    public RestTemplate restTemplate() {
        return new RestTemplate(); // Fournit une instance de RestTemplate.
    }
}
