package com.example.GameManager.DAO;

import com.example.GameManager.Entities.Game;
import java.util.List;

public interface IGameDAO {
    Game save(Game game);
    Game update(Game game);
    void deleteById(long id);
    Game findById(long id);
    List<Game> findAll();
}
