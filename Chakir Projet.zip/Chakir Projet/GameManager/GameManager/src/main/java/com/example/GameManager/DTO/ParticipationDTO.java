package com.example.GameManager.DTO;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ParticipationDTO {
    private long id;
    private long idGame;
    private long idPlayer;
    private int score;
    private boolean victory;
}

