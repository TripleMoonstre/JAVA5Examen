package com.example.GameManager.Services.Implem;

import com.example.GameManager.DAO.IGameDAO;
import com.example.GameManager.DAO.IParticipationDAO;
import com.example.GameManager.DTO.ParticipationDTO;
import com.example.GameManager.Entities.Game;
import com.example.GameManager.Entities.Participation;
import com.example.GameManager.Services.IParticipationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ParticipationService implements IParticipationService {

    @Autowired
    private IParticipationDAO participationDAO;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private IGameDAO gameDAO;

    private static final String PLAYER_EXISTS_URL = "http://localhost:8080/api/players/{id}/exist";

    @Override
    public ParticipationDTO createParticipation(ParticipationDTO participationDTO) {
        long playerId = participationDTO.getIdPlayer();
        long gameId = participationDTO.getIdGame();

        // Vérifier si le jeu existe dans la base de données avec findById

        Game game = gameDAO.findById(gameId);
        if (game == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Game with ID " + gameId + " does not exist.");
        }

        // Vérifier si le joueur existe via l'API
        Boolean playerExists = restTemplate.getForObject(PLAYER_EXISTS_URL, Boolean.class, playerId);

        if (playerExists == null || !playerExists) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Player with ID " + playerId + " does not exist.");
        }


        // Si le joueur et le jeu existent, créer la participation
        Participation participation = toEntity(participationDTO);
        Participation savedParticipation = participationDAO.save(participation);
        return toDTO(savedParticipation);
    }

    @Override
    public ParticipationDTO updateParticipation(long id, ParticipationDTO participationDTO) {
        // Récupérer l'entité existante
        Participation existingParticipation = participationDAO.findById(id);

        if (existingParticipation == null) {
            // Lance une exception avec un code HTTP 404
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Participation with ID " + id + " not found");
        }

        // Mettre à jour les champs si les nouvelles valeurs sont fournies
        if (participationDTO.getIdGame() != 0) {
            existingParticipation.setIdGame(participationDTO.getIdGame());
        }
        if (participationDTO.getIdPlayer() != 0) {
            existingParticipation.setIdPlayer(participationDTO.getIdPlayer());
        }
        if (participationDTO.getScore() >= 0) { // On autorise les scores de 0
            existingParticipation.setScore(participationDTO.getScore());
        }
        existingParticipation.setVictory(participationDTO.isVictory());

        // Sauvegarder et convertir en DTO
        Participation updatedParticipation = participationDAO.update(existingParticipation);
        return toDTO(updatedParticipation);
    }

    @Override
    public ParticipationDTO getParticipationById(long id) {
        Participation participation = participationDAO.findById(id);
        return participation != null ? toDTO(participation) : null;
    }

    @Override
    public List<ParticipationDTO> getAllParticipations() {
        List<Participation> participations = participationDAO.findAll();
        return participations.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteParticipationById(long id) {
        participationDAO.deleteById(id);
    }

    // Mapper: Entity -> DTO
    public ParticipationDTO toDTO(Participation participation) {
        return ParticipationDTO.builder()
                .id(participation.getId())
                .idGame(participation.getIdGame())
                .idPlayer(participation.getIdPlayer())
                .score(participation.getScore())
                .victory(participation.isVictory())
                .build();
    }

    // Mapper: DTO -> Entity
    public Participation toEntity(ParticipationDTO participationDTO) {
        Participation participation = new Participation();
        participation.setId(participationDTO.getId());
        participation.setIdGame(participationDTO.getIdGame());
        participation.setIdPlayer(participationDTO.getIdPlayer());
        participation.setScore(participationDTO.getScore());
        participation.setVictory(participationDTO.isVictory());
        return participation;
    }
}
