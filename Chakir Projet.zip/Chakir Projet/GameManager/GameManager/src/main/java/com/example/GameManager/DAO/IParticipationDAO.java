package com.example.GameManager.DAO;

import com.example.GameManager.Entities.Participation;

import java.util.List;

public interface IParticipationDAO {
    Participation save(Participation participation);
    Participation update(Participation participation);
    void deleteById(long id);
    Participation findById(long id);
    List<Participation> findAll();
    List<Participation> findByGameId(long gameId);
}
