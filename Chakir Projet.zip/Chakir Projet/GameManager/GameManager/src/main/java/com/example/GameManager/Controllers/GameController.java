package com.example.GameManager.Controllers;

import com.example.GameManager.DTO.GameDTO;
import com.example.GameManager.Services.IGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Indique que cette classe est un contrôleur REST.
@RequestMapping("/api/games") // Mappe les requêtes HTTP vers le chemin "/api/games".
public class GameController {

    @Autowired // Injecte le service IGameService automatiquement.
    private IGameService gameService;

    @PostMapping // Gère les requêtes POST pour créer un jeu.
    public GameDTO createGame(@RequestBody GameDTO gameDTO) {
        return gameService.createGame(gameDTO);
    }

    @GetMapping("/{id}") // Gère les requêtes GET pour obtenir un jeu par ID.
    public GameDTO getGameById(@PathVariable long id) {
        return gameService.getGameById(id);
    }

    @GetMapping // Gère les requêtes GET pour obtenir tous les jeux.
    public List<GameDTO> getAllGames() {
        return gameService.getAllGames();
    }

    @PutMapping("/{id}") // Gère les requêtes PUT pour mettre à jour un jeu.
    public GameDTO updateGame(@PathVariable long id, @RequestBody GameDTO gameDTO) {
        return gameService.updateGame(id, gameDTO);
    }

    @DeleteMapping("/{id}") // Gère les requêtes DELETE pour supprimer un jeu par ID.
    public void deleteGame(@PathVariable long id) {
        gameService.deleteGameById(id);
    }

    @PostMapping("/{id}/end") // Gère les requêtes POST pour marquer la fin d'un jeu.
    public void endGame(@PathVariable long id) {
        gameService.endGame(id); // Appelle la méthode pour gérer la fin du jeu.
    }
}
