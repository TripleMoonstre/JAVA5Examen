package com.example.GameManager.Controllers;

import com.example.GameManager.DTO.ParticipationDTO;
import com.example.GameManager.Services.IParticipationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Indique que cette classe est un contrôleur REST.
@RequestMapping("/api/participations") // Mappe les requêtes HTTP vers le chemin "/api/participations".
public class ParticipationController {

    @Autowired // Injecte automatiquement le service IParticipationService.
    private IParticipationService participationService;

    @PostMapping // Gère les requêtes POST pour créer une participation.
    public ParticipationDTO createParticipation(@RequestBody ParticipationDTO participationDTO) {
        return participationService.createParticipation(participationDTO);
    }

    @GetMapping("/{id}") // Gère les requêtes GET pour obtenir une participation par ID.
    public ParticipationDTO getParticipationById(@PathVariable long id) {
        return participationService.getParticipationById(id);
    }

    @GetMapping // Gère les requêtes GET pour obtenir toutes les participations.
    public List<ParticipationDTO> getAllParticipations() {
        return participationService.getAllParticipations();
    }

    @PutMapping("/{id}") // Gère les requêtes PUT pour mettre à jour une participation.
    public ParticipationDTO updateParticipation(@PathVariable long id, @RequestBody ParticipationDTO participationDTO) {
        return participationService.updateParticipation(id, participationDTO);
    }

    @DeleteMapping("/{id}") // Gère les requêtes DELETE pour supprimer une participation par ID.
    public void deleteParticipation(@PathVariable long id) {
        participationService.deleteParticipationById(id);
    }
}
