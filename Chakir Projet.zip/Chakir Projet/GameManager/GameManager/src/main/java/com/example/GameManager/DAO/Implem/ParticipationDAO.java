package com.example.GameManager.DAO.Implem;

import com.example.GameManager.DAO.IParticipationDAO;
import com.example.GameManager.Entities.Participation;
import com.example.GameManager.Repositories.IParticipationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Component // Indique que cette classe est un composant Spring géré par le conteneur.
public class ParticipationDAO implements IParticipationDAO {

    @Autowired // Injecte automatiquement le repository IParticipationRepository.
    private IParticipationRepository participationRepository;

    @Override
    public Participation save(Participation participation) {
        return participationRepository.save(participation); // Sauvegarde ou met à jour une participation.
    }

    @Override
    public Participation update(Participation participation) {
        return participationRepository.save(participation); // `save` agit comme `saveOrUpdate` ici aussi.
    }

    @Override
    public void deleteById(long id) {
        participationRepository.deleteById(id); // Supprime une participation par ID.
    }

    @Override
    public Participation findById(long id) {
        return participationRepository.findById(id).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, // Renvoie une exception HTTP 404 si la participation n'est pas trouvée.
                "Participation not found with id: " + id
        ));
    }

    @Override
    public List<Participation> findAll() {
        return participationRepository.findAll(); // Retourne toutes les participations.
    }

    // Méthode supplémentaire pour rechercher les participations par gameId.
    public List<Participation> findByGameId(long gameId) {
        return participationRepository.findByIdGame(gameId); // Appelle une méthode spécifique au repository.
    }
}
