package com.example.GameManager;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.GameManager.DTO.ParticipationDTO;
import com.example.GameManager.Entities.Participation;
import com.example.GameManager.Entities.Game;
import com.example.GameManager.DAO.IParticipationDAO;
import com.example.GameManager.DAO.IGameDAO;
import com.example.GameManager.Services.Implem.ParticipationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ParticipationServiceTest {

    @Mock
    private IParticipationDAO participationDAO = mock(IParticipationDAO.class);

    @Mock
    private IGameDAO gameDAO = mock(IGameDAO.class);

    @Mock
    private RestTemplate restTemplate = mock(RestTemplate.class);

    @InjectMocks
    private ParticipationService participationService = new ParticipationService();

    @Test
    public void testCreateParticipation() {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setIdPlayer(1L);
        participationDTO.setIdGame(1L);

        Game mockGame = new Game();
        when(gameDAO.findById(1L)).thenReturn(mockGame);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(1L))).thenReturn(true);
        when(participationDAO.save(any(Participation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ParticipationDTO result = participationService.createParticipation(participationDTO);

        assertNotNull(result);
        assertEquals(1L, result.getIdPlayer());
        assertEquals(1L, result.getIdGame());
        verify(gameDAO, times(1)).findById(1L);
        verify(restTemplate, times(1)).getForObject(anyString(), eq(Boolean.class), eq(1L));
        verify(participationDAO, times(1)).save(any(Participation.class));
    }

    @Test
    public void testUpdateParticipation() {
        Participation existingParticipation = new Participation();
        existingParticipation.setId(1L);
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setIdGame(2L);
        participationDTO.setScore(100);
        participationDTO.setVictory(true);

        when(participationDAO.findById(1L)).thenReturn(existingParticipation);
        when(participationDAO.update(any(Participation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ParticipationDTO result = participationService.updateParticipation(1L, participationDTO);

        assertNotNull(result);
        assertEquals(2L, result.getIdGame());
        assertEquals(100, result.getScore());
        assertTrue(result.isVictory());
        verify(participationDAO, times(1)).findById(1L);
        verify(participationDAO, times(1)).update(any(Participation.class));
    }

    @Test
    public void testGetParticipationById() {
        Participation participation = new Participation();
        participation.setId(1L);

        when(participationDAO.findById(1L)).thenReturn(participation);

        ParticipationDTO result = participationService.getParticipationById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(participationDAO, times(1)).findById(1L);
    }

    @Test
    public void testGetAllParticipations() {
        List<Participation> participations = new ArrayList<>();
        participations.add(new Participation());
        participations.add(new Participation());

        when(participationDAO.findAll()).thenReturn(participations);

        List<ParticipationDTO> result = participationService.getAllParticipations();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(participationDAO, times(1)).findAll();
    }

    @Test
    public void testDeleteParticipationById() {
        doNothing().when(participationDAO).deleteById(1L);

        participationService.deleteParticipationById(1L);

        verify(participationDAO, times(1)).deleteById(1L);
    }

    @Test
    public void testEntityToDtoConversion() {
        Participation participation = new Participation();
        participation.setId(1L);
        participation.setIdGame(10L);
        participation.setIdPlayer(100L);
        participation.setScore(200);
        participation.setVictory(true);

        ParticipationDTO result = participationService.toDTO(participation);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(10L, result.getIdGame());
        assertEquals(100L, result.getIdPlayer());
        assertEquals(200, result.getScore());
        assertTrue(result.isVictory());
    }

    @Test
    public void testDtoToEntityConversion() {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);
        participationDTO.setIdGame(10L);
        participationDTO.setIdPlayer(100L);
        participationDTO.setScore(200);
        participationDTO.setVictory(true);

        Participation result = participationService.toEntity(participationDTO);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(10L, result.getIdGame());
        assertEquals(100L, result.getIdPlayer());
        assertEquals(200, result.getScore());
        assertTrue(result.isVictory());
    }
}
