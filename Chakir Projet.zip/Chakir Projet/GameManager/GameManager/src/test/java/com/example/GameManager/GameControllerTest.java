package com.example.GameManager;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;

import com.example.GameManager.Controllers.GameController;
import com.example.GameManager.DTO.GameDTO;
import com.example.GameManager.Services.IGameService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.List;

@WebMvcTest(GameController.class)
public class GameControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IGameService gameService;

    @Test
    public void testCreateGame() throws Exception {
        GameDTO gameDTO = new GameDTO();
        gameDTO.setId(1L);

        when(gameService.createGame(any(GameDTO.class))).thenReturn(gameDTO);

        String requestBody = "{\"id\":1}";

        mockMvc.perform(post("/api/games")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testUpdateGame() throws Exception {
        GameDTO gameDTO = new GameDTO();
        gameDTO.setId(1L);
        gameDTO.setGameType("Updated Type");

        when(gameService.updateGame(eq(1L), any(GameDTO.class))).thenReturn(gameDTO);

        String requestBody = "{\"gameType\":\"Updated Type\"}";

        mockMvc.perform(put("/api/games/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.gameType").value("Updated Type"));
    }

    @Test
    public void testGetGameById() throws Exception {
        GameDTO gameDTO = new GameDTO();
        gameDTO.setId(1L);

        when(gameService.getGameById(1L)).thenReturn(gameDTO);

        mockMvc.perform(get("/api/games/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testGetAllGames() throws Exception {
        List<GameDTO> games = Arrays.asList(new GameDTO(), new GameDTO());

        when(gameService.getAllGames()).thenReturn(games);

        mockMvc.perform(get("/api/games"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    public void testDeleteGame() throws Exception {
        doNothing().when(gameService).deleteGameById(1L);

        mockMvc.perform(delete("/api/games/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void testEndGame() throws Exception {
        doNothing().when(gameService).endGame(1L);

        mockMvc.perform(post("/api/games/1/end"))
                .andExpect(status().isOk());
    }
}
