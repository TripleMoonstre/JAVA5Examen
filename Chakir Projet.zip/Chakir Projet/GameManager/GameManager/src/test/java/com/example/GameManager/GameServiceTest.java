package com.example.GameManager;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.GameManager.Entities.Participation;
import com.example.GameManager.Repositories.IGameRepository;
import com.example.GameManager.DAO.IGameDAO;
import com.example.GameManager.DAO.Implem.ParticipationDAO;
import com.example.GameManager.DTO.GameDTO;
import com.example.GameManager.Entities.Game;
import com.example.GameManager.Services.Implem.GameService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.ArrayList;

@ExtendWith(MockitoExtension.class)
public class GameServiceTest {

    @Mock
    private IGameRepository gameRepository;

    @Mock
    private IGameDAO gameDAO;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ParticipationDAO participationDAO;

    @InjectMocks
    private GameService gameService;

    @Test
    public void testCreateGame() {
        long hostId = 1L;
        Game game = new Game();
        GameDTO gameDTO = new GameDTO();
        gameDTO.setIdHost(hostId);

        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(hostId))).thenReturn(true);
        when(gameDAO.save(any(Game.class))).thenReturn(game);

        GameDTO result = gameService.createGame(gameDTO);

        assertNotNull(result);
        verify(restTemplate, times(1)).getForObject(anyString(), eq(Boolean.class), eq(hostId));
        verify(gameDAO, times(1)).save(any(Game.class));
    }

    @Test
    public void testGetGameById() {
        Game game = new Game();
        game.setId(1L);

        when(gameDAO.findById(1L)).thenReturn(game);

        GameDTO result = gameService.getGameById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    public void testGetAllGames() {
        List<Game> games = new ArrayList<>();
        games.add(new Game());
        games.add(new Game());

        when(gameDAO.findAll()).thenReturn(games);

        List<GameDTO> result = gameService.getAllGames();

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    public void testUpdateGame() {
        Game existingGame = new Game();
        existingGame.setId(1L);
        existingGame.setGameType("Old Type");

        Game updatedGame = new Game();
        updatedGame.setId(1L);
        updatedGame.setGameType("New Type");

        when(gameDAO.findById(1L)).thenReturn(existingGame);
        when(gameDAO.update(any(Game.class))).thenReturn(updatedGame);

        GameDTO updateDTO = new GameDTO();
        updateDTO.setGameType("New Type");

        GameDTO result = gameService.updateGame(1L, updateDTO);

        assertNotNull(result);
        assertEquals("New Type", result.getGameType());
        verify(gameDAO, times(1)).findById(1L);
        verify(gameDAO, times(1)).update(any(Game.class));
    }

    @Test
    public void testDeleteGame() {
        Game game = new Game();
        when(gameDAO.findById(1L)).thenReturn(game);
        when(participationDAO.findByGameId(1L)).thenReturn(new ArrayList<>());

        gameService.deleteGameById(1L);

        verify(gameDAO, times(1)).deleteById(1L);
        verify(participationDAO, times(1)).findByGameId(1L);
    }

    @Test
    public void testEndGame() {
        // Arrange
        Game game = new Game();
        game.setId(1L);

        // Simulez une participation pour forcer l'appel à restTemplate
        Participation participation = new Participation();
        participation.setIdPlayer(1L);
        participation.setScore(100);

        when(gameDAO.findById(1L)).thenReturn(game);
        when(participationDAO.findByGameId(1L)).thenReturn(List.of(participation));
        when(restTemplate.getForObject(eq("http://localhost:8080/api/players/{id}/exist"), eq(Boolean.class), eq(1L))).thenReturn(true);
        doNothing().when(restTemplate).put(eq("http://localhost:8080/api/players/{id}/updateScore"), any(), eq(1L));

        // Act
        gameService.endGame(1L);

        // Assert
        verify(gameDAO, times(1)).findById(1L);
        verify(participationDAO, times(1)).findByGameId(1L);
        verify(restTemplate, times(1)).getForObject(eq("http://localhost:8080/api/players/{id}/exist"), eq(Boolean.class), eq(1L));
        verify(restTemplate, times(1)).put(eq("http://localhost:8080/api/players/{id}/updateScore"), any(), eq(1L));
    }




    @Test
    public void testEntityToDtoConversion() {
        Game game = new Game();
        game.setId(1L);
        game.setGameType("Test Type");
        game.setMaxScore(100);

        GameDTO result = gameService.toDTO(game);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Type", result.getGameType());
        assertEquals(100, result.getMaxScore());
    }

    @Test
    public void testDtoToEntityConversion() {
        GameDTO gameDTO = new GameDTO();
        gameDTO.setId(1L);
        gameDTO.setGameType("Test Type");
        gameDTO.setMaxScore(100);

        Game result = gameService.toEntity(gameDTO);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Type", result.getGameType());
        assertEquals(100, result.getMaxScore());
    }

    @Test
    public void testUpdatePlayerStats() {
        long playerId = 1L;
        int scoreToAdd = 10;

        doNothing().when(restTemplate).put(anyString(), any(), eq(playerId));

        gameService.updatePlayerStats(playerId, scoreToAdd);

        verify(restTemplate, times(1)).put(anyString(), any(), eq(playerId));
    }
}
