package com.example.GameManager;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;

import com.example.GameManager.Controllers.ParticipationController;
import com.example.GameManager.DTO.ParticipationDTO;
import com.example.GameManager.Services.IParticipationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.List;

@WebMvcTest(ParticipationController.class)
public class ParticipationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IParticipationService participationService;

    @Test
    public void testCreateParticipation() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);

        when(participationService.createParticipation(any(ParticipationDTO.class))).thenReturn(participationDTO);

        String requestBody = "{\"id\":1}";

        mockMvc.perform(post("/api/participations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testGetParticipationById() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);

        when(participationService.getParticipationById(1L)).thenReturn(participationDTO);

        mockMvc.perform(get("/api/participations/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testGetAllParticipations() throws Exception {
        List<ParticipationDTO> participations = Arrays.asList(new ParticipationDTO(), new ParticipationDTO());

        when(participationService.getAllParticipations()).thenReturn(participations);

        mockMvc.perform(get("/api/participations"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    public void testUpdateParticipation() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);
        participationDTO.setScore(100);

        when(participationService.updateParticipation(eq(1L), any(ParticipationDTO.class))).thenReturn(participationDTO);

        String requestBody = "{\"score\":100}";

        mockMvc.perform(put("/api/participations/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.score").value(100));
    }

    @Test
    public void testDeleteParticipation() throws Exception {
        doNothing().when(participationService).deleteParticipationById(1L);

        mockMvc.perform(delete("/api/participations/1"))
                .andExpect(status().isOk());
    }
}
