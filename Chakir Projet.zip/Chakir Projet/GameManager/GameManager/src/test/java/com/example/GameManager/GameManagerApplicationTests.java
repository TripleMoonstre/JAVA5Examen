package com.example.GameManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
