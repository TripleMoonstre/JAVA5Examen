# Documentation du projet 

## Table des matières
### [1. ENDPOINT](#Liste-des-Endpoints)
### [2. Logique Metier](#Logique-métier)
### [3. Base De Données](#Définition-de-la-base-de-données)
### [4. WorkFlow](#Workflow)
### [5. Guide D'Installation ](#Installation-guide)

## Documentation des Endpoints : Service de Gestion des Joueurs

## Liste des Endpoints

## PLAYER

### 1. Ajouter un joueur
- **URL** : `/api/players`
- **Méthode** : `POST`
- **Description** : Permet d'ajouter un nouveau joueur dans la base de données.
- **Paramètres** :
    - Corps de la requête (JSON) :
      ```json
      {
        "name": "string",
        "surname": "string",
        "email": "string",
        "level": "integer",
        "totalPoint": "integer"
      }
      ```
- **Réponses** :
    - **201 Created** : Le joueur a été ajouté avec succès.
      ```json
      {
        "id": "integer",
        "name": "string",
        "surname": "string",
        "email": "string",
        "level": "integer",
        "totalPoint": "integer"
      }
      ```
    - **400 Bad Request** : Requête invalide.
      ```json
      {
        "error": "string"
      }
      ```

### 2. Récupérer les informations d'un joueur
- **URL** : `/api/players/{id}`
- **Méthode** : `GET`
- **Description** : Permet de récupérer les informations et les statistiques d’un joueur spécifique.
- **Paramètres** :
    - `id` : Identifiant unique du joueur (path parameter).
  - **Réponses** :
      - **200 OK** :
        ```json
        {
          "id": "integer",
          "name": "string",
          "surname": "string",
          "email": "string",
          "level": "integer",
          "totalPoint": "integer",
          "friends": [
              {
              "id": 4,
              "name": "cacasdad adpsdpa"
              }
           ]
         }
        ```
      - **404 Not Found** : Joueur non trouvé.
        ```json
        {
          "error": "Player not found with id : id"
        }
        ```

### 3. Récupérer tous les joueurs
- **URL** : `/api/players`
- **Méthode** : `GET`
- **Description** : Permet de récupérer la liste de tous les joueurs.
- **Réponses** :
    - **200 OK** :
      ```json
      {
          "id": "integer",
          "name": "string",
          "surname": "string",
          "email": "string",
          "level": "integer",
          "totalPoint": "integer",
          "friends": [
              {
              "id": 4,
              "name": "cacasdad adpsdpa"
              }
           ]
       }
      ```

### 4. Mettre à jour un joueur
- **URL** : `/api/players/{id}`
- **Méthode** : `PUT`
- **Description** : Permet de mettre à jour les informations d’un joueur spécifique.
- **Paramètres** :
    - `id` : Identifiant unique du joueur (path parameter).
    - Corps de la requête (JSON) :
      ```json
      {
        "name": "string",
        "surname": "string",
        "email": "string",
        "level": "integer",
        "totalPoint": "integer"
      }
      ```
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "id": "integer",
        "name": "string",
        "surname": "string",
        "email": "string",
        "level": "integer",
        "totalPoint": "integer"
      }
      ```
    - **404 Not Found** : Joueur non trouvé.
      ```json
      {
        "error": "Player not found"
      }
      ```

### 5. Supprimer un joueur
- **URL** : `/api/players/{id}`
- **Méthode** : `DELETE`
- **Description** : Permet de supprimer un joueur spécifique de la base de données.
- **Paramètres** :
    - `id` : Identifiant unique du joueur (path parameter).
- **Réponses** :
    - **204 No Content** : Le joueur a été supprimé avec succès.
    - **404 Not Found** : Joueur non trouvé.
      ```json
      {
        "error": "Player not found"
      }
      ```

### 6. Vérifier l’existence d’un joueur
- **URL** : `/api/players/{id}/exist`
- **Méthode** : `GET`
- **Description** : Permet de vérifier si un joueur existe dans la base de données.
- **Paramètres** :
    - `id` : Identifiant unique du joueur (path parameter).
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "exists": "boolean"
      }
      ```

### 7. Mettre à jour le score d’un joueur
- **URL** : `/api/players/{id}/updateScore`
- **Méthode** : `PUT`
- **Description** : Permet de mettre à jour le score total d’un joueur.
- **Paramètres** :
    - `id` : Identifiant unique du joueur (path parameter).
    - Corps de la requête (JSON) :
      ```json
      {
        "scoreToAdd": "integer"
      }
      ```
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "message": "Score updated successfully"
      }
      ```
    - **404 Not Found** : Joueur non trouvé.
      ```json
      {
        "error": "Player not found"
      }
      ```
## FRIEND

### 1. Ajouter une relation d'amitié
- **URL** : `/api/friends`
- **Méthode** : `POST`
- **Description** : Permet d’ajouter une nouvelle relation d’amitié entre deux joueurs.
- **Paramètres** :
    - Corps de la requête (JSON) :
      ```json
      {
        "idPlayer": "integer",
        "idFriend": "integer"
      }
      ```
- **Réponses** :
    - **201 Created** : Relation d’amitié ajoutée avec succès.
      ```json
      {
        "idFriendship": "integer",
        "idPlayer": "integer",
        "idFriend": "integer"
      }
      ```
    - **400 Bad Request** : Requête invalide.
      ```json
      {
        "error": "string"
      }
      ```

### 2. Récupérer toutes les relations d'amitié
- **URL** : `/api/friends`
- **Méthode** : `GET`
- **Description** : Permet de récupérer toutes les relations d’amitié enregistrées.
- **Réponses** :
    - **200 OK** :
      ```json
      [
        {
          "idFriendship": "integer",
          "idPlayer": "integer",
          "idFriend": "integer"
        }
      ]
      ```

### 3. Supprimer une relation d'amitié
- **URL** : `/api/friends/delete/{idPlayer1}/{idPlayer2}`
- **Méthode** : `DELETE`
- **Description** : Permet de supprimer une relation d’amitié entre deux joueurs.
- **Paramètres** :
    - `idPlayer1` : Identifiant du premier joueur (path parameter).
    - `idPlayer2` : Identifiant du second joueur (path parameter).
- **Réponses** :
    - **204 No Content** : La relation d’amitié a été supprimée avec succès.
    - **404 Not Found** : Relation ou joueurs non trouvés.
      ```json
      {
        "error": "Friendship or players not found"
      }
      ```
## GAME

### 1. Ajouter une partie
- **URL** : `/api/games`
- **Méthode** : `POST`
- **Description** : Permet de créer une nouvelle partie dans la base de données.
- **Paramètres** :
    - Corps de la requête (JSON) :
      ```json
      {
        "date": "string (ISO 8601 format)",
        "gameType": "string",
        "maxScore": "integer",
        "idHost": "integer"
      }
      ```
- **Réponses** :
    - **201 Created** : La partie a été créé avec succès.
      ```json
      {
        "id": "integer",
        "date": "string",
        "gameType": "string",
        "maxScore": "integer",
        "idHost": "integer"
      }
      ```
    - **400 Bad Request** : Requête invalide.
      ```json
      {
        "error": "string"
      }
      ```

### 2. Récupérer une partie spécifique
- **URL** : `/api/games/{id}`
- **Méthode** : `GET`
- **Description** : Permet de récupérer les informations d’une partie spécifique à partir de son ID.
- **Paramètres** :
    - `id` : Identifiant unique d'une partie (path parameter).
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "id": "integer",
        "date": "string",
        "gameType": "string",
        "maxScore": "integer",
        "idHost": "integer"
      }
      ```
    - **404 Not Found** : partie non trouvée.
      ```json
      {
        "error": "Game not found"
      }
      ```

### 3. Récupérer toutes les parties
- **URL** : `/api/games`
- **Méthode** : `GET`
- **Description** : Permet de récupérer la liste de toutes les parties.
- **Réponses** :
    - **200 OK** :
      ```json
      [
        {
          "id": "integer",
          "date": "string",
          "gameType": "string",
          "maxScore": "integer",
          "idHost": "integer"
        }
      ]
      ```

### 4. Mettre à jour une partie
- **URL** : `/api/games/{id}`
- **Méthode** : `PUT`
- **Description** : Permet de mettre à jour les informations d’une partie spécifique.
- **Paramètres** :
    - `id` : Identifiant unique d'une partie (path parameter).
    - Corps de la requête (JSON) :
      ```json
      {
        "date": "string",
        "gameType": "string",
        "maxScore": "integer",
        "idHost": "integer"
      }
      ```
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "id": "integer",
        "date": "string",
        "gameType": "string",
        "maxScore": "integer",
        "idHost": "integer"
      }
      ```
    - **404 Not Found** : partie non trouvée.
      ```json
      {
        "error": "Game not found"
      }
      ```

### 5. Supprimer une partie
- **URL** : `/api/games/{id}`
- **Méthode** : `DELETE`
- **Description** : Permet de supprimer une partie spécifique de la base de données.
- **Paramètres** :
    - `id` : Identifiant unique d'une partie (path parameter).
- **Réponses** :
    - **204 No Content** : La partie a été supprimé avec succès.
    - **404 Not Found** : partie non trouvée.
      ```json
      {
        "error": "Game not found"
      }
      ```

### 6. Marquer une partie comme terminé
- **URL** : `/api/games/{id}/end`
- **Méthode** : `POST`
- **Description** : Permet de marquer une partie comme terminé.
- **Paramètres** :
    - `id` : Identifiant unique d'une partie (path parameter).
- **Réponses** :
    - **200 OK** : La partie a été marqué comme terminé avec succès.
    - **404 Not Found** : partie non trouvée.
      ```json
      {
        "error": "Game not found"
      }
      ```
## PARTICIPATION

### 1. Ajouter une participation
- **URL** : `/api/participations`
- **Méthode** : `POST`
- **Description** : Permet de créer une nouvelle participation à une partie.
- **Paramètres** :
    - Corps de la requête (JSON) :
      ```json
      {
        "idGame": "integer",
        "idPlayer": "integer",
        "score": "integer",
        "victory": "boolean"
      }
      ```
- **Réponses** :
    - **201 Created** : Participation ajoutée avec succès.
      ```json
      {
        "id": "integer",
        "idGame": "integer",
        "idPlayer": "integer",
        "score": "integer",
        "victory": "boolean"
      }
      ```
    - **400 Bad Request** : Requête invalide.
      ```json
      {
        "error": "string"
      }
      ```

### 2. Récupérer une participation spécifique
- **URL** : `/api/participations/{id}`
- **Méthode** : `GET`
- **Description** : Permet de récupérer les informations d’une participation spécifique via son ID.
- **Paramètres** :
    - `id` : Identifiant unique de la participation (path parameter).
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "id": "integer",
        "idGame": "integer",
        "idPlayer": "integer",
        "score": "integer",
        "victory": "boolean"
      }
      ```
    - **404 Not Found** : Participation non trouvée.
      ```json
      {
        "error": "Participation not found"
      }
      ```

### 3. Récupérer toutes les participations
- **URL** : `/api/participations`
- **Méthode** : `GET`
- **Description** : Permet de récupérer la liste de toutes les participations enregistrées.
- **Réponses** :
    - **200 OK** :
      ```json
      [
        {
          "id": "integer",
          "idGame": "integer",
          "idPlayer": "integer",
          "score": "integer",
          "victory": "boolean"
        }
      ]
      ```

### 4. Mettre à jour une participation
- **URL** : `/api/participations/{id}`
- **Méthode** : `PUT`
- **Description** : Permet de mettre à jour les informations d’une participation spécifique.
- **Paramètres** :
    - `id` : Identifiant unique de la participation (path parameter).
    - Corps de la requête (JSON) :
      ```json
      {
        "idGame": "integer",
        "idPlayer": "integer",
        "score": "integer",
        "victory": "boolean"
      }
      ```
- **Réponses** :
    - **200 OK** :
      ```json
      {
        "id": "integer",
        "idGame": "integer",
        "idPlayer": "integer",
        "score": "integer",
        "victory": "boolean"
      }
      ```
    - **404 Not Found** : Participation non trouvée.
      ```json
      {
        "error": "Participation not found"
      }
      ```

### 5. Supprimer une participation
- **URL** : `/api/participations/{id}`
- **Méthode** : `DELETE`
- **Description** : Permet de supprimer une participation spécifique via son ID.
- **Paramètres** :
    - `id` : Identifiant unique de la participation (path parameter).
- **Réponses** :
    - **204 No Content** : Participation supprimée avec succès.
    - **404 Not Found** : Participation non trouvée.
      ```json
      {
        "error": "Participation not found"
      }
      ```

# Logique métier

## Explication de la logique métier : PlayerService

Le service `PlayerService` est responsable de la gestion des joueurs dans l'application. Il s'appuie sur des **DAO** (Data Access Objects) pour interagir avec la base de données et utilise une structure orientée objet pour gérer les entités et les DTO (Data Transfer Objects). Voici les principales fonctionnalités et décisions de conception :

### Fonctionnalités principales

1. **Création d'un joueur** (`createPlayer`)
    - Reçoit un `PlayerDTO` depuis le contrôleur.
    - Convertit ce DTO en une entité `Player` pour l'enregistrement dans la base de données.
    - Sauvegarde l'entité via `IPlayerDAO`.
    - Retourne un `PlayerDTO` basé sur l'entité sauvegardée.
   

2. **Récupération d'un joueur par ID** (`getPlayerById`)
    - Recherche un joueur dans la base de données via `IPlayerDAO`.
    - Si le joueur existe, il est converti en `PlayerDTO`.
    - Ajoute des informations détaillées sur ses amis (relations d'amitié trouvées via `IFriendDAO`).
    - Retourne le `PlayerDTO` enrichi.


3. **Récupération de tous les joueurs** (`getAllPlayers`)
    - Récupère tous les joueurs via `IPlayerDAO`.
    - Parcourt les joueurs pour convertir chaque entité en `PlayerDTO`.
    - Pour chaque joueur, enrichit le DTO avec des informations sur leurs amis.
    - Retourne une liste complète de `PlayerDTO`.


4. **Mise à jour d'un joueur** (`updatePlayer`)
    - Recherche un joueur existant dans la base de données.
    - Met à jour ses informations (nom, email, niveau, points, etc.) avec les données reçues dans le DTO.
    - Sauvegarde les modifications via `IPlayerDAO`.
    - Retourne un DTO basé sur l'entité mise à jour.


5. **Suppression d'un joueur** (`deletePlayerById`)
    - Supprime toutes les relations d'amitié associées au joueur via le service `FriendService`.
    - Supprime le joueur de la base de données via `IPlayerDAO`.


6. **Vérification de l'existence d'un joueur** (`checkPlayerExistence`)
    - Recherche un joueur par ID.
    - Retourne `true` si le joueur existe, sinon `false`.


7. **Mise à jour des statistiques d'un joueur** (`updatePlayerStats`)
    - Recherche un joueur par ID.
    - Ajoute un score au total des points du joueur.
    - Sauvegarde la modification via `IPlayerDAO`.

### Décisions de conception

1. **Utilisation de DTOs** :
    - Les DTOs (`PlayerDTO`, `FriendDTO`) servent à abstraire les entités de la base de données et à fournir une vue simplifiée ou enrichie des données, adaptée aux besoins de l'application.


2. **Séparation des responsabilités** :
    - `PlayerService` gère uniquement les opérations liées aux joueurs, tandis que les relations d'amitié sont déléguées à `FriendService`. Cela garantit une modularité et une maintenabilité accrues.


3. **Gestion des relations d'amitié** :
    - Pour chaque joueur, le service enrichit les DTO avec des informations sur ses amis, récupérées via `IFriendDAO`. Cela permet de fournir une vue complète du profil d’un joueur, incluant son réseau social.


4. **Approche REST** :
    - Les méthodes exposées dans `PlayerController` s'appuient sur `PlayerService` pour effectuer les actions métier. Les requêtes REST (POST, GET, PUT, DELETE) permettent de manipuler les ressources de manière cohérente.


### Exemple d'interaction REST
- **Endpoint :** `GET /api/players/{id}`
    - Le contrôleur appelle `PlayerService.getPlayerById`.
    - Le service récupère les données via `IPlayerDAO` et `IFriendDAO`, puis enrichit le DTO.
    - La réponse inclut les détails du joueur et de ses amis sous forme JSON.


### Avantages de la conception
1. **Réutilisabilité** : Le service est découplé du contrôleur, ce qui permet de réutiliser la logique métier dans d'autres parties de l'application.
2. **Testabilité** : Chaque méthode du service peut être testée indépendamment avec des mock DAO.
3. **Extensibilité** : La séparation des responsabilités facilite l’ajout de nouvelles fonctionnalités (exemple : ajout de statistiques avancées).


Le `PlayerService` met en œuvre une logique métier robuste et maintenable, tout en restant fidèle aux principes REST et aux bonnes pratiques de conception logicielle.

## Explication de la logique métier : FriendService

Le service `FriendService` gère les relations d'amitié entre les joueurs. Il repose sur des **DAO** pour interagir avec la base de données et applique une logique spécifique pour créer, récupérer et supprimer des relations d'amitié bidirectionnelles.

### Fonctionnalités principales

1. **Ajout d'une relation d'amitié** (`addFriend`)
    - Reçoit un `FriendDTO` depuis le contrôleur.
    - Recherche les deux joueurs (`idPlayer` et `idFriend`) dans la base de données via `IPlayerDAO`.
    - Crée deux relations d'amitié bidirectionnelles entre les deux joueurs (Player1 → Player2 et Player2 → Player1).
    - Sauvegarde ces relations via `IFriendDAO`.
    - Retourne un `FriendDTO` basé sur l'une des relations sauvegardées.


2. **Récupération de toutes les relations d'amitié** (`getAllFriends`)
    - Récupère toutes les relations d'amitié depuis `IFriendDAO`.
    - Transforme chaque entité `Friend` en un `FriendDTO`.
    - Retourne une liste complète de `FriendDTO`.


3. **Suppression d'une relation d'amitié spécifique** (`deleteFriendByPlayers`)
    - Recherche les relations bidirectionnelles associées à deux joueurs (`idPlayer1` et `idPlayer2`) dans la base de données.
    - Si les relations existent, les supprime via `IFriendDAO`.


4. **Suppression de toutes les relations d'amitié d'un joueur** (`deleteAllFriends`)
    - Recherche toutes les relations où le joueur est soit `idPlayer`, soit `idFriend`.
    - Supprime toutes les relations associées via `IFriendDAO`.


### Décisions de conception


1. **Relations bidirectionnelles** :
    - Chaque relation d'amitié est représentée par deux entrées dans la base de données, garantissant une symétrie (Player1 → Player2 et Player2 → Player1).
    - Cela simplifie les requêtes pour vérifier ou supprimer une amitié.


2. **Utilisation de DTOs** :
    - Les `FriendDTO` abstraient les entités `Friend`, fournissant uniquement les données nécessaires à l'application (identifiants des joueurs et relation).


3. **Séparation des responsabilités** :
    - `FriendService` gère uniquement les opérations métier liées aux relations d'amitié, laissant la gestion des joueurs au `PlayerService`.


4. **Traitement en mémoire** :
    - Certaines opérations (par exemple, la recherche des relations à supprimer) utilisent des filtres en mémoire (`stream` et `filter`). Cela peut être optimisé en déléguant davantage aux requêtes SQL pour améliorer la performance avec des ensembles de données volumineux.



### Avantages de la conception


1. **Modularité** : La gestion des relations d'amitié est isolée, ce qui facilite la maintenance et les évolutions futures.
2. **Simplicité d'utilisation** : Les DTOs et les relations bidirectionnelles offrent une interface utilisateur et développeur cohérente et intuitive.
3. **Robustesse** : La suppression des relations d'amitié couvre tous les cas , garantissant une base de données cohérente.


Le `FriendService` applique une logique claire et symétrique pour gérer les relations sociales entre les joueurs, tout en restant fidèle aux bonnes pratiques de conception logicielle.


## Explication de la logique métier : GameService


Le service `GameService` gère les opérations liées aux parties. Il repose sur des **DAO** pour interagir avec la base de données et utilise un `RestTemplate` pour communiquer avec le microservice des joueurs. Ce service met en œuvre une logique REST pour valider et mettre à jour les données des joueurs en fonction des participations à une partie.


### Fonctionnalités principales


1. **Création d'une partie** (`createGame`)
    - Vérifie si l'hôte de la partie (`idHost`) existe dans la base de données des joueurs en utilisant une requête REST (`GET /api/players/{id}/exist`).
    - Si l'hôte existe, convertit le `GameDTO` en une entité `Game` et enregistre cette entité via `IGameDAO`.
    - Retourne un `GameDTO` représentant la partie créée.
    - En cas d'échec de validation de l'hôte, déclenche une exception HTTP `404 Not Found`.


2. **Mise à jour d'une partie** (`updateGame`)
    - Recherche une partie existante par ID.
    - Met à jour uniquement les champs fournis dans le `GameDTO` (par exemple, `date`, `gameType`, `maxScore`, ou `idHost`).
    - Sauvegarde les modifications dans la base de données via `IGameDAO`.
    - Retourne le `GameDTO` mis à jour.


3. **Suppression d'une partie** (`deleteGameById`)
    - Recherche toutes les participations associées à la partie à supprimer via `ParticipationDAO`.
    - Supprime ces participations avant de supprimer la partie elle-même via `IGameDAO`.
    - Assure une suppression propre et cohérente en cascade.


4. **Récupération d'une partie spécifique** (`getGameById`)
    - Recherche une partie dans la base de données par ID via `IGameDAO`.
    - Retourne un `GameDTO` si la partie existe, sinon `null`.


5. **Récupération de toutes les parties** (`getAllGames`)
    - Récupère toutes les parties via `IGameDAO`.
    - Convertit chaque entité `Game` en `GameDTO` et retourne la liste complète.


6. **Marquer une partie comme terminée** (`endGame`)
    - Recherche les participations associées à une partie terminée.
    - Pour chaque participation, vérifie si le joueur correspondant existe via une requête REST (`GET /api/players/{id}/exist`).
    - Si le joueur existe, met à jour ses statistiques en envoyant une requête REST (`PUT /api/players/{id}/updateScore`) avec le score de la participation.
    - En cas d'erreurs (par exemple, joueur introuvable ou échec de l'appel REST), le service passe au joueur suivant pour garantir une exécution robuste.


### Communication REST


1. **Validation de l'hôte d'une partie** :
    - Lors de la création d'une partie, le service utilise l'endpoint `GET /api/players/{id}/exist` pour vérifier si l'hôte (`idHost`) existe.
    - Si l'hôte n'existe pas, une exception `404 Not Found` est levée pour informer le contrôleur.


2. **Mise à jour des statistiques des joueurs** :
    - Lorsqu'une partie est terminée, le service envoie une requête `PUT /api/players/{id}/updateScore` au microservice des joueurs pour ajouter le score de chaque participation.
    - Cette étape garantit que les performances des joueurs sont prises en compte dans leur historique.


3. **Gestion des erreurs REST** :
    - En cas d'erreur HTTP (`404`, `500`, etc.), le service consigne l'erreur et passe au joueur suivant pour éviter une interruption complète du processus.


### Décisions de conception


1. **Validation des joueurs via REST** :
    - Le service garantit l'intégrité des données en validant l'existence des joueurs avant de créer ou de mettre à jour une partie.
    - Cela réduit le risque d'incohérences entre les microservices.


2. **Suppression propre** :
    - La suppression d'une partie inclut la suppression des participations associées pour maintenir l'intégrité référentielle dans la base de données.


3. **Modularité avec les DTOs** :
    - Le service utilise des `GameDTO` et `ParticipationDTO` pour gérer les données échangées entre les couches.


4. **Robustesse via gestion des erreurs** :
    - Le service gère les erreurs REST de manière à minimiser les interruptions, notamment lors de la mise à jour des statistiques des joueurs.


### Exemple d'interaction REST

- **Endpoint :** `POST /api/games`
    - Le contrôleur appelle `GameService.createGame` avec un `GameDTO`.
    - Le service vérifie l'existence de l'hôte via REST (`GET /api/players/{id}/exist`).
    - Enregistre la partie si la validation est réussie, puis retourne un `GameDTO`.


- **Endpoint :** `POST /api/games/{id}/end`
    - Le contrôleur appelle `GameService.endGame`.
    - Le service parcourt les participations, valide l'existence des joueurs via REST, et met à jour leurs statistiques.


### Avantages de la conception


1. **Couplage faible** : La communication REST entre les services `Game` et `Player` réduit la dépendance directe et favorise la modularité.
2. **Évolutivité** : La gestion séparée des jeux et des joueurs facilite l'ajout de nouvelles fonctionnalités.
3. **Fiabilité** : La gestion des erreurs garantit que les processus critiques, comme la mise à jour des statistiques, ne sont pas interrompus par des erreurs ponctuelles.


Le `GameService` met en œuvre une logique métier robuste et repose sur des principes REST pour une interaction fiable avec le microservice des joueurs.


## Explication de la logique métier : ParticipationService


Le service `ParticipationService` gère les opérations liées aux participations des joueurs dans les parties. Il utilise des **DAO** pour interagir avec la base de données et un `RestTemplate` pour valider l'existence des joueurs via le microservice des joueurs.


### Fonctionnalités principales


1. **Création d'une participation** (`createParticipation`)
    - Vérifie si la partie (`idGame`) existe dans la base de données via `IGameDAO`.
    - Valide l'existence du joueur (`idPlayer`) via une requête REST (`GET /api/players/{id}/exist`).
    - Si le joueur et la partie existent, convertit le `ParticipationDTO` en une entité `Participation`, puis l'enregistre dans la base de données via `IParticipationDAO`.
    - Retourne un `ParticipationDTO` basé sur l'entité sauvegardée.
    - En cas d'échec (partie ou joueur introuvable), déclenche une exception HTTP `404 Not Found`.


2. **Mise à jour d'une participation** (`updateParticipation`)
    - Recherche une participation existante par ID.
    - Met à jour les champs fournis dans le `ParticipationDTO` (par exemple, `idGame`, `idPlayer`, `score`, ou `victory`).
    - Sauvegarde les modifications via `IParticipationDAO`.
    - Retourne un `ParticipationDTO` basé sur l'entité mise à jour.
    - En cas de participation introuvable, déclenche une exception HTTP `404 Not Found`.


3. **Récupération d'une participation spécifique** (`getParticipationById`)
    - Recherche une participation par ID via `IParticipationDAO`.
    - Retourne un `ParticipationDTO` si la participation existe, sinon `null`.


4. **Récupération de toutes les participations** (`getAllParticipations`)
    - Récupère toutes les participations via `IParticipationDAO`.
    - Convertit chaque entité `Participation` en un `ParticipationDTO` et retourne une liste complète.


5. **Suppression d'une participation** (`deleteParticipationById`)
    - Supprime une participation spécifique via son ID en utilisant `IParticipationDAO`.


### Communication REST


1. **Validation des joueurs** :
    - Lors de la création d'une participation, le service utilise l'endpoint `GET /api/players/{id}/exist` pour vérifier si le joueur existe.
    - Cette validation garantit que seules les participations associées à des joueurs valides sont créées.


2. **Gestion des erreurs REST** :
    - En cas d'erreur lors de la validation d'un joueur (par exemple, joueur introuvable), le service déclenche une exception `404 Not Found`, qui est propagée jusqu'au contrôleur.


### Décisions de conception


1. **Validation de l'existence des entités** :
    - Le service s'assure que la partie et le joueur associés à une participation existent avant d'autoriser la création ou la mise à jour. Cela garantit l'intégrité des données.


2. **Modularité avec les DTOs** :
    - Les `ParticipationDTO` sont utilisés pour interagir avec les couches supérieures (contrôleur), tandis que les entités `Participation` sont utilisées pour les interactions avec la base de données.


3. **Approche REST** :
    - Le service repose sur des appels REST au microservice des joueurs pour valider les joueurs. Cela favorise un couplage faible entre les microservices.


4. **Gestion des erreurs cohérente** :
    - Les erreurs, telles que les entités introuvables, sont gérées via des exceptions HTTP appropriées (`404 Not Found`) pour une meilleure communication avec le contrôleur et le client.


### Exemple d'interaction REST


- **Endpoint :** `POST /api/participations`
    - Le contrôleur appelle `ParticipationService.createParticipation` avec un `ParticipationDTO`.
    - Le service vérifie l'existence de la partie via `IGameDAO` et du joueur via REST.
    - Si les validations réussissent, la participation est créée, et un `ParticipationDTO` est retourné.


- **Endpoint :** `PUT /api/participations/{id}`
    - Le contrôleur appelle `ParticipationService.updateParticipation`.
    - Le service met à jour la participation avec les nouvelles données fournies dans le `ParticipationDTO`.


### Avantages de la conception

1. **Couplage faible** : L'utilisation de REST pour valider les joueurs réduit la dépendance directe avec le microservice des joueurs.
2. **Fiabilité** : Les validations strictes empêchent la création ou la mise à jour de participations invalides.
3. **Flexibilité** : Le service peut être étendu pour inclure des fonctionnalités supplémentaires liées aux participations.

Le `ParticipationService` assure une gestion robuste et cohérente des participations, tout en exploitant les avantages d'une architecture basée sur les microservices.


# Définition de la base de données

### Schéma de la base de données

Voici une représentation schématique des relations entre les tables de la base de données utilisées dans le projet :

![Schéma de la base de données](DiagrammeBddJava5.png)

---

### Script SQL de création des tables

```sql
-- Script pour générer les tables players et friends

CREATE TABLE players (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255),
    surname VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    level INTEGER,
    total_point INTEGER
);

CREATE TABLE friends (
    id_friendship BIGSERIAL PRIMARY KEY,
    id_player BIGINT NOT NULL,
    id_friend BIGINT NOT NULL,
    FOREIGN KEY (id_player) REFERENCES players(id),
    FOREIGN KEY (id_friend) REFERENCES players(id)
);

-- Script pour générer les tables games et participations

CREATE TABLE games (
    id BIGSERIAL PRIMARY KEY,
    date DATE,
    game_type VARCHAR(255),
    max_score BIGINT,
    id_host BIGINT,
    FOREIGN KEY (id_host) REFERENCES players(id)
);

CREATE TABLE participations (
    id BIGSERIAL PRIMARY KEY,
    id_game BIGINT NOT NULL,
    id_player BIGINT NOT NULL,
    score INTEGER,
    victory BOOLEAN,
    FOREIGN KEY (id_game) REFERENCES games(id),
    FOREIGN KEY (id_player) REFERENCES players(id)
);  
```

### Justification de la structure

#### Relations claires et normalisées :
- Chaque table est dédiée à une entité unique :
  - **`players`** : Contient les informations sur les joueurs (nom, prénom, email, niveau, points).
  - **`friends`** : Représente les relations d'amitié entre les joueurs.
  - **`games`** : Enregistre les informations des parties, y compris leur hôte.
  - **`participations`** : Suit les joueurs ayant participé à des parties, leur score et leur victoire.
- Les relations entre ces entités sont définies via des clés étrangères pour garantir l'intégrité référentielle.

#### Relations entre les entités :
- La table **`friends`** relie les joueurs entre eux via des relations bidirectionnelles.
- Les tables **`games`** et **`participations`** suivent une relation : "un jeu est joué par plusieurs joueurs".
- **`players`** est au centre de toutes les relations, jouant à la fois le rôle de participant aux parties et celui d'hôte.

#### Évolutivité :
- La structure est conçue pour permettre des extensions futures :
  - Ajouter des statistiques plus détaillées pour les joueurs.
  - Introduire des modes de jeu supplémentaires.
  - Étendre les types de relations entre les entités.

#### Simplicité et efficacité :
- L'utilisation de types de données standard (ex. : `VARCHAR`, `INTEGER`, `BIGSERIAL`) garantit une compatibilité avec la plupart des systèmes de gestion de bases de données relationnelles.
- Les relations entre les entités permettent des requêtes efficaces pour récupérer les informations nécessaires.

#### Alignement avec les besoins fonctionnels :
- La table **`players`** répond au besoin de gérer les informations des joueurs et leur réseau d'amis.
- La table **`games`** permet d'enregistrer les parties, en incluant l'identité de l'hôte et le score maximal.
- La table **`participations`** garantit le suivi des joueurs dans chaque partie, tout en permettant l'analyse des performances individuelles.
- La table **`friends`** permet de modéliser les relations d'amitié, facilitant la gestion des réseaux sociaux entre joueurs.

---

### Conclusion
La structure de la base de données a été pensée pour répondre efficacement aux exigences du projet. Elle est flexible, robuste, et facilement extensible, tout en assurant une gestion cohérente et normalisée des relations entre les entités.


# WorkFlow

### Exemple de workflow complet

Pour le détail du fonctionnement des endpoints, veuillez consulter la section [Liste des Endpoints](#Liste-des-Endpoints).

1. **Création de deux joueurs** :
    - Nous créons deux joueurs dans l'application (Joueur 1 et Joueur 2).
    - Les informations de chaque joueur sont enregistrées dans la base de données via le microservice **PlayerManager**.


2. **Ajout d'une relation d'amitié** :
    - Une relation d'amitié est établie entre Joueur 1 et Joueur 2.
    - Cette relation est enregistrée dans la table `friends` sous forme bidirectionnelle (Joueur 1 → Joueur 2 et Joueur 2 → Joueur 1).


3. **Création d'une partie par Joueur 1** :
    - Joueur 1 crée une partie en tant qu'hôte.
    - Le microservice **GameManager** vérifie que Joueur 1 existe dans la base de données via une communication REST avec **PlayerManager**.
    - La partie est ensuite enregistrée dans la table `games`.


4. **Participation des deux joueurs à la partie** :
    - Joueur 1 et Joueur 2 participent à la partie.
    - Chaque participation est enregistrée dans la table `participations`, en associant leur identifiant et celui de la partie.


5. **Fin de la partie** :
    - La partie est marquée comme terminée.
    - Le microservice **GameManager** :
        - Récupère toutes les participations liées à cette partie.
        - Pour chaque participation, vérifie que le joueur existe via une requête REST au microservice **PlayerManager**.
        - Met à jour les points totaux des joueurs dans la base de données via une requête REST.


À la fin de ce workflow, les joueurs ont été créés, liés par une relation d'amitié, ont participé à une partie, et leurs statistiques ont été mises à jour en conséquence. Ce processus illustre l'interaction fluide entre les microservices et la base de données pour répondre aux besoins fonctionnels de l'application.


# Installation guide

### Prérequis

1. **JAVA 21**   
   - Assurez-vous que JAVA 21 LTS est installé sur votre machine. Si ce n'est pas le cas, téléchargez-le depuis [https://www.oracle.com/fr/java/technologies/downloads/](https://www.oracle.com/fr/java/technologies/downloads/).


2. **PostgreSQL** :
    - Assurez-vous que PostgreSQL est installé sur votre machine. Si ce n'est pas le cas, téléchargez-le depuis [https://www.postgresql.org/download/](https://www.postgresql.org/download/).
    - Notez les identifiants (nom d'utilisateur et mot de passe) de votre base de données PostgreSQL dans le fichier application.propreties du dossier src/main/ressources.

3. **Maven** :
    - Installez Apache Maven sur votre machine. Vous pouvez le télécharger depuis [https://maven.apache.org/download.cgi](https://maven.apache.org/download.cgi).
    - Vérifiez son installation en exécutant `mvn -v` dans un terminal.

4. **IDE recommandé** :
    - Utilisez un IDE comme IntelliJ IDEA ou Eclipse pour simplifier le développement et l'exécution des tests.

---

### Étapes d'installation

1. **Configuration de la base de données** :
    - Connectez-vous à PostgreSQL avec vos identifiants.
    - Créez une base de données nommée `JAVA5` :
      ```sql
      CREATE DATABASE Java5;
      ```
    - Si vous souhaitez utiliser un autre nom pour la base de données, modifiez le fichier `application.properties` dans le projet.


2. **Configuration du fichier `application.properties`** :
    - Ouvrez le fichier `src/main/resources/application.properties` dans le projet.
    - Mettez à jour les informations suivantes avec vos identifiants PostgreSQL :
      ```properties
      spring.datasource.url=jdbc:postgresql://localhost:5432/Java5
      spring.datasource.username=VOTRE_NOM_UTILISATEUR
      spring.datasource.password=VOTRE_MOT_DE_PASSE
      ```
    - **Notez les éléments suivants dans ce fichier** :
        - **`spring.datasource.url`** : Remplacez `Java5` par le nom de votre base de données si vous avez choisi un nom différent.
        - **`spring.datasource.username`** : Ajoutez le nom d'utilisateur de votre instance PostgreSQL.
        - **`spring.datasource.password`** : Ajoutez le mot de passe correspondant à votre utilisateur PostgreSQL.

3. **Installation des dépendances** :
    - Ouvrez un terminal dans le répertoire du projet.
    - Exécutez la commande suivante pour installer toutes les dépendances :
      ```bash
      mvn clean install
      ```

4. **Exécution des tests** :
    - **Avec Maven** :
        - Exécutez les tests avec la commande suivante :
          ```bash
          mvn test
          ```
    - **Avec IntelliJ IDEA** (ou tout autre IDE prenant en charge les tests) :
        - Localisez un test dans le répertoire `src/test/java/`.
        - Faites un clic droit sur le fichier ou la méthode de test et sélectionnez `Run` pour lancer le test.

---

### Remarques

- Si vous rencontrez des erreurs liées à PostgreSQL, vérifiez que le service PostgreSQL est en cours d'exécution sur votre machine.
- Assurez-vous que votre version de PostgreSQL est compatible avec l'application Spring Boot utilisée.


Avec ces étapes, vous serez prêt à configurer et exécuter l'application sur votre environnement local.
