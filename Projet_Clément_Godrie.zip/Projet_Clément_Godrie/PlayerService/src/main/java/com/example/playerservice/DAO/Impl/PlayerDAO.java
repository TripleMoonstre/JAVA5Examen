package com.example.playerservice.DAO.Impl;

import com.example.playerservice.DAO.IPlayerDAO;
import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.Entities.Player;
import com.example.playerservice.Repositories.IPlayerRepository;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PlayerDAO implements IPlayerDAO {
    private final IPlayerRepository IPlayerRepository;
    public PlayerDAO(IPlayerRepository IPlayerRepository) {
        this.IPlayerRepository = IPlayerRepository;
    }

    @Override
    public Player save(Player player) {
        return IPlayerRepository.save(player);
    }

    @Override
    public Player findById(Long id) {
        return IPlayerRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Player not found with id: " + id)
        );
    }

    @Override
    public List<Player> findAll() {
        return IPlayerRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        IPlayerRepository.deleteById(id);
    }

    @Override
    public PlayerProfileDTO getPlayerProfile(Long playerId) {
        Player player = IPlayerRepository.findById(playerId)
                .orElseThrow(() -> new RuntimeException("Player not found with id: " + playerId));
        PlayerProfileDTO profileDTO = new PlayerProfileDTO();
        profileDTO.setId(player.getId());
        profileDTO.setName(player.getName());
        profileDTO.setUsername(player.getUsername());
        profileDTO.setEmail(player.getEmail());
        profileDTO.setLevel(player.getLevel());
        profileDTO.setTotalPoints(player.getTotalPoints());
        return profileDTO;
    }

    @Override
    public boolean existsById(Long playerId) {
        return IPlayerRepository.existsById(playerId);
    }
}
