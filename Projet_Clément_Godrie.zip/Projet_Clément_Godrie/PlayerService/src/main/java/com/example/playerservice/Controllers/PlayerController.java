package com.example.playerservice.Controllers;

import com.example.playerservice.DTO.PlayerDTO;

import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.DTO.PlayerStatsUpdateDTO;
import com.example.playerservice.Services.IPlayerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/players")
public class PlayerController {

    private final IPlayerService playerService;

    public PlayerController(IPlayerService playerService) {
        this.playerService = playerService;
    }

    /* =========== POST ENDPOINTS =========== */

    // Create a new player
    @PostMapping
    public ResponseEntity<PlayerDTO> createPlayer(@RequestBody PlayerDTO playerDTO) {
        PlayerDTO createdPlayer = playerService.create(playerDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPlayer);
    }

    /* =========== GET ENDPOINTS =========== */

    // Get a player by ID
    @GetMapping("/{id}")
    public ResponseEntity<PlayerDTO> getPlayerById(@PathVariable Long id) {
        PlayerDTO player = playerService.findById(id);
        return ResponseEntity.ok(player);
    }

    // Get all players
    @GetMapping
    public ResponseEntity<Iterable<PlayerDTO>> getAllPlayers() {
        Iterable<PlayerDTO> players = playerService.findAll();
        return ResponseEntity.ok(players);
    }

    // Get a player's profile
    @GetMapping("/{id}/profile")
    public ResponseEntity<PlayerProfileDTO> getPlayerProfile(@PathVariable Long id) {
        PlayerProfileDTO profile = playerService.getPlayerProfile(id);
        return ResponseEntity.ok(profile);
    }

    // Check if a player exists by ID
    @GetMapping("/{id}/exists")
    public ResponseEntity<Boolean> checkPlayerExists(@PathVariable Long id) {
        boolean exists = playerService.existsById(id);
        return ResponseEntity.ok(exists);
    }

    /* =========== PUT ENDPOINTS =========== */

    // Update player statistics
    @PutMapping("/{id}/stats")
    public ResponseEntity<Void> updatePlayerStats(@PathVariable Long id, @RequestBody PlayerStatsUpdateDTO statsUpdateDTO) {
        statsUpdateDTO.setPlayerId(id);
        playerService.updateStats(id, statsUpdateDTO);
        return ResponseEntity.noContent().build();
    }

    // Update player
    @PutMapping("/{id}")
    public ResponseEntity<PlayerDTO> updatePlayer(@PathVariable Long id, @RequestBody PlayerDTO playerDTO) {
        playerDTO.setId(id);
        playerService.update(id, playerDTO);
        return ResponseEntity.ok(playerDTO);
    }

    /* =========== DELETE ENDPOINTS =========== */

    // Delete a player by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlayerById(@PathVariable Long id) {
        playerService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
