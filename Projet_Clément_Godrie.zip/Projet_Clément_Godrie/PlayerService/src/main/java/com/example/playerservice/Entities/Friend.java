package com.example.playerservice.Entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "friends")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Friend {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long playerId;
    private Long friendId;

    public Friend(Long playerId, Long friendId) {
        this.playerId = playerId;
        this.friendId = friendId;
    }

}
