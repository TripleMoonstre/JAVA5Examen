package com.example.playerservice.DAO;

import com.example.playerservice.Entities.Friend;

import java.util.List;

public interface IFriendDAO {
    Friend create(Friend friend);
    List<Friend> findByPlayerId(Long playerId);
    Friend findByPlayerIdAndFriendId(Long playerId, Long friendId);
    void delete(Friend friend);
}