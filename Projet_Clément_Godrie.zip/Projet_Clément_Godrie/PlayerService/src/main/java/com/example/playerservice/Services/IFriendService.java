package com.example.playerservice.Services;

import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.Entities.Friend;

import java.util.List;

public interface IFriendService {
    FriendDTO addFriend(FriendDTO friend);
    void delete(Long playerId, Long friendId);
    FriendDTO findByPlayerIdAndFriendId(Long playerId, Long friendId);
    List<FriendDTO> findByPlayerId(Long playerId);
    Friend convertToEntity(FriendDTO friend);
    FriendDTO convertToDTO(Friend friend);
}
