package com.example.playerservice.Controllers;

import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.Services.IFriendService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
public class FriendController {

    private final IFriendService friendService;

    public FriendController(IFriendService friendService) {
        this.friendService = friendService;
    }

    /* =========== POST ENDPOINT =========== */

    // Add a new friend
    @PostMapping
    public ResponseEntity<FriendDTO> addFriend(@RequestBody FriendDTO friendDTO) {
        FriendDTO addedFriend = friendService.addFriend(friendDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(addedFriend);
    }

    /* =========== GET ENDPOINTS =========== */

    // Find a specific friendship by playerId and friendId
    @GetMapping("/{playerId}/{friendId}")
    public ResponseEntity<FriendDTO> getFriendship(@PathVariable Long playerId, @PathVariable Long friendId) {
        FriendDTO friendship = friendService.findByPlayerIdAndFriendId(playerId, friendId);
        return ResponseEntity.ok(friendship);
    }

    // Get all friends of a player
    @GetMapping("/{playerId}")
    public ResponseEntity<List<FriendDTO>> getFriendsByPlayerId(@PathVariable Long playerId) {
        List<FriendDTO> friends = friendService.findByPlayerId(playerId);
        return ResponseEntity.ok(friends);
    }

    /* =========== DELETE ENDPOINT =========== */

    // Delete a friendship
    @DeleteMapping
    public ResponseEntity<Void> deleteFriend(@RequestBody FriendDTO friendDTO) {
        friendService.delete(friendDTO.getPlayerId(), friendDTO.getFriendId());
        return ResponseEntity.noContent().build();
    }
}

