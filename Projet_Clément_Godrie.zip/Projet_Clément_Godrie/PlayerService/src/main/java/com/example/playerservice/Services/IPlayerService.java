package com.example.playerservice.Services;

import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.DTO.PlayerStatsUpdateDTO;
import com.example.playerservice.Entities.Player;

public interface IPlayerService {
    PlayerDTO create(PlayerDTO player);
    PlayerDTO findById(Long id);
    void deleteById(Long id);
    Iterable<PlayerDTO> findAll();
    PlayerProfileDTO getPlayerProfile(Long playerId);
    void updateStats(Long playerId, PlayerStatsUpdateDTO statsUpdateDTO);
    boolean existsById(Long playerId);
    Player convertToEntity(PlayerDTO playerDTO);
    PlayerDTO convertToDTO(Player player);
    PlayerDTO update(Long playerId, PlayerDTO playerDTO);
    int calculateLevel(int points);
}
