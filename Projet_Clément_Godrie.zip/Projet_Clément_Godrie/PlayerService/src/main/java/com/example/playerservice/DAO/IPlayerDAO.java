package com.example.playerservice.DAO;

import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.Entities.Player;

import java.util.List;

public interface IPlayerDAO {
    Player save(Player player);
    Player findById(Long id);
    List<Player> findAll();
    void deleteById(Long id);
    PlayerProfileDTO getPlayerProfile(Long playerId);
    boolean existsById(Long playerId);
}
