package com.example.playerservice.Entities;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "players")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Player {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String username;
    private String email;
    private Integer level;
    private Integer totalPoints;

}
