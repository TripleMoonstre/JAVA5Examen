package com.example.playerservice.Repositories;

import com.example.playerservice.Entities.Friend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IFriendRepository extends JpaRepository<Friend, Long> {
    List<Friend> findByPlayerId(Long playerId);
    Optional<Friend> findByPlayerIdAndFriendId(Long playerId, Long friendId);
}