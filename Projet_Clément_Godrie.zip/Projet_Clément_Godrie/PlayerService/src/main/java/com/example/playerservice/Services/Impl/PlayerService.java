package com.example.playerservice.Services.Impl;

import com.example.playerservice.DAO.Impl.PlayerDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.DTO.PlayerStatsUpdateDTO;
import com.example.playerservice.Entities.Player;
import com.example.playerservice.Services.IPlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlayerService implements IPlayerService {

    @Autowired
    private PlayerDAO playerDAO;
    @Autowired
    private FriendService friendService;

    @Override
    public PlayerDTO create(PlayerDTO player) {
        Player playerEntity = playerDAO.save(convertToEntity(player));
        return convertToDTO(playerEntity);
    }

    @Override
    public PlayerDTO findById(Long id) {
        Player playerEntity = playerDAO.findById(id);
        return convertToDTO(playerEntity);
    }

    @Override
    public void deleteById(Long id) {
        playerDAO.deleteById(id);
    }

    @Override
    public List<PlayerDTO> findAll() {
        return playerDAO.findAll().stream()
               .map(this::convertToDTO)
               .collect(Collectors.toList());
    }

    @Override
    public PlayerProfileDTO getPlayerProfile(Long playerId) {
        List<FriendDTO> friends = friendService.findByPlayerId(playerId);
        PlayerProfileDTO player = playerDAO.getPlayerProfile(playerId);
        player.setFriends(friends);
        return player;
    }


    @Override
    public void updateStats(Long playerId, PlayerStatsUpdateDTO statsUpdateDTO) {
        Player player = playerDAO.findById(playerId);
        player.setTotalPoints(player.getTotalPoints() + statsUpdateDTO.getPointsGained());
        player.setLevel(calculateLevel(player.getTotalPoints()));
        playerDAO.save(player);
    }

    @Override
    public boolean existsById(Long playerId) {
        return playerDAO.existsById(playerId);
    }
    @Override
    public PlayerDTO update(Long playerId, PlayerDTO playerDTO) {
        Player player = playerDAO.findById(playerId);
        player.setId(playerDTO.getId());
        player.setName(playerDTO.getName());
        player.setUsername(playerDTO.getUsername());
        player.setEmail(playerDTO.getEmail());
        player.setLevel(playerDTO.getLevel());
        player.setTotalPoints(playerDTO.getTotalPoints());
        return convertToDTO(playerDAO.save(player));
    }

    @Override
    public Player convertToEntity(PlayerDTO playerDTO) {
        Player player = new Player();
        player.setId(playerDTO.getId());
        player.setName(playerDTO.getName());
        player.setUsername(playerDTO.getUsername());
        player.setEmail(playerDTO.getEmail());
        player.setLevel(playerDTO.getLevel());
        player.setTotalPoints(playerDTO.getTotalPoints());
        return player;
    }

    @Override
    public PlayerDTO convertToDTO(Player player) {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(player.getId());
        playerDTO.setName(player.getName());
        playerDTO.setUsername(player.getUsername());
        playerDTO.setEmail(player.getEmail());
        playerDTO.setLevel(player.getLevel());
        playerDTO.setTotalPoints(player.getTotalPoints());
        return playerDTO;
    }

    @Override
    public int calculateLevel(int points) {
        int base = 100;
        double factor = 1.5;
        int level = 1;

        while (points >= base * Math.pow(level, factor)) {
            level++;
        }
        return level;
    }
}
