package com.example.playerservice.Services.Impl;

import com.example.playerservice.DAO.Impl.FriendDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.Entities.Friend;
import com.example.playerservice.Services.IFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendService implements IFriendService {
    @Autowired
    private  FriendDAO friendDAO;

    @Override
    public FriendDTO addFriend(FriendDTO friendDTO) {
        Friend friend = convertToEntity(friendDTO);
        Friend savedFriend = friendDAO.create(friend);
        return convertToDTO(savedFriend);
    }

    @Override
    public void delete(Long playerId, Long friendId) {
        Friend friendship = friendDAO.findByPlayerIdAndFriendId(playerId, friendId);
        friendDAO.delete(friendship);
    }

    @Override
    public FriendDTO findByPlayerIdAndFriendId(Long playerId, Long friendId) {
        Friend friendship = friendDAO.findByPlayerIdAndFriendId(playerId, friendId);
        return convertToDTO(friendship);
    }

    @Override
    public List<FriendDTO> findByPlayerId(Long playerId) {
        List<Friend> friends = friendDAO.findByPlayerId(playerId);
        return friends.stream().map(this::convertToDTO).toList();
    }

    @Override
    public Friend convertToEntity(FriendDTO friendDTO) {
        Friend friend = new Friend();
        friend.setId(friendDTO.getId());
        friend.setPlayerId(friendDTO.getPlayerId());
        friend.setFriendId(friendDTO.getFriendId());
        return friend;
    }

    @Override
    public FriendDTO convertToDTO(Friend friend) {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setId(friend.getId());
        friendDTO.setPlayerId(friend.getPlayerId());
        friendDTO.setFriendId(friend.getFriendId());
        return friendDTO;
    }
}