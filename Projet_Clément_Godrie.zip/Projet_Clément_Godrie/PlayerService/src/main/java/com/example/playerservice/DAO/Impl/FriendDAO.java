package com.example.playerservice.DAO.Impl;

import com.example.playerservice.DAO.IFriendDAO;
import com.example.playerservice.Entities.Friend;
import com.example.playerservice.Repositories.IFriendRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FriendDAO implements IFriendDAO {

    @Autowired
    private IFriendRepository IFriendRepository;

    @Override
    public Friend create(Friend friend) {
        // Vérifier si le doublon existe déjà
        if (IFriendRepository.findByPlayerIdAndFriendId(friend.getFriendId(), friend.getPlayerId()).isEmpty()) {
            Friend friend2 = new Friend(friend.getFriendId(), friend.getPlayerId());
            IFriendRepository.save(friend2);
        }
        return IFriendRepository.save(friend);
    }


    @Override
    public List<Friend> findByPlayerId(Long playerId) {
        return IFriendRepository.findByPlayerId(playerId);
    }

    @Override
    public Friend findByPlayerIdAndFriendId(Long playerId, Long friendId) {
        return IFriendRepository.findByPlayerIdAndFriendId(playerId, friendId).orElseThrow(
                () -> new RuntimeException("Friend not found with playerId: " + playerId + " and friendId: " + friendId)
        );
    }

    @Override
    public void delete(Friend friend) {
        IFriendRepository.delete(friend);

        // Supprimer le doublon correspondant en inversant playerId et friendId
        IFriendRepository.findByPlayerIdAndFriendId(friend.getFriendId(), friend.getPlayerId()).ifPresent(duplicate -> IFriendRepository.delete(duplicate));

    }
}