package com.example.playerservice;

import com.example.playerservice.Controllers.PlayerController;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.DTO.PlayerStatsUpdateDTO;
import com.example.playerservice.Services.IPlayerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PlayerController.class)
public class PlayerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IPlayerService playerService;

    // Utilisé pour convertir les objets en JSON (pour le body de la requete)
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testCreatePlayer() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setName("John Doe");
        playerDTO.setEmail("john.doe@example.com");

        PlayerDTO createdPlayer = new PlayerDTO();
        createdPlayer.setId(1L);
        createdPlayer.setName("John Doe");
        createdPlayer.setEmail("john.doe@example.com");

        when(playerService.create(any(PlayerDTO.class))).thenReturn(createdPlayer);

        mockMvc.perform(post("/api/players")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(playerDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));

    }

    @Test
    public void testUpdatePlayer() throws Exception {
        // Arrange
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(1L);
        playerDTO.setName("John Doe Updated");
        playerDTO.setEmail("john.doe@example.com");

        PlayerDTO updatedPlayer = new PlayerDTO();
        updatedPlayer.setId(1L);
        updatedPlayer.setName("John Doe Updated");
        updatedPlayer.setEmail("john.doe@example.com");

        when(playerService.update(any(Long.class), any(PlayerDTO.class))).thenReturn(updatedPlayer);

        mockMvc.perform(put("/api/players/{id}", 1)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(playerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe Updated"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"));

    }

    @Test
    public void testDeletePlayer() throws Exception {
        Mockito.doNothing().when(playerService).deleteById(any(Long.class));

        mockMvc.perform(delete("/api/players/{id}", 1))
                .andExpect(status().isNoContent());
    }

    @Test
    public void testGetPlayerById() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setId(1L);
        playerDTO.setName("John Doe");
        playerDTO.setEmail("john.doe@example.com");

        when(playerService.findById(any(Long.class))).thenReturn(playerDTO);

        mockMvc.perform(get("/api/players/{id}", 1))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.id").value(1L))
               .andExpect(jsonPath("$.name").value("John Doe"))
               .andExpect(jsonPath("$.email").value("john.doe@example.com"));
    }
    @Test
    public void testGetAllPlayers() throws Exception {
        PlayerDTO player1 = new PlayerDTO();
        player1.setId(1L);
        player1.setName("John Doe");
        player1.setEmail("john.doe@example.com");

        PlayerDTO player2 = new PlayerDTO();
        player2.setId(2L);
        player2.setName("Jane Doe");
        player2.setEmail("jane.doe@example.com");

        when(playerService.findAll()).thenReturn(List.of(player1, player2));

        mockMvc.perform(get("/api/players"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("[0].id").value(1L))
               .andExpect(jsonPath("[0].name").value("John Doe"))
               .andExpect(jsonPath("[0].email").value("john.doe@example.com"))
               .andExpect(jsonPath("[1].id").value(2L));
    }

    @Test
    public void testGetPlayerProfile() throws Exception {
        PlayerProfileDTO profileDTO = new PlayerProfileDTO();
        profileDTO.setId(1L);
        profileDTO.setName("John Doe");
        profileDTO.setUsername("johndoe123");
        profileDTO.setEmail("john.doe@example.com");
        profileDTO.setLevel(5);
        profileDTO.setTotalPoints(1500);

        FriendDTO friend1 = new FriendDTO();
        friend1.setId(101L);
        friend1.setPlayerId(1L);
        friend1.setFriendId(2L);

        FriendDTO friend2 = new FriendDTO();
        friend2.setId(102L);
        friend2.setPlayerId(1L);
        friend2.setFriendId(3L);

        profileDTO.setFriends(List.of(friend1, friend2));

        when(playerService.getPlayerProfile(any(Long.class))).thenReturn(profileDTO);

        mockMvc.perform(get("/api/players/{id}/profile", 1)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.username").value("johndoe123"))
                .andExpect(jsonPath("$.email").value("john.doe@example.com"))
                .andExpect(jsonPath("$.level").value(5))
                .andExpect(jsonPath("$.totalPoints").value(1500))
                .andExpect(jsonPath("$.friends[0].id").value(101L))
                .andExpect(jsonPath("$.friends[0].playerId").value(1L))
                .andExpect(jsonPath("$.friends[0].friendId").value(2L))
                .andExpect(jsonPath("$.friends[1].id").value(102L))
                .andExpect(jsonPath("$.friends[1].playerId").value(1L))
                .andExpect(jsonPath("$.friends[1].friendId").value(3L));

    }

    @Test
    public void testUpdatePlayerStats() throws Exception {
        PlayerStatsUpdateDTO statsUpdateDTO = new PlayerStatsUpdateDTO();
        statsUpdateDTO.setPointsGained(500);

        mockMvc.perform(put("/api/players/{id}/stats", 1)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(statsUpdateDTO)))
                .andExpect(status().isNoContent());
    }

    @Test
    public void testCheckPlayerExists() throws Exception {
        Long playerId = 1L;
        when(playerService.existsById(playerId)).thenReturn(true);

        mockMvc.perform(get("/api/players/{id}/exists", playerId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }
}