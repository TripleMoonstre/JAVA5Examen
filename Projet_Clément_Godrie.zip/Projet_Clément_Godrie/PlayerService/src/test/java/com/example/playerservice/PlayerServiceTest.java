package com.example.playerservice;

import com.example.playerservice.DAO.Impl.FriendDAO;
import com.example.playerservice.DAO.Impl.PlayerDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerProfileDTO;
import com.example.playerservice.DTO.PlayerStatsUpdateDTO;
import com.example.playerservice.Entities.Player;
import com.example.playerservice.Services.Impl.FriendService;
import com.example.playerservice.Services.Impl.PlayerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerServiceTest {

    @Mock
    private PlayerDAO playerDAO;
    @Mock
    private FriendDAO friendDAO;
    @Mock
    private FriendService friendService;
    @InjectMocks
    private PlayerService playerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreatePlayer() {
        Long playerId = 1L;

        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setName("John Doe");
        playerDTO.setUsername("johndoeusername");
        playerDTO.setEmail("john.doe@example.com");
        playerDTO.setLevel(5);
        playerDTO.setTotalPoints(1500);

        Player player = new Player();
        player.setId(playerId);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        when(playerDAO.save(any(Player.class))).thenReturn(player);

        PlayerDTO createdPlayer = playerService.create(playerDTO);

        assertNotNull(createdPlayer);
        assertEquals("John Doe", createdPlayer.getName());

        verify(playerDAO, times(1)).save(any(Player.class));
    }

    @Test
    public void testGetPlayerById() {
        Long playerId = 1L;
        Player player = new Player();
        player.setId(playerId);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        when(playerDAO.findById(playerId)).thenReturn(player);

        PlayerDTO playerDTO = playerService.findById(playerId);

        assertNotNull(playerDTO);
        assertEquals("John Doe", playerDTO.getName());

        verify(playerDAO, times(1)).findById(playerId);
    }

    @Test
    public void testDeletePlayerById() {
        Long playerId = 1L;

        playerService.deleteById(playerId);

        verify(playerDAO, times(1)).deleteById(playerId);
    }

    @Test
    public void testFinAllPlayers() {
        Player player1 = new Player();
        player1.setId(1L);
        player1.setName("John Doe");
        player1.setUsername("johndoeusername");
        player1.setEmail("john.doe@example.com");
        player1.setLevel(5);
        player1.setTotalPoints(1500);

        Player player2 = new Player();
        player2.setId(2L);
        player2.setName("Jane Doe");
        player2.setUsername("janedoeusername");
        player2.setEmail("jane.doe@example.com");
        player2.setLevel(6);
        player2.setTotalPoints(1600);

        when(playerDAO.findAll()).thenReturn(List.of(player1, player2));

        List<PlayerDTO> playersDTO = playerService.findAll();

        assertNotNull(playersDTO);
        assertEquals(2, playersDTO.size());
    }

    @Test
    public void testExistsById() {
        Long playerId = 1L;
        Player player = new Player();
        player.setId(playerId);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        when(playerDAO.existsById(playerId)).thenReturn(true);

        boolean exists = playerService.existsById(playerId);

        assertTrue(exists);

        verify(playerDAO, times(1)).existsById(playerId);
    }

    @Test
    public void testUpdatePlayerStats() {
        Long playerId = 1L;
        Player player = new Player();
        player.setId(playerId);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        when(playerDAO.findById(playerId)).thenReturn(player);

        PlayerStatsUpdateDTO statsUpdateDTO = new PlayerStatsUpdateDTO();
        statsUpdateDTO.setPointsGained(100);

        playerService.updateStats(playerId, statsUpdateDTO);

        verify(playerDAO, times(1)).save(any(Player.class));
        assertEquals(1600, player.getTotalPoints());
    }

    @Test
    public void testGetPlayerProfile() {
        Long playerId = 1L;

        PlayerProfileDTO playerProfileDTO = new PlayerProfileDTO();
        playerProfileDTO.setId(playerId);
        playerProfileDTO.setName("John Doe");
        playerProfileDTO.setUsername("johndoeusername");
        playerProfileDTO.setEmail("john.doe@example.com");
        playerProfileDTO.setLevel(5);
        playerProfileDTO.setTotalPoints(1500);

        // Création des relations d'amitiés
        List<FriendDTO> friendDTOList = Arrays.asList(
                new FriendDTO(1L, 1L, 2L),
                new FriendDTO(2L, 1L, 3L)
        );

        when(playerDAO.getPlayerProfile(playerId)).thenReturn(playerProfileDTO);
        when(friendService.findByPlayerId(playerId)).thenReturn(friendDTOList);

        PlayerProfileDTO playerProfile = playerService.getPlayerProfile(playerId);

        assertNotNull(playerProfile);
        assertEquals("John Doe", playerProfile.getName());
        assertEquals("johndoeusername", playerProfile.getUsername());
        assertEquals(5, playerProfile.getLevel());
        assertEquals(1500, playerProfile.getTotalPoints());
        assertNotNull(playerProfile.getFriends());
        assertEquals(2, playerProfile.getFriends().size());
        assertEquals(2L, playerProfile.getFriends().get(0).getFriendId());
        assertEquals(3L, playerProfile.getFriends().get(1).getFriendId());

        verify(playerDAO).getPlayerProfile(playerId);
        verify(friendService).findByPlayerId(playerId);
    }

    @Test
    public void testUpdatePlayer() {
        Long playerId = 1L;
        Player player = new Player();
        player.setId(playerId);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        when(playerDAO.findById(playerId)).thenReturn(player);

        when(playerDAO.save(any(Player.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PlayerDTO playerUpdateDTO = new PlayerDTO();
        playerUpdateDTO.setId(playerId);
        playerUpdateDTO.setName("Jane Doe");
        playerUpdateDTO.setUsername("janedoeusername");
        playerUpdateDTO.setEmail("jane.doe@example.com");
        playerUpdateDTO.setLevel(6);
        playerUpdateDTO.setTotalPoints(1600);

        PlayerDTO updatedPlayer = playerService.update(playerId, playerUpdateDTO);

        verify(playerDAO, times(1)).save(any(Player.class));

        assertEquals("Jane Doe", updatedPlayer.getName());
        assertEquals("janedoeusername", updatedPlayer.getUsername());
        assertEquals("jane.doe@example.com", updatedPlayer.getEmail());
        assertEquals(6, updatedPlayer.getLevel());
        assertEquals(1600, updatedPlayer.getTotalPoints());
    }


    @Test
    public void testConvertToEntity() {
        PlayerDTO playerDTO = new PlayerDTO();
        playerDTO.setName("John Doe");
        playerDTO.setUsername("johndoeusername");
        playerDTO.setEmail("john.doe@example.com");
        playerDTO.setLevel(5);
        playerDTO.setTotalPoints(1500);

        Player player = playerService.convertToEntity(playerDTO);

        assertNotNull(player);
        assertEquals("John Doe", player.getName());
    }
    @Test
    public void testConvertToDTO() {
        Player player = new Player();
        player.setId(1L);
        player.setName("John Doe");
        player.setUsername("johndoeusername");
        player.setEmail("john.doe@example.com");
        player.setLevel(5);
        player.setTotalPoints(1500);

        PlayerDTO playerDTO = playerService.convertToDTO(player);

        assertNotNull(playerDTO);
        assertEquals("John Doe", playerDTO.getName());
    }

}
