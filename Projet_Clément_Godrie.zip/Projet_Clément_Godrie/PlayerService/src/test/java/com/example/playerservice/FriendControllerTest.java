package com.example.playerservice;

import com.example.playerservice.Controllers.FriendController;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.Services.IFriendService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(FriendController.class)
public class FriendControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IFriendService friendService;

    // Utilisé pour convertir les objets en JSON (pour le body de la requete)
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testAddFriend() throws Exception {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setId(1L);
        friendDTO.setPlayerId(1L);
        friendDTO.setFriendId(2L);

        when(friendService.addFriend(any(FriendDTO.class))).thenReturn(friendDTO);

        mockMvc.perform(post("/api/friends")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(friendDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.playerId").value(1L))
                .andExpect(jsonPath("$.friendId").value(2L));
    }

    @Test
    public void testDeleteFriend() throws Exception {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setPlayerId(1L);
        friendDTO.setFriendId(2L);

        doNothing().when(friendService).delete(anyLong(), anyLong());

        mockMvc.perform(delete("/api/friends")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(friendDTO)))
                .andExpect(status().isNoContent());
    }

    @Test
    public void testGetFriendship() throws Exception {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setId(1L);
        friendDTO.setPlayerId(1L);
        friendDTO.setFriendId(2L);

        when(friendService.findByPlayerIdAndFriendId(1L, 2L)).thenReturn(friendDTO);

        mockMvc.perform(get("/api/friends/{playerId}/{friendId}", 1L, 2L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.playerId").value(1L))
                .andExpect(jsonPath("$.friendId").value(2L));
    }

    @Test
    public void testGetFriendsByPlayerId() throws Exception {
        FriendDTO friend1 = new FriendDTO();
        friend1.setId(1L);
        friend1.setPlayerId(1L);
        friend1.setFriendId(2L);

        FriendDTO friend2 = new FriendDTO();
        friend2.setId(2L);
        friend2.setPlayerId(1L);
        friend2.setFriendId(3L);

        List<FriendDTO> friends = List.of(friend1, friend2);

        when(friendService.findByPlayerId(1L)).thenReturn(friends);

        mockMvc.perform(get("/api/friends/{playerId}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].playerId").value(1L))
                .andExpect(jsonPath("$[0].friendId").value(2L))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].playerId").value(1L))
                .andExpect(jsonPath("$[1].friendId").value(3L));
    }
}
