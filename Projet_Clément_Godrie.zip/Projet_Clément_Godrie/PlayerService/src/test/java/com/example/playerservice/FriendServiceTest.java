package com.example.playerservice;

import com.example.playerservice.DAO.Impl.FriendDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.Entities.Friend;
import com.example.playerservice.Services.Impl.FriendService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FriendServiceTest {

    @Mock
    private FriendDAO friendDAO;
    @InjectMocks
    private FriendService friendService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Initialisation des mocks
    }

    @Test
    public void testAddFriend() {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setPlayerId(1L);
        friendDTO.setFriendId(2L);

        Friend friend = new Friend();
        friend.setId(1L);
        friend.setPlayerId(1L);
        friend.setFriendId(2L);

        when(friendDAO.create(any(Friend.class))).thenReturn(friend);

        FriendDTO savedFriend = friendService.addFriend(friendDTO);

        assertNotNull(savedFriend);
        assertEquals(1L, savedFriend.getId());
        assertEquals(1L, savedFriend.getPlayerId());
        assertEquals(2L, savedFriend.getFriendId());

        verify(friendDAO, times(1)).create(any(Friend.class));
    }

    @Test
    public void testDeleteFriend() {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setPlayerId(1L);
        friendDTO.setFriendId(2L);

        Friend friend = new Friend();
        friend.setId(1L);
        friend.setPlayerId(1L);
        friend.setFriendId(2L);

        when(friendDAO.findByPlayerIdAndFriendId(1L, 2L)).thenReturn(friend);

        friendService.delete(friendDTO.getPlayerId(), friendDTO.getFriendId());

        verify(friendDAO, times(1)).delete(friend);
    }

    @Test
    public void testFindByPlayerIdAndFriendId() {
        Friend friend = new Friend();
        friend.setId(1L);
        friend.setPlayerId(1L);
        friend.setFriendId(2L);

        when(friendDAO.findByPlayerIdAndFriendId(anyLong(), anyLong())).thenReturn(friend);

        FriendDTO foundFriend = friendService.findByPlayerIdAndFriendId(1L, 2L);

        assertNotNull(foundFriend);
        assertEquals(1L, foundFriend.getId());
        assertEquals(1L, foundFriend.getPlayerId());
        assertEquals(2L, foundFriend.getFriendId());

        verify(friendDAO, times(1)).findByPlayerIdAndFriendId(anyLong(), anyLong());
    }

    @Test
    public void testFindByPlayerId() {
        Long playerId = 1L;

        Friend friend1 = new Friend();
        friend1.setId(1L);
        friend1.setPlayerId(playerId);
        friend1.setFriendId(2L);

        Friend friend2 = new Friend();
        friend2.setId(2L);
        friend2.setPlayerId(playerId);
        friend2.setFriendId(3L);

        when(friendDAO.findByPlayerId(playerId)).thenReturn(Arrays.asList(friend1, friend2));

        List<FriendDTO> friends = friendService.findByPlayerId(playerId);

        assertNotNull(friends);
        assertEquals(2, friends.size());
        assertEquals(2L, friends.get(0).getFriendId());
        assertEquals(3L, friends.get(1).getFriendId());

        verify(friendDAO, times(1)).findByPlayerId(playerId);
    }

    @Test
    public void testConvertToEntity() {
        FriendDTO friendDTO = new FriendDTO();
        friendDTO.setId(1L);
        friendDTO.setPlayerId(2L);
        friendDTO.setFriendId(3L);

        Friend friend = friendService.convertToEntity(friendDTO);

        assertNotNull(friend);
        assertEquals(1L, friend.getId());
        assertEquals(2L, friend.getPlayerId());
        assertEquals(3L, friend.getFriendId());
    }

    @Test
    public void testConvertToDTO() {
        Friend friend = new Friend();
        friend.setId(1L);
        friend.setPlayerId(2L);
        friend.setFriendId(3L);

        FriendDTO friendDTO = friendService.convertToDTO(friend);

        assertNotNull(friendDTO);
        assertEquals(1L, friendDTO.getId());
        assertEquals(2L, friendDTO.getPlayerId());
        assertEquals(3L, friendDTO.getFriendId());
    }
}