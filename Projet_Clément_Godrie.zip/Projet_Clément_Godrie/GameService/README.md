# Documentation Technique Complète

Cette documentation détaille l'ensemble des aspects techniques de mon projet. Elle inclut les endpoints, la logique métier, la structure de la base de données, une explication complète du fonctionnement de l'application et pour finir, une guide d'installation.

---

## Table des Matières

1. [Définition des Endpoints](#définition-des-endpoints)
2. [Logique Métier](#logique-métier)
3. [Base de données](#base-de-données)
4. [Workflow](#explications-détaillées-du-fonctionnement)
5. [Guide d'installation](#guide-dinstallation)

---

## Définition des Endpoints

### 1. GameController

#### 1.1 Créer une nouvelle partie

- **URL** : `/api/games`
- **Méthode** : POST
- **Paramètres** :
    - Body (JSON) :
      ```json
      {
        "date": "2024-06-11T10:00:00",
        "typeId": 1,
        "maxScore": 100,
        "hostId": 1
      }
      ```
- **Réponse** :
    - 201 CREATED
      ```json
      {
        "id": 1,
        "date": "2024-06-11T10:00:00",
        "typeId": 1,
        "maxScore": 100,
        "hostId": 1
      }
      ```

#### 1.2 Récupérer une partie par ID

- **URL** : `/api/games/{id}`
- **Méthode** : GET
- **Paramètres** :
    - `id` (Path, Long)
- **Réponse** :
    - 200 OK
      ```json
      {
        "id": 1,
        "date": "2024-06-11T10:00:00",
        "typeId": 1,
        "maxScore": 100,
        "hostId": 1
      }
      ```

#### 1.3 Supprimer une partie par ID

- **URL** : `/api/games/{id}`
- **Méthode** : DELETE
- **Paramètres** :
    - `id` (Path, Long)
- **Réponse** :
    - 204 NO CONTENT

#### 1.4 Mettre à jour les statistiques après une partie

- **URL** : `/api/games/{gameId}/update-stats`
- **Méthode** : POST
- **Paramètres** :
    - `gameId` (Path, Long)
- **Réponse** :
    - 204 NO CONTENT

---

### 2. GameTypeController

#### 2.1 Créer un type de jeu

- **URL** : `/api/game-types`
- **Méthode** : POST
- **Paramètres** :
    - Body (JSON) :
      ```json
      {
        "name": "Jeu de Stratégie",
        "description": "Un jeu basé sur la stratégie.",
        "maxPlayers": 4
      }
      ```
- **Réponse** :
    - 201 CREATED
      ```json
      {
        "id": 1,
        "name": "Jeu de Stratégie",
        "description": "Un jeu basé sur la stratégie.",
        "maxPlayers": 4
      }
      ```

#### 2.2 Récupérer tous les types de jeu

- **URL** : `/api/game-types`
- **Méthode** : GET
- **Réponse** :
    - 200 OK
      ```json
      [
        {
          "id": 1,
          "name": "Jeu de Stratégie",
          "description": "Un jeu basé sur la stratégie.",
          "maxPlayers": 4
        }
      ]
      ```

---

### 3. ParticipationController

#### 3.1 Créer une participation

- **URL** : `/api/participations`
- **Méthode** : POST
- **Paramètres** :
    - Body (JSON) :
      ```json
      {
        "gameId": 1,
        "playerId": 2,
        "score": 50,
        "victory": false
      }
      ```
- **Réponse** :
    - 201 CREATED
      ```json
      {
        "id": 1,
        "gameId": 1,
        "playerId": 2,
        "score": 50,
        "victory": false
      }
      ```

---

### 4. FriendController

#### 4.1 Ajouter un ami

- **URL** : `/api/friends`
- **Méthode** : POST
- **Paramètres** :
    - Body (JSON) :
      ```json
      {
        "playerId": 1,
        "friendId": 2
      }
      ```
- **Réponse** :
    - 201 CREATED
      ```json
      {
        "id": 1,
        "playerId": 1,
        "friendId": 2
      }
      ```

#### 4.2 Obtenir les amis d'un joueur

- **URL** : `/api/friends/{playerId}`
- **Méthode** : GET
- **Paramètres** :
    - `playerId` (Path, Long)
- **Réponse** :
    - 200 OK
      ```json
      [
        {
          "id": 1,
          "playerId": 1,
          "friendId": 2
        }
      ]
      ```

---

### 5. PlayerController

#### 5.1 Créer un joueur

- **URL** : `/api/players`
- **Méthode** : POST
- **Paramètres** :
    - Body (JSON) :
      ```json
      {
        "name": "John Doe",
        "username": "johndoe",
        "email": "john@example.com",
        "level": 1,
        "totalPoints": 0
      }
      ```
- **Réponse** :
    - 201 CREATED
      ```json
      {
        "id": 1,
        "name": "John Doe",
        "username": "johndoe",
        "email": "john@example.com",
        "level": 1,
        "totalPoints": 0
      }
      ```

#### 5.2 Mettre à jour les statistiques d'un joueur

- **URL** : `/api/players/{id}/stats`
- **Méthode** : PUT
- **Paramètres** :
    - `id` (Path, Long)
    - Body (JSON) :
      ```json
      {
        "playerId": 1,
        "newPoints": 100
      }
      ```
- **Réponse** :
    - 204 NO CONTENT

---
## Logique Métier
### 1. Introduction
Cette documentation présente la logique métier et les choix techniques du projet **Gestion de Joueurs et de Parties pour un Jeu Vidéo en Ligne**. Le projet est basé sur **deux microservices Spring Boot distincts** :

1. **Service de Gestion des Joueurs** : gère les informations des joueurs, leur réseau d'amis et leurs statistiques.
2. **Service de Gestion des Parties** : gère les parties, les scores et la participation des joueurs.

Les microservices communiquent via des **API REST** pour mettre à jour les statistiques des joueurs après chaque partie.

### 2. Architecture
Le projet est structuré en **6 couches** pour chaque microservice :

1. **Controller** : Gère les requêtes HTTP entrantes et les réponses.
2. **DTO** : Représentation des données échangées entre les couches.
3. **Service** : Contient la logique métier.
4. **Repository** : Fournit des méthodes pour accéder aux bases de données.
5. **DAO** : Permet de gérer les `Optional` renvoyés par le repository afin que le service n'ait que les entités à traiter.
6. **Entity** : Représentation des modèles de données.

---

### 3. Service de Gestion des Joueurs
### 3.1 Fonctionnalités
- **Créer un joueur** : Ajouter un joueur avec ses informations personnelles (nom, pseudo, email, niveau, points de base).
- **Gérer les amis** : Ajouter ou supprimer des amis pour un joueur donné.
- **Récupérer le profil d'un joueur** : Afficher les informations personnelles et le réseau d'amis d'un joueur.
- **Mettre à jour les statistiques** : Après chaque partie, le niveau et les points du joueur sont mis à jour.

### 3.2 Logique métier
- Un joueur peut avoir **plusieurs amis** (relation *One-to-Many*).
- Le niveau d'un joueur est recalculé en fonction des **points accumulés** (algorithme dans `PlayerService`).
- La suppression d'un ami est réciproque pour maintenir la cohérence des données.

### 3.3 Code Exemple - Mise à jour des statistiques
La méthode suivante met à jour les statistiques après un match :
```java
@Override
public void updateStats(Long playerId, PlayerStatsUpdateDTO statsUpdateDTO) {
    Player player = playerDAO.findById(playerId);
    player.setTotalPoints(player.getTotalPoints() + statsUpdateDTO.getPointsGained());
    player.setLevel(calculateLevel(player.getTotalPoints()));
    playerDAO.save(player);
}
```

---

## 4. Service de Gestion des Parties
### 4.1 Fonctionnalités
- **Créer une partie** : Ajouter une nouvelle partie avec un hôte, une date et un type.
- **Gérer les participations** : Enregistrer le score et les performances des joueurs pour chaque partie.
- **Mettre à jour les joueurs** : Appel REST vers le microservice des joueurs pour mettre à jour leurs statistiques.

### 4.2 Logique métier
- Une partie peut avoir **plusieurs participants** (relation *Many-to-Many* via `Participation`).
- Une fois la partie terminée, les données des joueurs sont enregistrées, et leurs statistiques sont mises à jour.
- Le **GameType** définit le type de partie ainsi que le nombre maximum de joueurs qui peuvent y participer.

### 4.3 Code Exemple - Communication inter-service
La méthode suivante met à jour les statistiques des joueurs via un appel REST :
```java
@Override
public void updatePlayerStatsAfterGame(Long gameId) {
    List<ParticipationDTO> participations = participationService.getParticipationsByGameId(gameId);

    for (ParticipationDTO participation : participations) {
        String playerStatsUpdateUrl = playerServiceURL + "/api/players/" + participation.getPlayerId() + "/stats";
        PlayerStatsUpdateDTO statsUpdateDTO = new PlayerStatsUpdateDTO();
        statsUpdateDTO.setPointsGained(participation.getScore());
        statsUpdateDTO.setVictory(participation.getVictory());

        restTemplate.put(playerStatsUpdateUrl, statsUpdateDTO);
    }
}
```

## 5. Décisions Techniques
### 5.1 Microservices
L'architecture en microservices permet :
- Une **indépendance** des services pour faciliter la maintenance.
- Une meilleure **scalabilité** en isolant la logique métier des joueurs et des parties.
- Une communication via **REST API** pour assurer la synchronisation des données.

### 5.2 Base de Données Relationnelle
- Le choix d'une base relationnelle permet de gérer les relations complexes (One-to-Many, Many-to-Many).
- Les deux services disposent de la même base de données afin garantir la cohérence des données.

### 5.3 Communication Inter-Services
L'utilisation de **RestTemplate** pour les appels REST assure une communication simple et efficace entre les microservices.

---
# Base de données

## 1. Introduction
La base de données est un élément central du projet **Gestion de Joueurs et de Parties pour un Jeu Vidéo en Ligne**. Elle permet de stocker et gérer les informations liées aux joueurs, aux parties, aux amis et aux participations. Ce document présente un schéma détaillé, justifie les choix structurels et explique comment la base répond aux exigences du projet.
### 1.1 Script de création des tables 

```sql
create table friends
(
    friend_id bigint not null,
    id        bigint generated by default as identity
        primary key,
    player_id bigint not null
);


create table players
(
    level       integer,
    totalpoints integer,
    id          bigint generated by default as identity
        primary key,
    email       varchar(255),
    name        varchar(255),
    username    varchar(255)
);

create table games
(
    maxscore integer,
    date     timestamp(6),
    hostid   bigint,
    id       bigint generated by default as identity
        primary key,
    typeid   bigint
);

create table gametypes
(
    maxplayers  integer,
    id          bigint generated by default as identity
        primary key,
    description varchar(255),
    name        varchar(255)
);

create table participations
(
    score    integer,
    victory  boolean,
    gameid   bigint,
    id       bigint generated by default as identity
        primary key,
    playerid bigint
);
```
--- 

## 2. Schéma de la base de données
Le schéma ci-dessous illustre les tables, les colonnes, les types de données ainsi que les relations entre les différentes entités du projet :
![Schéma de la Base de Données](./DBModel.png)
### 2.1 Tables et Colonnes


#### Player
| Colonne       | Type       | Description               |
|---------------|------------|---------------------------|
| `id`          | `long`     | Identifiant unique (PK)   |
| `name`        | `varchar`  | Nom complet du joueur     |
| `username`    | `varchar`  | Pseudo du joueur          |
| `email`       | `varchar`  | Adresse email             |
| `level`       | `int`      | Niveau du joueur          |
| `totalPoints` | `int`      | Points accumulés          |

**Relation** :
- **1-N** avec la table `Friend` via `playerId`.
- **1-N** avec la table `Game` en tant qu'hôte via `hostId`.
- **1-N** avec la table `Participation` via `playerId`.
- **N-N** avec la table `Game` via la table intermédiaire `Participation`.

---

#### Friend
| Colonne     | Type       | Description                |
|-------------|------------|----------------------------|
| `id`        | `long`     | Identifiant unique (PK)    |
| `playerId`  | `long`     | Identifiant du joueur (FK) |
| `friendId`  | `long`     | Identifiant de l'ami (FK)  |

**Relation** :
- **1-N** avec la table `Player` (relation d'amitié bidirectionnelle via `playerId` et `friendId`).

---

#### Game
| Colonne     | Type       | Description                            |
|-------------|------------|----------------------------------------|
| `id`        | `long`     | Identifiant unique (PK)                |
| `date`      | `date`     | Date de la partie                      |
| `typeId`    | `long`     | Identifiant du type de partie (FK)     |
| `maxScore`  | `int`      | Score maximum de la partie             |
| `hostId`    | `long`     | Identifiant de l'hôte (FK vers Player) |

**Relation** :
- **1-N** avec la table `Participation` via `gameId`.
- **1-N** avec la table `GameType` via `typeId`.
- **1-N** avec la table `Player` pour l'hôte de la partie via `hostId`.
- **N-N** avec la table `Player` via la table intermédiaire `Participation`.

---

#### GameType
| Colonne       | Type       | Description                   |
|---------------|------------|-------------------------------|
| `id`          | `long`     | Identifiant unique (PK)       |
| `name`        | `string`   | Nom du type de partie         |
| `description` | `string`   | Description du type de partie |
| `maxPlayers`  | `int`      | Nombre maximum de joueurs     |

**Relation** :
- **1-N** avec la table `Game` via `typeId`.

---

#### **Participation**
| Colonne     | Type       | Description                   |
|-------------|------------|-------------------------------|
| `id`        | `long`     | Identifiant unique (PK)       |
| `gameId`    | `long`     | Identifiant de la partie (FK) |
| `playerId`  | `long`     | Identifiant du joueur (FK)    |
| `score`     | `int`      | Score obtenu par le joueur    |
| `isWin`     | `bool`     | Victoire ou défaite           |

**Relation** :
- **1-N** avec la table `Player` via `playerId`.
- **1-N** avec la table `Game` via `gameId`.
- **N-N** entre `Player` et `Game` pour les participations.

## 3. Explication de la structure

### 3.1 Relations Joueur-Ami (Friend)
La table **Friend** implémente une relation **1-N** récursive permettant à un joueur d'avoir plusieurs amis. Les clés `playerId` et `friendId` sont utilisées pour représenter les relations bidirectionnelles entre joueurs.

### 3.2 Relations Joueur-Partie (Participation)
La table **Participation** agit comme une table d'association entre **Player** et **Game** pour modéliser une relation **Many-to-Many**. Cela permet :
- D'enregistrer les joueurs ayant participé à une partie.
- D'associer les scores et les résultats (victoire/défaite).

### 3.3 Relations Game-GameType
La table **Game** contient une clé étrangère vers **GameType**, ce qui permet de définir des types de partie.

### 3.4 Clés primaires et étrangères
Chaque table possède une **clé primaire** (`id`) pour assurer l'unicité des données. Les **clés étrangères** (`FK`) sont utilisées pour définir les relations entre les entités.

## 4. Réponses aux exigences du projet
La structure choisie permet de répondre efficacement aux besoins du projet :

1. **Service de Gestion des Joueurs** :
    - Gestion des informations des joueurs avec `Player`.
    - Gestion des relations d'amitié avec `Friend`.

2. **Service de Gestion des Parties** :
    - Gestion des parties avec `Game` et `GameType`.
    - Suivi des performances des joueurs via `Participation`.

3. **Communication entre les Microservices** :
    - La table `Participation` facilite la mise à jour des statistiques des joueurs après chaque partie.

---

# Explications détaillées du fonctionnement

## 1. Architecture globale
L'architecture repose sur **une API REST backend** développée avec **Spring Boot** et **une base de données relationnelle** PostgreSQL. Les principaux composants sont :

1. **Backend** : Gère la logique métier et expose des endpoints REST.
2. **Base de Données** : Stocke les données (joueurs, amitiés, types de partie, parties, participations).
3. **Repositories** : Fournissent des interfaces pour interagir avec la base de données.
4. **DAO** : Permettent de gérer les `Optional` envoyés par les repositories.
5. **Services** : Orchestrent les opérations métier via des DAO (Data Access Object).

**Technologies et outils utilisés** :
- Java avec Spring Boot
- JPA / Hibernate pour l'ORM
- Mockito & JUnit pour les tests
- PostgreSQL pour la base de données
- Postman pour tester les appels REST

---
## 2. Workflow des applications

### Étapes principales
1. **Création de 2 joueurs**
2. **Création d'une amitié entre les joueurs**
3. **Création d'un type de partie**
4. **Création d'une partie**
5. **Création des participations pour chaque joueur**
6. **Mise à jour des résultats via un appel REST**

Chaque étape est décrite en détail dans la section suivante.

---

## 3. Endpoints et logique métier

### 1. Création des joueurs
**Endpoint** : `POST /api/players`

**Description** : Permet de créer un nouveau joueur.

**Logique Métier** :
- `PlayerService` appelle `PlayerDAO` qui utilise `IPlayerRepository` pour insérer un joueur dans la base de données.

### 2. Création d'une amitié
**Endpoint** : `POST /api/friends`

**Description** : Crée une relation d'amitié entre deux joueurs.

**Logique Métier** :
- `FriendService` utilise `FriendDAO` pour vérifier si les deux joueurs existent qui utilise `IFriendRepository` puis insère l'amitié dans la base de données.

### 3. Création d'un type de partie
**Endpoint** : `POST /api/game-types`

**Description** : Ajoute un type de partie dans l'application.

**Logique Métier** :
- `GameTypeService` appelle `GameTypeDAO` qui utilise `IGameTypeRepository` pour insérer le nouveau type dans la base de données.

### 4. Création d'une partie
**Endpoint** : `POST /api/games`

**Description** : Crée une nouvelle partie.

**Logique Métier** :
- `GameService` appelle `GameDAO` qui utilise `IGameRepository` pour insérer la nouvelle partie dans la base de données.
- `GameService` effectue un appel REST à l'application de gestion des joueurs afin de vérifier si l'hôte spécifié existe bel et bien.
### 5. Création des participations
**Endpoint** : `POST /api/participations`

**Description** : Ajoute la participation d'un joueur à une partie.

**Logique Métier** :
- `ParticipationService` appelle `ParticipationDAO` qui utilise `IParticipationRepository` pour insérer la nouvelle participation dans la base de données.

### 6. Mise à jour des résultats
**Endpoint** : `POST /api/games/{gameId}/update-stats`

**Description** : Met à jour les résultats d'une partie.

**Logique Métier** :
- `GameService` parcourt toutes les participations enregistrées pour la partie spécifiée et pour chaque participation, effectue un appel REST vers le microservice Player afin de modifier les stats du joueur. 

---

## 4. Interconnexion Backend et Base de Données
Chaque endpoint interagit avec un **service** qui appelle un **DAO** pour effectuer les opérations CRUD sur la base de données via les **repositories**.

### Exemple : Création d'un Joueur
1. `PlayerController` reçoit la requête POST.
2. `PlayerService` appelle `PlayerDAO`.
3. `PlayerDAO` utilise `IPlayerRepository.save()` pour insérer le joueur dans la base.
4. Le joueur est retourné dans la réponse.

**Schéma d'interaction** :
```
[Request] --> [Controller] --> [Service] --> [DAO] --> [Repository] --> [Database]
```

# Guide d'Installation
## 1. Prérequis
Assurez-vous que les outils suivants sont installés sur votre machine :

### Outils Nécessaires
- **Java Development Kit (JDK) 21**
- **Apache Maven**
- **PostgreSQL**
- **IDE** (IntelliJ, Eclipse, VS Code, etc.)

Vérifiez les installations avec les commandes suivantes :
```bash
java -version
mvn -version 
```

---

## 2. Configuration de la base de données PostgreSQL
### Installation Locale de PostgreSQL
- Téléchargez et installez PostgreSQL : [PostgreSQL.org](https://www.postgresql.org/)
- Créez une base de données `<nom_database_postgreSQL>` avec un utilisateur `<username_postgreSQL>` et un mot de passe `<password_postgreSQL>`.

---

## 3. Configuration des microservices

### 3.2 Configuration des fichiers `application.properties`
Pour chaque microservice **PlayerService** et **GameService**, configurez la base de données PostgreSQL dans le fichier `src/main/resources/application.properties` :

```properties
# Database Configuration
spring.datasource.url=jdbc:postgresql://localhost:5432/<nom_database_postgreSQL>
spring.datasource.username=<username_postgreSQL>
spring.datasource.password=<password_postgreSQL>
```
---

## 4. Compilation et Exécution des microservices

### 4.1 Compilation avec Maven
Compilez chaque microservice en exécutant la commande Maven :
```bash
mvn clean install
```

### 4.3 Vérification des Microservices
Ouvrez un navigateur ou utilisez un outil comme Postman pour tester les endpoints des microservices :

- **PlayerService** : [http://localhost:8081/api/players](http://localhost:8081/api/players)
- **GameService** : [http://localhost:8082/api/games](http://localhost:8082/api/games)

---

## 5. Tests API et Debugging

### Utilisation de Postman pour tester l'API
- Envoyez des requêtes GET, POST, PUT et DELETE aux différents endpoints.

---

## 6. Conclusion
Vous avez maintenant installé et configuré votre application Spring Boot avec PostgreSQL et deux microservices. En cas de problèmes, consultez les logs ou vérifiez les configurations des fichiers `application.properties`.

Pour toute assistance supplémentaire, contactez l'administrateur du projet.

