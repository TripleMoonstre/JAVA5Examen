package com.example.gameservice;

import com.example.gameservice.Controllers.GameTypeController;
import com.example.gameservice.DTO.GameTypeDTO;
import com.example.gameservice.Services.IGameTypeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@WebMvcTest(GameTypeController.class)
public class GameTypeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IGameTypeService gameTypeService;

    private GameTypeDTO gameTypeDTO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        gameTypeDTO = new GameTypeDTO();
        gameTypeDTO.setId(1L);
        gameTypeDTO.setName("Strategy");
        gameTypeDTO.setDescription("Strategy games");
        gameTypeDTO.setMaxPlayers(4);
    }

    @Test
    public void testCreateGameType() throws Exception {
        Mockito.when(gameTypeService.create(any(GameTypeDTO.class))).thenReturn(gameTypeDTO);

        mockMvc.perform(post("/api/game-types")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Strategy\",\"description\":\"Strategy games\",\"maxPlayers\":4}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Strategy")))
                .andExpect(jsonPath("$.description", is("Strategy games")))
                .andExpect(jsonPath("$.maxPlayers", is(4)));
    }

    @Test
    public void testGetAllGameTypes() throws Exception {
        List<GameTypeDTO> gameTypes = Arrays.asList(gameTypeDTO);
        Mockito.when(gameTypeService.findAll()).thenReturn(gameTypes);

        mockMvc.perform(get("/api/game-types"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name", is("Strategy")));
    }

    @Test
    public void testGetGameTypeById() throws Exception {
        Mockito.when(gameTypeService.findById(anyLong())).thenReturn(gameTypeDTO);

        mockMvc.perform(get("/api/game-types/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Strategy")));
    }

    @Test
    public void testUpdateGameType() throws Exception {
        Mockito.when(gameTypeService.update(any(GameTypeDTO.class))).thenReturn(gameTypeDTO);

        mockMvc.perform(put("/api/game-types/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Updated Strategy\",\"description\":\"Updated description\",\"maxPlayers\":6}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Strategy")));
    }

    @Test
    public void testDeleteGameType() throws Exception {
        Mockito.doNothing().when(gameTypeService).delete(anyLong());

        mockMvc.perform(delete("/api/game-types/1"))
                .andExpect(status().isNoContent());
    }
}
