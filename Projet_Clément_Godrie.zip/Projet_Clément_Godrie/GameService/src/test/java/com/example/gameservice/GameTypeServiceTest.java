package com.example.gameservice;

import com.example.gameservice.DAO.Impl.GameTypeDAO;
import com.example.gameservice.DTO.GameTypeDTO;
import com.example.gameservice.Entities.GameType;
import com.example.gameservice.Services.Impl.GameTypeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameTypeServiceTest {

    @Mock
    private GameTypeDAO gameTypeDAO;

    @InjectMocks
    private GameTypeService gameTypeService;

    private GameType gameType;
    private GameTypeDTO gameTypeDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        gameType = new GameType();
        gameType.setId(1L);
        gameType.setName("Board Game");
        gameType.setDescription("A strategy board game");
        gameType.setMaxPlayers(4);

        gameTypeDTO = new GameTypeDTO();
        gameTypeDTO.setId(1L);
        gameTypeDTO.setName("Board Game");
        gameTypeDTO.setDescription("A strategy board game");
        gameTypeDTO.setMaxPlayers(4);
    }

    @Test
    void testCreate() {
        when(gameTypeDAO.create(any(GameType.class))).thenReturn(gameType);

        GameTypeDTO result = gameTypeService.create(gameTypeDTO);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(gameTypeDTO.getName());
        verify(gameTypeDAO, times(1)).create(any(GameType.class));
    }

    @Test
    void testFindAll() {
        when(gameTypeDAO.findAll()).thenReturn(Arrays.asList(gameType));

        List<GameTypeDTO> result = gameTypeService.findAll();

        assertThat(result).isNotEmpty().hasSize(1);
        assertThat(result.get(0).getName()).isEqualTo(gameType.getName());
        verify(gameTypeDAO, times(1)).findAll();
    }

    @Test
    void testFindById() {
        when(gameTypeDAO.findById(1L)).thenReturn(gameType);

        GameTypeDTO result = gameTypeService.findById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(gameType.getId());
        verify(gameTypeDAO, times(1)).findById(1L);
    }

    @Test
    void testDelete() {
        doNothing().when(gameTypeDAO).delete(1L);

        gameTypeService.delete(1L);

        verify(gameTypeDAO, times(1)).delete(1L);
    }

    @Test
    void testUpdate() {
        when(gameTypeDAO.update(any(GameType.class))).thenReturn(gameType);

        GameTypeDTO result = gameTypeService.update(gameTypeDTO);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(gameTypeDTO.getName());
        verify(gameTypeDAO, times(1)).update(any(GameType.class));
    }

    @Test
    void testConvertToDTO() {
        GameTypeDTO result = gameTypeService.convertToDTO(gameType);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(gameType.getName());
        assertThat(result.getDescription()).isEqualTo(gameType.getDescription());
        assertThat(result.getMaxPlayers()).isEqualTo(gameType.getMaxPlayers());
    }

    @Test
    void testConvertToEntity() {
        GameType result = gameTypeService.convertToEntity(gameTypeDTO);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(gameTypeDTO.getName());
        assertThat(result.getDescription()).isEqualTo(gameTypeDTO.getDescription());
        assertThat(result.getMaxPlayers()).isEqualTo(gameTypeDTO.getMaxPlayers());
    }
}
