package com.example.gameservice;

import com.example.gameservice.Controllers.GameController;
import com.example.gameservice.DTO.GameDTO;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Services.IGameService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GameController.class)
class GameControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IGameService gameService;
    @Autowired
    private ObjectMapper objectMapper;

    private GameDTO gameDTO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        objectMapper.findAndRegisterModules();
        objectMapper.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Paris"));

        gameDTO = new GameDTO();
        gameDTO.setId(1L);
        gameDTO.setDate(new Date());
        gameDTO.setTypeId(101L);
        gameDTO.setMaxScore(50);
        gameDTO.setHostId(100L);
    }

    @Test
    void testCreateGame() throws Exception {
        when(gameService.create(any(GameDTO.class))).thenReturn(gameDTO);

        mockMvc.perform(post("/api/games")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(gameDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(gameDTO.getId()))
                .andExpect(jsonPath("$.date").exists())
                .andExpect(jsonPath("$.typeId").value(gameDTO.getTypeId()))
                .andExpect(jsonPath("$.maxScore").value(gameDTO.getMaxScore()))
                .andExpect(jsonPath("$.hostId").value(gameDTO.getHostId()));
    }

    @Test
    void testGetGameById() throws Exception {
        when(gameService.findById(1L)).thenReturn(gameDTO);

        mockMvc.perform(get("/api/games/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.typeId").value(101L));
    }

    @Test
    void testDeleteGameById() throws Exception {
        doNothing().when(gameService).deleteById(1L);

        mockMvc.perform(delete("/api/games/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void testGetAllGames() throws Exception {
        GameDTO game2 = new GameDTO();
        game2.setId(2L);
        game2.setDate(new Date());
        game2.setTypeId(102L);
        game2.setMaxScore(100);
        game2.setHostId(200L);

        when(gameService.findAll()).thenReturn(Arrays.asList(gameDTO, game2));

        mockMvc.perform(get("/api/games")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[1].id").value(2L));
    }

    @Test
    void testUpdateStats() throws Exception {
        doNothing().when(gameService).updatePlayerStatsAfterGame(1L);

        mockMvc.perform(post("/api/games/1/update-stats")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }
}
