package com.example.gameservice;

import com.example.gameservice.Controllers.ParticipationController;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Services.IParticipationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ParticipationController.class)
class ParticipationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IParticipationService participationService;

    @Autowired
    private ObjectMapper objectMapper;

    private ParticipationDTO participationDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);
        participationDTO.setGameId(2L);
        participationDTO.setPlayerId(3L);
        participationDTO.setScore(100);
        participationDTO.setVictory(true);
    }

    @Test
    void testCreateParticipation() throws Exception {
        when(participationService.create(any(ParticipationDTO.class))).thenReturn(participationDTO);

        mockMvc.perform(post("/api/participations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(participationDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(participationDTO.getId()))
                .andExpect(jsonPath("$.gameId").value(participationDTO.getGameId()));
    }

    @Test
    void testGetParticipationById() throws Exception {
        Long id = 1L;
        when(participationService.findById(id)).thenReturn(participationDTO);

        mockMvc.perform(get("/api/participations/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(participationDTO.getId()))
                .andExpect(jsonPath("$.playerId").value(participationDTO.getPlayerId()));
    }

    @Test
    void testUpdateParticipation() throws Exception {
        Long id = 1L;
        when(participationService.update(any(ParticipationDTO.class))).thenReturn(participationDTO);

        mockMvc.perform(put("/api/participations/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(participationDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(participationDTO.getId()))
                .andExpect(jsonPath("$.score").value(participationDTO.getScore()));
    }

    @Test
    void testGetAllParticipations() throws Exception {
        List<ParticipationDTO> participations = new ArrayList<>();
        participations.add(participationDTO);
        when(participationService.findAll()).thenReturn(participations);

        mockMvc.perform(get("/api/participations"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(participationDTO.getId()))
                .andExpect(jsonPath("$[0].victory").value(participationDTO.getVictory()));
    }

    @Test
    void testDeleteParticipation() throws Exception {
        Long id = 1L;
        doNothing().when(participationService).delete(id);

        mockMvc.perform(delete("/api/participations/{id}", id))
                .andExpect(status().isNoContent());

        verify(participationService, times(1)).delete(id);
    }
}
