package com.example.gameservice;

import com.example.gameservice.DAO.Impl.ParticipationDAO;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Entities.Participation;
import com.example.gameservice.Services.Impl.ParticipationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ParticipationServiceTest {

    @Mock
    private ParticipationDAO participationDAO;

    @InjectMocks
    private ParticipationService participationService;

    private Participation participation;
    private ParticipationDTO participationDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        participation = new Participation();
        participation.setId(1L);
        participation.setGameId(100L);
        participation.setPlayerId(200L);
        participation.setScore(150);
        participation.setVictory(true);

        participationDTO = new ParticipationDTO();
        participationDTO.setId(1L);
        participationDTO.setGameId(100L);
        participationDTO.setPlayerId(200L);
        participationDTO.setScore(150);
        participationDTO.setVictory(true);
    }

    @Test
    void testCreate() {
        when(participationDAO.create(any(Participation.class))).thenReturn(participation);

        ParticipationDTO result = participationService.create(participationDTO);

        assertNotNull(result);
        assertEquals(participation.getId(), result.getId());
        verify(participationDAO, times(1)).create(any(Participation.class));
    }

    @Test
    void testFindById() {
        when(participationDAO.findById(1L)).thenReturn(participation);

        ParticipationDTO result = participationService.findById(1L);

        assertNotNull(result);
        assertEquals(participation.getId(), result.getId());
        verify(participationDAO, times(1)).findById(1L);
    }

    @Test
    void testUpdate() {
        when(participationDAO.update(any(Participation.class))).thenReturn(participation);

        ParticipationDTO result = participationService.update(participationDTO);

        assertNotNull(result);
        assertEquals(participation.getId(), result.getId());
        verify(participationDAO, times(1)).update(any(Participation.class));
    }

    @Test
    void testFindAll() {
        List<Participation> participations = Arrays.asList(participation, participation);
        when(participationDAO.findAll()).thenReturn(participations);

        List<ParticipationDTO> result = participationService.findAll();

        assertEquals(2, result.size());
        verify(participationDAO, times(1)).findAll();
    }

    @Test
    void testDelete() {
        doNothing().when(participationDAO).delete(1L);

        participationService.delete(1L);

        verify(participationDAO, times(1)).delete(1L);
    }

    @Test
    void testGetParticipationsByGameId() {
        List<Participation> participations = Arrays.asList(participation);
        when(participationDAO.findByGameId(100L)).thenReturn(participations);

        List<ParticipationDTO> result = participationService.getParticipationsByGameId(100L);

        assertEquals(1, result.size());
        assertEquals(participation.getGameId(), result.get(0).getGameId());
        verify(participationDAO, times(1)).findByGameId(100L);
    }

    @Test
    void testConvertToDTO() {
        ParticipationDTO result = participationService.convertToDTO(participation);

        assertNotNull(result);
        assertEquals(participation.getId(), result.getId());
        assertEquals(participation.getGameId(), result.getGameId());
        assertEquals(participation.getPlayerId(), result.getPlayerId());
        assertEquals(participation.getScore(), result.getScore());
        assertEquals(participation.getVictory(), result.getVictory());
    }

    @Test
    void testConvertToEntity() {
        Participation result = participationService.convertToEntity(participationDTO);

        assertNotNull(result);
        assertEquals(participationDTO.getId(), result.getId());
        assertEquals(participationDTO.getGameId(), result.getGameId());
        assertEquals(participationDTO.getPlayerId(), result.getPlayerId());
        assertEquals(participationDTO.getScore(), result.getScore());
        assertEquals(participationDTO.getVictory(), result.getVictory());
    }

}
