package com.example.gameservice;

import com.example.gameservice.DAO.Impl.GameDAO;
import com.example.gameservice.DAO.Impl.GameTypeDAO;
import com.example.gameservice.DTO.GameDTO;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.DTO.PlayerStatsUpdateDTO;
import com.example.gameservice.Entities.Game;
import com.example.gameservice.Services.Impl.GameService;
import com.example.gameservice.Services.Impl.ParticipationService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameServiceTest {

    @Mock
    private GameDAO gameDAO;

    @Mock
    private GameTypeDAO gameTypeDAO;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ParticipationService participationService;

    @InjectMocks
    private GameService gameService;

    private GameDTO gameDTO;
    private Game game;
    @Value("${player-service.url}")
    private String playerServiceURL;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        gameDTO = new GameDTO();
        gameDTO.setId(1L);
        gameDTO.setDate(Date.from(Instant.now()));
        gameDTO.setTypeId(2L);
        gameDTO.setHostId(3L);

        game = new Game();
        game.setId(1L);
        game.setDate(Date.from(Instant.now()));
        game.setTypeId(2L);
        game.setHostId(3L);
    }

    @Test
    void testCreate() {
        when(gameTypeDAO.existsById(2L)).thenReturn(true);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);
        when(gameDAO.create(any(Game.class))).thenReturn(game);

        GameDTO result = gameService.create(gameDTO);

        assertNotNull(result);
        assertEquals(game.getId(), result.getId());
        verify(gameDAO).create(any(Game.class));
    }

    @Test
    void testFindById() {
        when(gameDAO.findById(1L)).thenReturn(game);

        GameDTO result = gameService.findById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(gameDAO).findById(1L);
    }

    @Test
    void testDeleteById() {
        doNothing().when(gameDAO).deleteById(1L);

        gameService.deleteById(1L);

        verify(gameDAO).deleteById(1L);
    }

    @Test
    void testFindAll() {
        when(gameDAO.findAll()).thenReturn(List.of(game));

        Iterable<GameDTO> result = gameService.findAll();

        assertNotNull(result);
        assertTrue(result.iterator().hasNext());
        verify(gameDAO).findAll();
    }

    @Test
    void testUpdatePlayerStatsAfterGame() {
        ParticipationDTO participation = new ParticipationDTO();
        participation.setPlayerId(3L);
        participation.setScore(10);
        participation.setVictory(true);

        when(participationService.getParticipationsByGameId(1L)).thenReturn(List.of(participation));
        doNothing().when(restTemplate).put(anyString(), any(PlayerStatsUpdateDTO.class));

        gameService.updatePlayerStatsAfterGame(1L);

        verify(restTemplate).put(anyString(), any(PlayerStatsUpdateDTO.class));
    }
    @Test
    void testCheckPlayerExists() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);

        Boolean isValid = gameService.checkPlayerExists(3L);

        assertTrue(isValid);
        verify(restTemplate).getForObject(anyString(), eq(Boolean.class));
    }

    @Test
    void testValidateGameData() {
        when(gameTypeDAO.existsById(2L)).thenReturn(true);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(true);

        Boolean isValid = gameService.validateGameData(3L, 2L);

        assertTrue(isValid);
        verify(gameTypeDAO).existsById(2L);
        verify(restTemplate).getForObject(anyString(), eq(Boolean.class));
    }

    @Test
    void testConvertToDTO() {
        GameDTO result = gameService.convertToDTO(game);

        assertNotNull(result);
        assertEquals(game.getId(), result.getId());
        assertEquals(game.getDate(), result.getDate());
        assertEquals(game.getHostId(), result.getHostId());
        assertEquals(game.getTypeId(), result.getTypeId());
    }

    @Test
    void testConvertToEntity() {
        Game result = gameService.convertToEntity(gameDTO);

        assertNotNull(result);
        assertEquals(gameDTO.getId(), result.getId());
        assertEquals(gameDTO.getDate(), result.getDate());
        assertEquals(gameDTO.getHostId(), result.getHostId());
        assertEquals(gameDTO.getTypeId(), result.getTypeId());
    }
}
