package com.example.gameservice.DAO.Impl;

import com.example.gameservice.DAO.IParticipationDAO;
import com.example.gameservice.Entities.Participation;
import com.example.gameservice.Repositories.IParticipationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ParticipationDAO implements IParticipationDAO {
    @Autowired
    private IParticipationRepository IParticipationRepository;

    @Override
    public Participation create(Participation participation) {
        return IParticipationRepository.save(participation);
    }

    @Override
    public Participation findById(Long id) {
        return IParticipationRepository.findById(id).orElseThrow(
                () -> new RuntimeException("Participation with id " + id + " not found")
        );
    }

    @Override
    public Participation update(Participation participation) {
        return IParticipationRepository.save(participation);
    }

    @Override
    public List<Participation> findAll() {
        return IParticipationRepository.findAll();
    }

    @Override
    public List<Participation> findByGameId(Long gameId) {
        return IParticipationRepository.findByGameId(gameId);
    }

    @Override
    public void delete(Long id) {
        IParticipationRepository.deleteById(id);
    }


}
