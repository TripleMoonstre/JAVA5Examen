package com.example.gameservice.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlayerStatsUpdateDTO {
    private int pointsGained;
    private Boolean victory;
}