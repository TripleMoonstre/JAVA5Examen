package com.example.gameservice.Controllers;

import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Services.IParticipationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/participations")
public class ParticipationController {

    private final IParticipationService participationService;

    public ParticipationController(IParticipationService participationService) {
        this.participationService = participationService;
    }

    // Create a new Participation
    @PostMapping
    public ResponseEntity<ParticipationDTO> createParticipation(@RequestBody ParticipationDTO participationDTO) {
        ParticipationDTO createdParticipation = participationService.create(participationDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdParticipation);
    }

    // Get a Participation by ID
    @GetMapping("/{id}")
    public ResponseEntity<ParticipationDTO> getParticipationById(@PathVariable Long id) {
        ParticipationDTO participation = participationService.findById(id);
        return ResponseEntity.ok(participation);
    }

    // Update an existing Participation
    @PutMapping("/{id}")
    public ResponseEntity<ParticipationDTO> updateParticipation(@PathVariable Long id, @RequestBody ParticipationDTO participationDTO) {
        participationDTO.setId(id);
        ParticipationDTO updatedParticipation = participationService.update(participationDTO);
        return ResponseEntity.ok(updatedParticipation);
    }

    // Get all Participations
    @GetMapping
    public ResponseEntity<List<ParticipationDTO>> getAllParticipations() {
        List<ParticipationDTO> participations = participationService.findAll();
        return ResponseEntity.ok(participations);
    }

    // Delete a Participation by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteParticipation(@PathVariable Long id) {
        participationService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
