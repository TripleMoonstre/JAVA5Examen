package com.example.gameservice.DAO.Impl;

import com.example.gameservice.DAO.IGameTypeDAO;
import com.example.gameservice.Entities.GameType;
import com.example.gameservice.Repositories.IGameTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GameTypeDAO implements IGameTypeDAO {
    @Autowired
    private IGameTypeRepository IGameTypeRepository;

    @Override
    public GameType create(GameType gameType) {
        return IGameTypeRepository.save(gameType);
    }

    @Override
    public List<GameType> findAll() {
        return IGameTypeRepository.findAll();
    }

    @Override
    public GameType findById(Long id) {
        return IGameTypeRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("GameType not found with id: " + id)
        );
    }

    @Override
    public void delete(Long id) {
        IGameTypeRepository.deleteById(id);
    }

    @Override
    public GameType update(GameType gameType) {
        return IGameTypeRepository.save(gameType);
    }

    @Override
    public Boolean existsById(Long id) {
        return IGameTypeRepository.existsById(id);
    }
}
