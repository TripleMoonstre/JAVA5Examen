package com.example.gameservice.Entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "participations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Participation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long gameId;
    private Long playerId;

    private Integer score;
    private Boolean victory;

}
