package com.example.gameservice.Controllers;

import com.example.gameservice.DTO.GameTypeDTO;
import com.example.gameservice.Services.IGameTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/game-types")
public class GameTypeController {

    private final IGameTypeService gameTypeService;

    public GameTypeController(IGameTypeService gameTypeService) {
        this.gameTypeService = gameTypeService;
    }

    // Create a new GameType
    @PostMapping
    public ResponseEntity<GameTypeDTO> createGameType(@RequestBody GameTypeDTO gameTypeDTO) {
        GameTypeDTO createdGameType = gameTypeService.create(gameTypeDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdGameType);
    }

    // Get all GameTypes
    @GetMapping
    public ResponseEntity<List<GameTypeDTO>> getAllGameTypes() {
        List<GameTypeDTO> gameTypes = gameTypeService.findAll();
        return ResponseEntity.ok(gameTypes);
    }

    // Get a GameType by ID
    @GetMapping("/{id}")
    public ResponseEntity<GameTypeDTO> getGameTypeById(@PathVariable Long id) {
        GameTypeDTO gameType = gameTypeService.findById(id);
        return ResponseEntity.ok(gameType);
    }

    // Update an existing GameType
    @PutMapping("/{id}")
    public ResponseEntity<GameTypeDTO> updateGameType(@PathVariable Long id, @RequestBody GameTypeDTO gameTypeDTO) {
        gameTypeDTO.setId(id);
        GameTypeDTO updatedGameType = gameTypeService.update(gameTypeDTO);
        return ResponseEntity.ok(updatedGameType);
    }

    // Delete a GameType by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGameType(@PathVariable Long id) {
        gameTypeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}