package com.example.gameservice.Services;

import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Entities.Participation;

import java.util.List;

public interface IParticipationService {
    ParticipationDTO create(ParticipationDTO participation);
    ParticipationDTO findById(Long id);
    ParticipationDTO update(ParticipationDTO participation);
    List<ParticipationDTO> findAll();
    List<ParticipationDTO> getParticipationsByGameId(Long gameId);
    void delete(Long id);
    ParticipationDTO convertToDTO(Participation participation);
    Participation convertToEntity(ParticipationDTO participationDTO);
}
