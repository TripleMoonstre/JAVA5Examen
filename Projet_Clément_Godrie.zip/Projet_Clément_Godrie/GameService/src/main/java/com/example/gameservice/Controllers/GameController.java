package com.example.gameservice.Controllers;

import com.example.gameservice.DTO.GameDTO;
import com.example.gameservice.Services.IGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/games")
public class GameController {

    @Autowired
    private IGameService gameService;

    // Créer une nouvelle partie
    @PostMapping
    public ResponseEntity<GameDTO> createGame(@RequestBody GameDTO gameDTO) {
        GameDTO createdGame = gameService.create(gameDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdGame);
    }

    // Récupérer une partie par ID
    @GetMapping("/{id}")
    public ResponseEntity<GameDTO> getGameById(@PathVariable Long id) {
        GameDTO game = gameService.findById(id);
        return ResponseEntity.ok(game);
    }

    // Supprimer une partie par ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGameById(@PathVariable Long id) {
        gameService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Iterable<GameDTO>> getAllGames() {
        Iterable<GameDTO> games = gameService.findAll();
        return ResponseEntity.ok(games);
    }

    // Mettre à jour les statistiques après une partie
    @PostMapping("/{gameId}/update-stats")
    public ResponseEntity<Void> updateStats(@PathVariable Long gameId) {
        gameService.updatePlayerStatsAfterGame(gameId);
        return ResponseEntity.noContent().build();
    }

}


