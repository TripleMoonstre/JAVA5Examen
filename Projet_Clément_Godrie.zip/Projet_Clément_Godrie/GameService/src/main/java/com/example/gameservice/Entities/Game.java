package com.example.gameservice.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;


@Entity
@Table(name = "games")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Date date;
    private Integer maxScore;
    private Long hostId;
    private Long typeId;


}
