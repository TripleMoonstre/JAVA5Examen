package com.example.gameservice.DAO.Impl;

import com.example.gameservice.DAO.IGameDAO;
import com.example.gameservice.Entities.Game;
import com.example.gameservice.Repositories.IGameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GameDAO implements IGameDAO {
    @Autowired
    private IGameRepository IGameRepository;

    @Override
    public Game create(Game game) {
        return IGameRepository.save(game);
    }

    @Override
    public Game findById(Long id) {
        return IGameRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Game not found with id: " + id)
        );
    }

    @Override
    public void deleteById(Long id) {
        IGameRepository.deleteById(id);
    }

    @Override
    public List<Game> findAll() {
        return IGameRepository.findAll();
    }


}
