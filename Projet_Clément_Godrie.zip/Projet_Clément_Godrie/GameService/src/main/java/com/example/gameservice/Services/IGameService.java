package com.example.gameservice.Services;

import com.example.gameservice.DTO.GameDTO;
import com.example.gameservice.Entities.Game;

public interface IGameService {
    GameDTO create(GameDTO gameDTO);
    GameDTO findById(Long id);
    void deleteById(Long id);
    Iterable<GameDTO> findAll();
    Boolean checkPlayerExists(Long playerId);
    Boolean validateGameData(Long hostId, Long typeId);
    GameDTO convertToDTO(Game game);
    Game convertToEntity(GameDTO gameDTO);
    void updatePlayerStatsAfterGame(Long gameId);
}

