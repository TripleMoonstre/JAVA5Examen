package com.example.gameservice.DAO;

import com.example.gameservice.Entities.GameType;

import java.util.List;

public interface IGameTypeDAO {
    GameType create(GameType gameType);
    List<GameType> findAll();
    GameType findById(Long id);
    void delete(Long id);
    GameType update(GameType gameType);
    Boolean existsById(Long id);
}
