package com.example.gameservice.DAO;

import com.example.gameservice.Entities.Game;

import java.util.List;

public interface IGameDAO {
    Game create(Game game);
    Game findById(Long id);
    void deleteById(Long id);
    List<Game> findAll();
}
