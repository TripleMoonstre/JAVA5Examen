package com.example.gameservice.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ParticipationDTO {
    private Long id;
    private Long gameId;
    private Long playerId;
    private Integer score;
    private Boolean victory = false;
}
