package com.example.gameservice.Services.Impl;

import com.example.gameservice.DAO.Impl.GameDAO;
import com.example.gameservice.DAO.Impl.GameTypeDAO;
import com.example.gameservice.DTO.GameDTO;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.DTO.PlayerStatsUpdateDTO;
import com.example.gameservice.Entities.Game;
import com.example.gameservice.Services.IGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class GameService implements IGameService {
    @Autowired
    private GameDAO gameDAO;
    @Autowired
    private GameTypeDAO gameTypeDAO;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    ParticipationService participationService;
    @Value("${player-service.url}")
    private String playerServiceURL;

    @Override
    public GameDTO create(GameDTO gameDTO) {
        if (!validateGameData(gameDTO.getHostId(), gameDTO.getTypeId())) {
            throw new RuntimeException("Invalid host or game type");
        }
        Game savedGame = gameDAO.create(convertToEntity(gameDTO));
        return convertToDTO(savedGame);
    }

    @Override
    public GameDTO findById(Long id) {
        Game game = gameDAO.findById(id);
        return convertToDTO(game);
    }

    @Override
    public void deleteById(Long id) {
        gameDAO.deleteById(id);
    }

    @Override
    public Iterable<GameDTO> findAll() {
        List<Game> games = gameDAO.findAll();
        return games.stream().map(this::convertToDTO).toList();
    }

    @Override
    public void updatePlayerStatsAfterGame(Long gameId) {
        List<ParticipationDTO> participations = participationService.getParticipationsByGameId(gameId);

        for (ParticipationDTO participation : participations) {
            String playerStatsUpdateUrl = playerServiceURL + "/api/players/" + participation.getPlayerId() + "/stats";

            PlayerStatsUpdateDTO statsUpdateDTO = new PlayerStatsUpdateDTO();
            statsUpdateDTO.setPointsGained(participation.getScore());
            statsUpdateDTO.setVictory(participation.getVictory());
            try {
                restTemplate.put(playerStatsUpdateUrl, statsUpdateDTO);
            } catch (Exception e) {
                throw new RuntimeException("Failed to update stats for player " + participation.getPlayerId(), e);
            }

        }
    }

    @Override
    public Boolean checkPlayerExists(Long hostId) {
        String url = playerServiceURL + "/api/players/" + hostId + "/exists";
        try {
            return restTemplate.getForObject(url, Boolean.class);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Boolean validateGameData(Long hostId, Long typeId) {
        boolean playerExists = checkPlayerExists(hostId);
        boolean gameTypeExists = gameTypeDAO.existsById(typeId);
        return playerExists && gameTypeExists;
    }

    @Override
    public GameDTO convertToDTO(Game game) {
        GameDTO gameDTO = new GameDTO();
        gameDTO.setId(game.getId());
        gameDTO.setDate(game.getDate());
        gameDTO.setTypeId(game.getTypeId());
        gameDTO.setMaxScore(game.getMaxScore());
        gameDTO.setHostId(game.getHostId());
        return gameDTO;
    }

    @Override
    public Game convertToEntity(GameDTO gameDTO) {
        Game game = new Game();
        game.setId(gameDTO.getId());
        game.setDate(gameDTO.getDate());
        game.setTypeId(gameDTO.getTypeId());
        game.setMaxScore(gameDTO.getMaxScore());
        game.setHostId(gameDTO.getHostId());
        return game;
    }

}
