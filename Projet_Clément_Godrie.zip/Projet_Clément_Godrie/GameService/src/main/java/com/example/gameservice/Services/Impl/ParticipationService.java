package com.example.gameservice.Services.Impl;

import com.example.gameservice.DAO.Impl.ParticipationDAO;
import com.example.gameservice.DTO.ParticipationDTO;
import com.example.gameservice.Entities.Participation;
import com.example.gameservice.Services.IParticipationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParticipationService implements IParticipationService {

    @Autowired
    private ParticipationDAO participationDAO;

    @Override
    public ParticipationDTO create(ParticipationDTO participationDTO) {
        Participation participation = participationDAO.create(convertToEntity(participationDTO));
        return  convertToDTO(participation);
    }

    @Override
    public ParticipationDTO findById(Long id) {
        Participation participation = participationDAO.findById(id);
        return convertToDTO(participation);
    }

    @Override
    public ParticipationDTO update(ParticipationDTO participationDTO) {
        Participation participation = participationDAO.update(convertToEntity(participationDTO));
        return convertToDTO(participation);
    }

    @Override
    public List<ParticipationDTO> findAll() {
        List<Participation> participations = participationDAO.findAll();
        return List.of(participations.stream().map(this::convertToDTO).toArray(ParticipationDTO[]::new));
    }

    @Override
    public void delete(Long id) {
        participationDAO.delete(id);
    }

    @Override
    public List<ParticipationDTO> getParticipationsByGameId(Long gameId) {
        List<Participation> participations = participationDAO.findByGameId(gameId);
        return participations.stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    public ParticipationDTO convertToDTO(Participation participation) {
        ParticipationDTO participationDTO = new ParticipationDTO();
        participationDTO.setId(participation.getId());
        participationDTO.setGameId(participation.getGameId());
        participationDTO.setScore(participation.getScore());
        participationDTO.setPlayerId(participation.getPlayerId());
        participationDTO.setVictory(participation.getVictory());
        return participationDTO;
    }

    @Override
    public Participation convertToEntity(ParticipationDTO participationDTO) {
        Participation participation = new Participation();
        participation.setId(participationDTO.getId());
        participation.setGameId(participationDTO.getGameId());
        participation.setScore(participationDTO.getScore());
        participation.setPlayerId(participationDTO.getPlayerId());
        participation.setVictory(participationDTO.getVictory());
        return participation;
    }

}
