package com.example.gameservice.DAO;

import com.example.gameservice.Entities.Participation;

import java.util.List;

public interface IParticipationDAO {
    Participation create(Participation participation);
    Participation findById(Long id);
    Participation update(Participation participation);
    List<Participation> findAll();
    List<Participation> findByGameId(Long gameId);
    void delete(Long id);
}
