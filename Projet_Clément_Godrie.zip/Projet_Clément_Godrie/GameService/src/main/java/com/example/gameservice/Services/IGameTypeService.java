package com.example.gameservice.Services;

import com.example.gameservice.DTO.GameTypeDTO;
import com.example.gameservice.Entities.GameType;

import java.util.List;

public interface IGameTypeService {
    GameTypeDTO create(GameTypeDTO gameType);
    List<GameTypeDTO> findAll();
    GameTypeDTO findById(Long id);
    void delete(Long id);
    GameTypeDTO update(GameTypeDTO gameType);
    GameTypeDTO convertToDTO(GameType game);
    GameType convertToEntity(GameTypeDTO gameDTO);
}
