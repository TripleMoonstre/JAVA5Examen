package com.example.gameservice.Services.Impl;

import com.example.gameservice.DAO.Impl.GameTypeDAO;
import com.example.gameservice.DTO.GameTypeDTO;
import com.example.gameservice.Entities.GameType;
import com.example.gameservice.Services.IGameTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameTypeService implements IGameTypeService {
    @Autowired
    private GameTypeDAO gameTypeDAO;
    @Override
    public GameTypeDTO create(GameTypeDTO gameTypeDTO) {
        GameType gameType = gameTypeDAO.create(convertToEntity(gameTypeDTO));
        return  convertToDTO(gameType);
    }

    @Override
    public List<GameTypeDTO> findAll() {
        List<GameType> gameTypes = gameTypeDAO.findAll();
        return List.of(gameTypes.stream().map(this::convertToDTO).toArray(GameTypeDTO[]::new));
    }

    @Override
    public GameTypeDTO findById(Long id) {
        GameType gameType = gameTypeDAO.findById(id);
        return convertToDTO(gameType);
    }

    @Override
    public void delete(Long id) {
        gameTypeDAO.delete(id);
    }

    @Override
    public GameTypeDTO update(GameTypeDTO gameTypeDTO) {
        GameType gameType = gameTypeDAO.update(convertToEntity(gameTypeDTO));
        return convertToDTO(gameType);
    }

    @Override
    public GameTypeDTO convertToDTO(GameType gameType) {
        GameTypeDTO result = new GameTypeDTO();
        result.setId(gameType.getId());
        result.setName(gameType.getName());
        result.setDescription(gameType.getDescription());
        result.setMaxPlayers(gameType.getMaxPlayers());
        return result;
    }

    @Override
    public GameType convertToEntity(GameTypeDTO gameDTO) {
        GameType result = new GameType();
        result.setId(gameDTO.getId());
        result.setName(gameDTO.getName());
        result.setDescription(gameDTO.getDescription());
        result.setMaxPlayers(gameDTO.getMaxPlayers());
        return result;
    }
}
