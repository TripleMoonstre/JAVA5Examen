package com.example.gameservice.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GameDTO {
    private Long id;
    private LocalDate date;
    private String gameType;
    private int maxScore;
    private Long hostId;
    private List<ParticipationDTO> participations;
    private Boolean is_finished;
}
