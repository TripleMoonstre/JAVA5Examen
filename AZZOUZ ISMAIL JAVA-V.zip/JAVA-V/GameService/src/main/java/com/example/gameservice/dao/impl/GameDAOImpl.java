package com.example.gameservice.dao.impl;

import com.example.gameservice.dao.GameDAO;
import com.example.gameservice.entity.Game;
import com.example.gameservice.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public class GameDAOImpl implements GameDAO {

    @Autowired
    private GameRepository gameRepository;

    @Override
    public Game save(Game game) {
        return gameRepository.save(game);
    }

    @Override
    public Game findById(Long id) {
        return gameRepository.findById(id).orElseThrow(() -> new RuntimeException("Game not found"));
    }

    @Override
    public List<Game> findAll() {
        return gameRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        gameRepository.deleteById(id);
    }

    @Override
    public List<Game> findAllByHostId(Long hostId) {
        return gameRepository.findAllByHostId(hostId);
    }

    @Override
    public void deleteAllByPlayerId(Long playerId) {
        gameRepository.deleteAllByHostId(playerId);
    }
}
