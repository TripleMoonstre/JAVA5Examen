package com.example.gameservice.service;


import com.example.gameservice.dao.ParticipationDAO;
import com.example.gameservice.dto.*;
import com.example.gameservice.entity.Game;
import com.example.gameservice.entity.Participation;
import com.example.gameservice.service.PlayerApiService.PlayerNotFoundException;
import com.example.gameservice.service.PlayerApiService.PlayerRestClientService;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@AllArgsConstructor
public class ParticipationService {
    @Autowired
    private final ParticipationDAO participationDAO;
    @Autowired
    private final GameService gameService;
    private final PlayerRestClientService playerRestClientService;

    public List<ParticipationDTO> getAllParticipationPerGame(Long gameId) {
        GameDTO game = gameService.getGameById(gameId); // Appel inter-service
        return game.getParticipations();
    }

    public ParticipationDTO registerParticipation(NewParticipationDTO participationDTO) {
        if (!playerRestClientService.checkIfPlayerExists(participationDTO.getPlayerId())) {
            throw new PlayerNotFoundException(participationDTO.getPlayerId());
        }

        Game game = gameService.getGameByIdGameObject(participationDTO.getGameId()); // Appel inter-service
        Participation participation = new Participation(
                game,
                participationDTO.getPlayerId(),
                participationDTO.getScore()
        );
        participationDAO.save(participation);
        return participation.dtoConverter();
    }

    @Transactional
    public void removeParticipationByPlayerIdAndGameId(Long playerId, Long gameId) {
        gameService.getGameById(gameId); // Vérifie si le jeu existe
        participationDAO.deleteByPlayerIdAndGameId(playerId, gameId);
    }

    public ParticipationDTO setPlayerVictory(UpdateParticipationVictory updateParticipationVictory) {
        GameDTO game = gameService.getGameById(updateParticipationVictory.getGameId()); // Appel inter-service

        if (!playerRestClientService.checkIfPlayerExists(updateParticipationVictory.getPlayerId())) {
            throw new PlayerNotFoundException(updateParticipationVictory.getPlayerId());
        }

        Participation participation = participationDAO.findByGameIdAndPlayerId(
                updateParticipationVictory.getGameId(),
                updateParticipationVictory.getPlayerId()
        );
        if (participation == null) {
            throw new EntityNotFoundException("Participation not found.");
        }

        participation.setVictory(true);
        participationDAO.save(participation);
        return participation.dtoConverter();
    }

    public ParticipationDTO setPlayerScore(UpdateParticipationScoreDTO updateParticipationScoreDTO) {
        gameService.getGameById(updateParticipationScoreDTO.getGameId()); // Vérifie si le jeu existe
        if (!playerRestClientService.checkIfPlayerExists(updateParticipationScoreDTO.getPlayerId())) {
            throw new PlayerNotFoundException(updateParticipationScoreDTO.getPlayerId());
        }
        Participation participation = participationDAO.findByGameIdAndPlayerId(
                updateParticipationScoreDTO.getGameId(),
                updateParticipationScoreDTO.getPlayerId()
        );
        if (participation == null) {
            throw new EntityNotFoundException("Participation not found.");
        }

        participation.setScore(updateParticipationScoreDTO.getScore());
        participationDAO.save(participation);
        return participation.dtoConverter();
    }

    public List<ParticipationDTO> getParticipationsByPlayerId(Long playerId) {
        if (!playerRestClientService.checkIfPlayerExists(playerId)) {
            throw new PlayerNotFoundException(playerId);
        }
        return participationDAO.findAllByPlayerId(playerId)
                .stream()
                .map(Participation::dtoConverter)
                .toList();
    }

    public void removeAllPlayerParticipations(Long playerId) {
        if (!playerRestClientService.checkIfPlayerExists(playerId)) {
            throw new PlayerNotFoundException(playerId);
        }
        participationDAO.deleteByPlayerId(playerId);
    }
}
