package com.example.gameservice.controller;

import com.example.gameservice.dto.*;
import com.example.gameservice.service.GameService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/games")
public class GameController {

    @Autowired
    private GameService gameService;

    // Retrieve a list of all games
    @GetMapping
    public List<GameDTO> getAllGames() {
        return gameService.listAllGame();
    }

    // Retrieve details of a specific game by its ID
    @GetMapping("/{id}")
    public GameDTO getGameById(@PathVariable Long id) {
        return gameService.getGameById(id);
    }

    // Retrieve all games hosted by a specific host
    @GetMapping("/allplayergame/{hostId}")
    public List<GameDTO> getAllGamesByHostId(@PathVariable Long hostId) {
        return gameService.getAllGameByHostId(hostId);
    }

    // Check if a game is finished
    @GetMapping("/isgamefinished/{gameId}")
    public Boolean isGameFinished(@PathVariable Long gameId) {
        return gameService.isGameFinished(gameId);
    }

    // Create a new game
    @PostMapping("/creategame")
    public GameDTO createGame(@RequestBody NewGameDTO newGameDTO) {
        return gameService.createGame(newGameDTO);
    }

    // Mark a game as finished
    @PostMapping("/finishgame/{id}")
    public GameDTO finishGame(@PathVariable Long id) {
        return gameService.finishGame(id);

    }

    // Delete a game by its ID
    @DeleteMapping("/deletegame/{id}")
    public void deleteGame(@PathVariable Long id) {
        gameService.deleteGame(id);
    }
    @DeleteMapping("/deleteAllPlayerGames/{playerId}")
    public void deleteAllPlayerGames(@PathVariable Long playerId) {
        gameService.deleteAllGamesHostByPlayer(playerId);
    }

    // Update the maximum score of a game
    @PutMapping("/updategameMaxScore/{id}")
    public GameDTO updateGameMaxScore(@PathVariable Long id, @RequestBody UpdateGameMaxScoreDTO updatedGame) {
        return gameService.updateGameMaxScore(id, updatedGame);
    }

    // Update the host of a game
    @PutMapping("/updateGameHost/{id}")
    public GameDTO updateGameHost(@PathVariable Long id, @RequestBody UpdateGameHostDTO updatedGame) {
        return gameService.updateGameHost(id, updatedGame);
    }

}