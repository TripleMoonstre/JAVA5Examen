package com.example.gameservice.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateGameHostDTO {
    private Long newHostId;
}
