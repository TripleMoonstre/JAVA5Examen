package com.example.gameservice.service.PlayerApiService;

public class PlayerNotFoundException extends RuntimeException {
    public PlayerNotFoundException(Long playerId) {
        super("Player with ID: " + playerId + " do not exist.");
    }
}
