package com.example.gameservice.controller;

import com.example.gameservice.dto.*;
import com.example.gameservice.service.ParticipationService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/participation")
public class ParticipationController {

    @Autowired
    private ParticipationService participationService;

    // Retrieve all participations of a specific player
    @GetMapping("/getplayerparticipation/{playerId}")
    public List<ParticipationDTO> getParticipationByPlayerId(@PathVariable Long playerId) {
        return participationService.getParticipationsByPlayerId(playerId);
    }

    // Retrieve all participations for a specific game
    @GetMapping("/getgameparticipation/{gameId}")
    public List<ParticipationDTO> getParticipationByGameId(@PathVariable Long gameId) {
        return participationService.getAllParticipationPerGame(gameId);
    }

    // Register a new participation
    @PostMapping
    public ParticipationDTO registerParticipation(@RequestBody NewParticipationDTO participationDTO) {
        return participationService.registerParticipation(participationDTO);
    }

    // Update a player's score in a participation
    @PatchMapping("/setPlayerScore")
    public ParticipationDTO updatePlayerParticipationScore(@RequestBody UpdateParticipationScoreDTO participationDTO) {
        return participationService.setPlayerScore(participationDTO);
    }

    // Update a player's victory status in a participation
    @PatchMapping("/setPlayerWinner")
    public ParticipationDTO updatePlayerParticipationVictory(@RequestBody UpdateParticipationVictory participationDTO) {
        return participationService.setPlayerVictory(participationDTO);
    }

    // Delete a participation for a specific player in a specific game
    @DeleteMapping("/{gameId}/{playerId}")
    public void deleteParticipationByPlayerIdAndGameId(@PathVariable Long playerId, @PathVariable Long gameId) {
        participationService.removeParticipationByPlayerIdAndGameId(playerId, gameId);
    }
    @DeleteMapping("/{playerId}")
    public void deleteParticipationByPlayerIdAndGameId(@PathVariable Long playerId) {
        participationService.removeAllPlayerParticipations(playerId);
    }

}
