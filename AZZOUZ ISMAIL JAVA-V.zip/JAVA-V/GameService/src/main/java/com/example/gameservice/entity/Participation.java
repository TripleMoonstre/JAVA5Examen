package com.example.gameservice.entity;
import com.example.gameservice.dto.ParticipationDTO;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Set;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "participations")
public class Participation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "game_id", nullable = false)
    private Game game;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(nullable = false)
    private Integer score;

    @Column(nullable = false)
    private Boolean victory;

    public Participation(Game game, Long playerId, Integer score) {
        this.game = game;
        this.playerId = playerId;
        this.score = score;
        this.victory = false;
    }

    public ParticipationDTO dtoConverter(){
        return new ParticipationDTO(
                this.getId(),
                this.getGame().getId(),
                this.getPlayerId(),
                this.getScore(),
                this.getVictory()
        );
    }
}
