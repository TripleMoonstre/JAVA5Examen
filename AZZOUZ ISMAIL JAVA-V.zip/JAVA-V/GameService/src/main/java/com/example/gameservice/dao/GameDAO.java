package com.example.gameservice.dao;

import com.example.gameservice.entity.Game;
import java.util.Optional;
import java.util.List;

public interface GameDAO {
    Game save(Game game);
    Game findById(Long id);
    List<Game> findAll();
    void deleteById(Long id);
    List<Game> findAllByHostId(Long hostId);

    void deleteAllByPlayerId(Long playerId);
}
