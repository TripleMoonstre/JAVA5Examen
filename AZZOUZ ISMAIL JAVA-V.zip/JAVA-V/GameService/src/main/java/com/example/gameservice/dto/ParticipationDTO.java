package com.example.gameservice.dto;
import java.time.LocalDate;
import java.util.Set;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ParticipationDTO {
    private Long id;
    private Long gameId;
    private Long playerId;
    private Integer score;
    private Boolean victory;

    public ParticipationDTO(Long gameId, Long playerId, Integer score) {
        this.gameId = gameId;
        this.playerId = playerId;
        this.score = score;

    }
}
