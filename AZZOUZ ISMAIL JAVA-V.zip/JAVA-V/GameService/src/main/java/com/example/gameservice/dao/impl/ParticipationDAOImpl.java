package com.example.gameservice.dao.impl;

import com.example.gameservice.dao.ParticipationDAO;
import com.example.gameservice.entity.Participation;
import com.example.gameservice.repository.ParticipationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ParticipationDAOImpl implements ParticipationDAO {

    @Autowired
    private ParticipationRepository participationRepository;

    @Override
    public Participation save(Participation participation) {
        return participationRepository.save(participation);
    }

    @Override
    public Optional<Participation> findById(Long id) {
        return participationRepository.findById(id);
    }

    @Override
    public Participation findByGameIdAndPlayerId(Long gameId, Long playerId) {
        return participationRepository.findParticipationByGame_IdAndPlayerId(gameId,playerId);
    }

    @Override
    public List<Participation> findAllByGameId(Long gameId) {
        return participationRepository.findByGameId(gameId);
    }

    @Override
    public List<Participation> findAllByPlayerId(Long playerId) {
        return participationRepository.findByPlayerId(playerId);
    }

    @Override
    public void deleteById(Long id) {
        participationRepository.deleteById(id);
    }

    @Override
    public void deleteByPlayerIdAndGameId(Long playerId, Long gameId) {
        participationRepository.deleteParticipationsByPlayerIdAndGame_Id(playerId,gameId);

    }

    @Override
    public void deleteByPlayerId(Long playerId) {
        participationRepository.deleteAllByPlayerId(playerId);
    }

}
