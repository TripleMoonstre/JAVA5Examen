package com.example.gameservice.dao;

import com.example.gameservice.entity.Participation;

import java.util.List;
import java.util.Optional;

public interface ParticipationDAO {
    Participation save(Participation participation);
    Optional<Participation> findById(Long id);
    Participation findByGameIdAndPlayerId(Long gameId, Long playerId);
    List<Participation> findAllByGameId(Long gameId);
    List<Participation> findAllByPlayerId(Long playerId);
    void deleteById(Long id);
    void deleteByPlayerIdAndGameId(Long playerId, Long gameId);
    void deleteByPlayerId(Long playerId);
}
