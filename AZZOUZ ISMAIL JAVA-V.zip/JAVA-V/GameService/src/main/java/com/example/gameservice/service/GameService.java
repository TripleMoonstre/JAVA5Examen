package com.example.gameservice.service;
import com.example.gameservice.dao.GameDAO;
import com.example.gameservice.dto.*;
import com.example.gameservice.entity.Game;
import com.example.gameservice.service.PlayerApiService.PlayerNotFoundException;
import com.example.gameservice.service.PlayerApiService.PlayerRestClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
@AllArgsConstructor
@Service
public class GameService {

    @Autowired
    private GameDAO gameDAO;

    private PlayerRestClientService playerClient;

    public List<GameDTO> listAllGame() {
        return gameDAO.findAll().stream()
                .map(Game::dtoConverter)
                .collect(Collectors.toList());
    }

    public List<GameDTO> getAllGameByHostId(Long hostId) {
        if (hostId == null || hostId <= 0) {
            throw new IllegalArgumentException("Host ID must be a positive value.");
        }
        if(!playerClient.checkIfPlayerExists(hostId)){
            throw new PlayerNotFoundException(hostId);
        }

        return gameDAO.findAllByHostId(hostId).stream()
                .map(Game::dtoConverter).toList();
    }

    public GameDTO createGame(NewGameDTO gameDTO) {
        if (gameDTO == null) {
            throw new IllegalArgumentException("Game data cannot be null.");
        }
        if (gameDTO.getGameType() == null || gameDTO.getGameType().isEmpty()) {
            throw new IllegalArgumentException("Game type cannot be null or empty.");
        }
        if (gameDTO.getHostId() == null || gameDTO.getHostId() <= 0) {
            throw new IllegalArgumentException("Host ID must be a positive value.");
        }
        if(!playerClient.checkIfPlayerExists(gameDTO.getHostId())){
            throw new PlayerNotFoundException(gameDTO.getHostId());
        }
        Game new_game = new Game(gameDTO.getGameType(), gameDTO.getMaxScore(), gameDTO.getHostId());
        gameDAO.save(new_game);
        return new_game.dtoConverter();
    }
    @Transactional
    public void deleteGame(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }

        if (gameDAO.findById(id) == null) { //Cannot happen in theory because Of ThrowError but still good to add this check
            throw new EntityNotFoundException("Game with the given ID does not exist.");
        }

        gameDAO.deleteById(id);
    }

    public GameDTO getGameById(Long gameId) {
        if (gameId == null || gameId <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }

        Game game = gameDAO.findById(gameId);
        if (game == null) {
            throw new EntityNotFoundException("Game not found.");
        }

        return game.dtoConverter();
    }
    public Game getGameByIdGameObject(long id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }
        Game game = gameDAO.findById(id);
        if (game == null) {
            throw new EntityNotFoundException("Game not found.");
        }
        return game;
    }
    public GameDTO updateGameMaxScore(Long id, UpdateGameMaxScoreDTO updatedGame) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }
        if (updatedGame == null) {
            throw new IllegalArgumentException("Update data cannot be null.");
        }
        if (updatedGame.getNewMaxScore() <= 0) {
            throw new IllegalArgumentException("Max score must be a positive value.");
        }
        Game game_Before = gameDAO.findById(id);
        if (game_Before == null) {
            throw new EntityNotFoundException("Game not found.");
        }
        game_Before.setMaxScore(updatedGame.getNewMaxScore());
        gameDAO.save(game_Before);
        return game_Before.dtoConverter();
    }

    public GameDTO updateGameHost(Long id, UpdateGameHostDTO updatedGame) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }
        Game game_Before = gameDAO.findById(id);
        if (game_Before == null) {
            throw new EntityNotFoundException("Game not found.");
        }
        if (updatedGame == null) {
            throw new IllegalArgumentException("Update data cannot be null.");
        }
        if (updatedGame.getNewHostId() == null || updatedGame.getNewHostId() <= 0) {
            throw new IllegalArgumentException("Host ID must be a positive value.");
        }
        if(!playerClient.checkIfPlayerExists(updatedGame.getNewHostId())){
            throw new PlayerNotFoundException(updatedGame.getNewHostId());
        }
        game_Before.setHostId(updatedGame.getNewHostId());
        gameDAO.save(game_Before);
        return game_Before.dtoConverter();
    }

    public GameDTO finishGame(Long gameId) {
        if (gameId == null || gameId <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }
        Game game = gameDAO.findById(gameId);
        if (game == null) {
            throw new EntityNotFoundException("Game not found.");
        }
        game.getParticipations().forEach(participation -> {
            Long playerId = participation.getPlayerId();
            if (playerClient.checkIfPlayerExists(playerId)) {
                PlayerScoreDTO scoreUpdate = new PlayerScoreDTO();
                scoreUpdate.setPlayerscore(participation.getScore());
                playerClient.updatePlayerScore(playerId, scoreUpdate);
            }  //DO NOTHING THROWING AN ERROR WOULD CANCEL THE WHOLE PROCESS ITS BETTER TO JUST NOT ACTUALISE THE BAD ONE
        });
        game.setIs_finished(true);
        return gameDAO.save(game).dtoConverter();
    }

    public Boolean isGameFinished(Long gameId) {
        if (gameId == null || gameId <= 0) {
            throw new IllegalArgumentException("Game ID must be a positive value.");
        }
        Game game = gameDAO.findById(gameId);
        if (game == null) {
            throw new EntityNotFoundException("Game not found.");
        }
        return game.getIs_finished();
    }
    public void deleteAllGamesHostByPlayer(Long playerId){
        gameDAO.deleteAllByPlayerId(playerId);
    }
}