package com.example.gameservice.dto;
import java.time.LocalDate;
import java.util.Set;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateParticipationVictory {
    private Long gameId;
    private Long playerId;
}
