package com.example.gameservice.service.PlayerApiService;


import com.example.gameservice.service.PlayerScoreDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class PlayerRestClientService {

    @Autowired
    private RestTemplate restTemplate;

    private final String PLAYER_SERVICE_URL = "http://localhost:9999/players";

    public boolean checkIfPlayerExists(Long playerId) {
        String url = PLAYER_SERVICE_URL + "/" + playerId;
        try {
            //restTemplate.getForEntity(url, Void.class).getStatusCode(); // Appel à l'API
            if(restTemplate.getForEntity(url, Void.class).getStatusCodeValue() == 200){
                return true; // Si le code 200 est renvoyé
            }
            return false;

        } catch (HttpClientErrorException.NotFound e) {
            throw new PlayerNotFoundException(playerId);

        } catch (Exception e) {
            throw new RuntimeException("Error while calling PlayerService: " + e.getMessage() + " Please Check URL or if service is UP");
        }

    }

    public void updatePlayerScore(Long playerId, PlayerScoreDTO playerScoreDTO) {
        String url = PLAYER_SERVICE_URL + "/updatePlayerScore/" + playerId;
        restTemplate.patchForObject(url, playerScoreDTO, Void.class);
    }


}
