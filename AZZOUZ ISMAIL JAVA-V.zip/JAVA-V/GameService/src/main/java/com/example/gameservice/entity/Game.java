package com.example.gameservice.entity;

import com.example.gameservice.dto.GameDTO;
import com.example.gameservice.dto.ParticipationDTO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Table(name = "games")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, updatable = false)
    private LocalDate date;
    @Column(name = "game_type", nullable = false)
    private String gameType;
    @Column(name = "max_score", nullable = false)
    private int maxScore;
    @Column(name = "host_id", nullable = false)
    private Long hostId;
    @Column(name = "is_finished", nullable = false)
    private Boolean is_finished;

    @OneToMany(mappedBy = "game", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Participation> participations;
    public Game(String gameType, int maxScore, Long hostId) {
        this.gameType = gameType;
        this.maxScore = maxScore;
        this.hostId = hostId;
        this.participations = new ArrayList<>();
    }
    @PrePersist
    private void onCreate() {
        this.date = LocalDate.now();
        this.is_finished = false;
    }
    public GameDTO dtoConverter(){
        return new GameDTO(
          this.id,
          this.date,
          this.gameType,
          this.maxScore, this.hostId,
                this.getParticipations().stream()
                        .map(Participation::dtoConverter)
                        .collect(Collectors.toList()),this.is_finished

        );
    }
}
