package com.example.gameservice.repository;

import com.example.gameservice.entity.Participation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ParticipationRepository extends JpaRepository<Participation, Long> {
    List<Participation> findByGameId(Long gameId);
    List<Participation> findAllByGameId(Long gameId); // Méthode personnalisée pour obtenir les participations d'un jeu
    List<Participation> findByPlayerId(Long playerId);
    void deleteParticipationsByPlayerIdAndGame_Id(Long playerId, Long gameId);
    Participation findParticipationByGame_IdAndPlayerId(Long gameId, Long playerId);
    void deleteAllByPlayerId(Long playerId);
}
