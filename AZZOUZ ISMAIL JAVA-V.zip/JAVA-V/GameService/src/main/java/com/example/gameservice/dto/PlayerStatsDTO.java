package com.example.gameservice.dto;
import lombok.AllArgsConstructor;
@AllArgsConstructor

public class PlayerStatsDTO {
    private Integer score;
    private Boolean victory;



}
