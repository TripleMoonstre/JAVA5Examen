package com.example.gameservice;

import com.example.gameservice.dao.ParticipationDAO;
import com.example.gameservice.dto.*;
import com.example.gameservice.entity.Game;
import com.example.gameservice.entity.Participation;
import com.example.gameservice.service.GameService;
import com.example.gameservice.service.ParticipationService;
import com.example.gameservice.service.PlayerApiService.PlayerRestClientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ParticipationServiceTest {

    @Mock
    private ParticipationDAO participationDAO;

    @Mock
    private GameService gameService;

    @Mock
    private PlayerRestClientService playerRestClientService;

    @InjectMocks
    private ParticipationService participationService;

    private Participation participation;
    private Game game;

    @BeforeEach
    void setUp() {
        game = new Game("Chess", 100, 1L);
        game.setId(1L);
        participation = new Participation(game, 1L, 50);
        participation.setId(1L);
    }

    @Test
    void testGetAllParticipationPerGame() {
        GameDTO gameDTO = new GameDTO(1L, null, "Chess", 100, 1L, List.of(), false);

        when(gameService.getGameById(1L)).thenReturn(gameDTO);

        List<ParticipationDTO> result = participationService.getAllParticipationPerGame(1L);

        assertNotNull(result);
        verify(gameService, times(1)).getGameById(1L);
    }

    @Test
    void testRegisterParticipation() {
        NewParticipationDTO newParticipationDTO = new NewParticipationDTO(1L, 1L, 50);

        when(playerRestClientService.checkIfPlayerExists(1L)).thenReturn(true);
        when(gameService.getGameByIdGameObject(1L)).thenReturn(game);
        when(participationDAO.save(any(Participation.class))).thenReturn(participation);

        ParticipationDTO result = participationService.registerParticipation(newParticipationDTO);

        assertNotNull(result);
        assertEquals(participation.getPlayerId(), result.getPlayerId());
        verify(participationDAO, times(1)).save(any(Participation.class));
    }

    @Test
    void testRemoveParticipationByPlayerIdAndGameId() {
        doNothing().when(participationDAO).deleteByPlayerIdAndGameId(1L, 1L);

        assertDoesNotThrow(() -> participationService.removeParticipationByPlayerIdAndGameId(1L, 1L));

        verify(participationDAO, times(1)).deleteByPlayerIdAndGameId(1L, 1L);
    }

    @Test
    void testSetPlayerVictory() {
        UpdateParticipationVictory updateVictory = new UpdateParticipationVictory(1L, 1L);

        when(gameService.getGameById(1L)).thenReturn(new GameDTO());
        when(playerRestClientService.checkIfPlayerExists(1L)).thenReturn(true);
        when(participationDAO.findByGameIdAndPlayerId(1L, 1L)).thenReturn(participation);
        when(participationDAO.save(any(Participation.class))).thenReturn(participation);

        ParticipationDTO result = participationService.setPlayerVictory(updateVictory);

        assertNotNull(result);
        assertTrue(result.getVictory());
        verify(participationDAO, times(1)).save(any(Participation.class));
    }

    @Test
    void testSetPlayerScore() {
        UpdateParticipationScoreDTO updateScore = new UpdateParticipationScoreDTO(1L, 1L, 75);

        when(gameService.getGameById(1L)).thenReturn(new GameDTO());
        when(playerRestClientService.checkIfPlayerExists(1L)).thenReturn(true);
        when(participationDAO.findByGameIdAndPlayerId(1L, 1L)).thenReturn(participation);
        when(participationDAO.save(any(Participation.class))).thenReturn(participation);

        ParticipationDTO result = participationService.setPlayerScore(updateScore);

        assertNotNull(result);
        assertEquals(updateScore.getScore(), result.getScore());
        verify(participationDAO, times(1)).save(any(Participation.class));
    }

    @Test
    void testGetParticipationsByPlayerId() {
        when(playerRestClientService.checkIfPlayerExists(1L)).thenReturn(true);
        when(participationDAO.findAllByPlayerId(1L)).thenReturn(List.of(participation));

        List<ParticipationDTO> result = participationService.getParticipationsByPlayerId(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(participationDAO, times(1)).findAllByPlayerId(1L);
    }

    @Test
    void testRemoveAllPlayerParticipations() {
        when(playerRestClientService.checkIfPlayerExists(1L)).thenReturn(true); // Ajout du mock

        doNothing().when(participationDAO).deleteByPlayerId(1L);

        assertDoesNotThrow(() -> participationService.removeAllPlayerParticipations(1L));

        verify(participationDAO, times(1)).deleteByPlayerId(1L);
        verify(playerRestClientService, times(1)).checkIfPlayerExists(1L); // Vérification du mock
    }

}
