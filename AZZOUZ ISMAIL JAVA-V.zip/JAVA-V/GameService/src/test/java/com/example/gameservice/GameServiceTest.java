package com.example.gameservice.service;

import com.example.gameservice.dao.GameDAO;
import com.example.gameservice.dto.*;
import com.example.gameservice.entity.Game;
import com.example.gameservice.service.PlayerApiService.PlayerRestClientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameServiceTest {

    @Mock
    private GameDAO gameDAO;

    @Mock
    private PlayerRestClientService playerClient;

    @InjectMocks
    private GameService gameService;

    private Game game;

    @BeforeEach
    void setUp() {
        game = new Game("Chess", 100, 1L);
        game.setId(1L);
    }

    @Test
    void testListAllGame() {
        when(gameDAO.findAll()).thenReturn(List.of(game));

        List<GameDTO> result = gameService.listAllGame();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(game.getGameType(), result.get(0).getGameType());
        verify(gameDAO, times(1)).findAll();
    }

    @Test
    void testGetGameById() {
        when(gameDAO.findById(1L)).thenReturn(game);

        GameDTO result = gameService.getGameById(1L);

        assertNotNull(result);
        assertEquals(game.getId(), result.getId());
        verify(gameDAO, times(1)).findById(1L);
    }

    @Test
    void testCreateGame() {
        NewGameDTO newGameDTO = new NewGameDTO("Chess", 100, 1L);

        when(playerClient.checkIfPlayerExists(1L)).thenReturn(true);
        when(gameDAO.save(any(Game.class))).thenReturn(game);

        GameDTO result = gameService.createGame(newGameDTO);

        assertNotNull(result);
        assertEquals(game.getGameType(), result.getGameType());
        verify(gameDAO, times(1)).save(any(Game.class));
    }

    @Test
    void testDeleteGame() {
        when(gameDAO.findById(1L)).thenReturn(game);

        doNothing().when(gameDAO).deleteById(1L);

        assertDoesNotThrow(() -> gameService.deleteGame(1L));

        verify(gameDAO, times(1)).deleteById(1L);
    }

    @Test
    void testUpdateGameMaxScore() {
        UpdateGameMaxScoreDTO updateDTO = new UpdateGameMaxScoreDTO(200);

        when(gameDAO.findById(1L)).thenReturn(game);
        when(gameDAO.save(any(Game.class))).thenReturn(game);

        GameDTO result = gameService.updateGameMaxScore(1L, updateDTO);

        assertNotNull(result);
        assertEquals(updateDTO.getNewMaxScore(), result.getMaxScore());
        verify(gameDAO, times(1)).save(any(Game.class));
    }

    @Test
    void testFinishGame() {
        game.setParticipations(List.of());

        when(gameDAO.findById(1L)).thenReturn(game);
        when(gameDAO.save(any(Game.class))).thenReturn(game);

        GameDTO result = gameService.finishGame(1L);

        assertNotNull(result);
        assertTrue(result.getIs_finished());
        verify(gameDAO, times(1)).save(any(Game.class));
    }
}
