package com.example.gameservice;

import com.example.gameservice.controller.GameController;
import com.example.gameservice.dto.*;
import com.example.gameservice.service.GameService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GameController.class)
public class GameControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GameService gameService;

    @Test
    void testGetAllGames() throws Exception {
        GameDTO gameDTO = new GameDTO(1L, null, "Chess", 100, 1L, null, false);
        when(gameService.listAllGame()).thenReturn(List.of(gameDTO));

        mockMvc.perform(get("/games"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].gameType").value("Chess"));

        verify(gameService, times(1)).listAllGame();
    }

    @Test
    void testGetGameById() throws Exception {
        GameDTO gameDTO = new GameDTO(1L, null, "Chess", 100, 1L, null, false);
        when(gameService.getGameById(1L)).thenReturn(gameDTO);

        mockMvc.perform(get("/games/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.gameType").value("Chess"));

        verify(gameService, times(1)).getGameById(1L);
    }

    @Test
    void testCreateGame() throws Exception {
        GameDTO gameDTO = new GameDTO(1L, null, "Chess", 100, 1L, null, false);
        NewGameDTO newGameDTO = new NewGameDTO("Chess", 100, 1L);
        when(gameService.createGame(any(NewGameDTO.class))).thenReturn(gameDTO);

        mockMvc.perform(post("/games/creategame")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"gameType\":\"Chess\",\"maxScore\":100,\"hostId\":1}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.gameType").value("Chess"));

        verify(gameService, times(1)).createGame(any(NewGameDTO.class));
    }

    @Test
    void testDeleteGame() throws Exception {
        doNothing().when(gameService).deleteGame(1L);

        mockMvc.perform(delete("/games/deletegame/1"))
                .andExpect(status().isOk());

        verify(gameService, times(1)).deleteGame(1L);
    }

    @Test
    void testUpdateGameMaxScore() throws Exception {
        GameDTO gameDTO = new GameDTO(1L, null, "Chess", 100, 1L, null, false);
        UpdateGameMaxScoreDTO updateDTO = new UpdateGameMaxScoreDTO(200);
        when(gameService.updateGameMaxScore(eq(1L), any(UpdateGameMaxScoreDTO.class))).thenReturn(gameDTO);

        mockMvc.perform(put("/games/updategameMaxScore/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"newMaxScore\":200}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.gameType").value("Chess"));

        verify(gameService, times(1)).updateGameMaxScore(eq(1L), any(UpdateGameMaxScoreDTO.class));
    }
}
