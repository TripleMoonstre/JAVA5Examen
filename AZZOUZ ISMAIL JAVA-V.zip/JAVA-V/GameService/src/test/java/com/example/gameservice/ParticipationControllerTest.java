package com.example.gameservice;

import com.example.gameservice.controller.ParticipationController;
import com.example.gameservice.dto.*;
import com.example.gameservice.service.ParticipationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ParticipationController.class)
public class ParticipationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ParticipationService participationService;

    @Test
    void testGetParticipationByPlayerId() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO(1L, 1L, 1L, 50, false);
        when(participationService.getParticipationsByPlayerId(1L)).thenReturn(List.of(participationDTO));

        mockMvc.perform(get("/participation/getplayerparticipation/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].score").value(50));

        verify(participationService, times(1)).getParticipationsByPlayerId(1L);
    }

    @Test
    void testGetParticipationByGameId() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO(1L, 1L, 1L, 50, false);
        when(participationService.getAllParticipationPerGame(1L)).thenReturn(List.of(participationDTO));

        mockMvc.perform(get("/participation/getgameparticipation/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].score").value(50));

        verify(participationService, times(1)).getAllParticipationPerGame(1L);
    }

    @Test
    void testRegisterParticipation() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO(1L, 1L, 1L, 50, false);
        NewParticipationDTO newParticipationDTO = new NewParticipationDTO(1L, 1L, 50);
        when(participationService.registerParticipation(any(NewParticipationDTO.class))).thenReturn(participationDTO);

        mockMvc.perform(post("/participation")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"gameId\":1,\"playerId\":1,\"score\":50}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.score").value(50));

        verify(participationService, times(1)).registerParticipation(any(NewParticipationDTO.class));
    }

    @Test
    void testUpdatePlayerParticipationScore() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO(1L, 1L, 1L, 50, false);
        UpdateParticipationScoreDTO updateDTO = new UpdateParticipationScoreDTO(1L, 1L, 75);
        when(participationService.setPlayerScore(any(UpdateParticipationScoreDTO.class))).thenReturn(participationDTO);

        mockMvc.perform(patch("/participation/setPlayerScore")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"gameId\":1,\"playerId\":1,\"score\":75}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.score").value(50));

        verify(participationService, times(1)).setPlayerScore(any(UpdateParticipationScoreDTO.class));
    }

    @Test
    void testUpdatePlayerParticipationVictory() throws Exception {
        ParticipationDTO participationDTO = new ParticipationDTO(1L, 1L, 1L, 50, false);
        UpdateParticipationVictory updateVictory = new UpdateParticipationVictory(1L, 1L);
        when(participationService.setPlayerVictory(any(UpdateParticipationVictory.class))).thenReturn(participationDTO);

        mockMvc.perform(patch("/participation/setPlayerWinner")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"gameId\":1,\"playerId\":1}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.victory").value(false));

        verify(participationService, times(1)).setPlayerVictory(any(UpdateParticipationVictory.class));
    }

    @Test
    void testDeleteParticipationByPlayerIdAndGameId() throws Exception {
        doNothing().when(participationService).removeParticipationByPlayerIdAndGameId(1L, 1L);

        mockMvc.perform(delete("/participation/1/1"))
                .andExpect(status().isOk());

        verify(participationService, times(1)).removeParticipationByPlayerIdAndGameId(1L, 1L);
    }

    @Test
    void testDeleteAllPlayerParticipations() throws Exception {
        doNothing().when(participationService).removeAllPlayerParticipations(1L);

        mockMvc.perform(delete("/participation/1"))
                .andExpect(status().isOk());

        verify(participationService, times(1)).removeAllPlayerParticipations(1L);
    }
}
