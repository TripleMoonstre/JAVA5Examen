package com.example.playerservice;

import com.example.playerservice.Controller.FriendController;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.Service.FriendService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(FriendController.class)
public class FriendControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FriendService friendService;

    @Test
    void testAddFriend() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO(1L, "John Doe", "jdoe", "john.doe@example.com", 1, 100, null);
        when(friendService.addFriend(1L, 2L)).thenReturn(playerDTO);

        mockMvc.perform(post("/friends/add/1/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"));

        verify(friendService, times(1)).addFriend(1L, 2L);
    }

    @Test
    void testCheckFriendship() throws Exception {
        when(friendService.arePlayersFriends(1L, 2L)).thenReturn(true);

        mockMvc.perform(get("/friends/checkfriendship/1/2"))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));

        verify(friendService, times(1)).arePlayersFriends(1L, 2L);
    }

    @Test
    void testGetFriendsList() throws Exception {
        FriendDTO friendDTO = new FriendDTO("Jane Smith", "jane.smith@example.com", "jsmith", 1, 50);
        when(friendService.getPlayerFriendList(1L)).thenReturn(List.of(friendDTO));

        mockMvc.perform(get("/friends/friendslist/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Jane Smith"));

        verify(friendService, times(1)).getPlayerFriendList(1L);
    }

    @Test
    void testEndFriendship() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO(1L, "John Doe", "jdoe", "john.doe@example.com", 1, 100, null);
        when(friendService.removeFriend(1L, 2L)).thenReturn(playerDTO);

        mockMvc.perform(patch("/friends/endFriendShip/1/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"));

        verify(friendService, times(1)).removeFriend(1L, 2L);
    }
}
