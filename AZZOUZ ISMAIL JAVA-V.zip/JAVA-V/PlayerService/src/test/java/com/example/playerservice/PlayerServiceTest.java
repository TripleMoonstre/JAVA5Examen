package com.example.playerservice.Service;

import com.example.playerservice.DAO.FriendDAO;
import com.example.playerservice.DAO.PlayerDAO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerScoreDTO;
import com.example.playerservice.DTO.newPlayerDTO;
import com.example.playerservice.Entity.Player;
import com.example.playerservice.Service.GameApiService.GameRestClientService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerServiceTest {

    @Mock
    private PlayerDAO playerDAO;

    @Mock
    private FriendDAO friendDAO;

    @Mock
    private GameRestClientService gameRestClientService;

    @InjectMocks
    private PlayerService playerService;

    private Player player;

    @BeforeEach
    void setUp() {
        player = new Player("John Doe", "jdoe", "john.doe@example.com");
        player.setId(1L);
    }

    @Test
    void testAddPlayer() {
        newPlayerDTO newPlayer = new newPlayerDTO("John Doe", "jdoe", "john.doe@example.com");

        when(playerDAO.save(any(Player.class))).thenReturn(player);

        PlayerDTO result = playerService.addPlayer(newPlayer);

        assertNotNull(result);
        assertEquals(player.getName(), result.getName());
        verify(playerDAO, times(1)).save(any(Player.class));
    }

    @Test
    void testGetPlayer() {
        when(playerDAO.findById(1L)).thenReturn(player);

        PlayerDTO result = playerService.getPlayer(1L);

        assertNotNull(result);
        assertEquals(player.getId(), result.getId());
        assertEquals(player.getName(), result.getName());
        verify(playerDAO, times(1)).findById(1L);
    }

    @Test
    void testListPlayers() {
        when(playerDAO.findAll()).thenReturn(List.of(player));

        List<PlayerDTO> result = playerService.listPlayers();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(player.getName(), result.get(0).getName());
        verify(playerDAO, times(1)).findAll();
    }

    @Test
    void testDeletePlayer() {
        when(playerDAO.findById(1L)).thenReturn(player);

        doNothing().when(friendDAO).deleteByPlayerId(1L);
        doNothing().when(playerDAO).deleteById(1L);
        doNothing().when(gameRestClientService).playerDataErazer(1L);

        assertDoesNotThrow(() -> playerService.deletePlayer(1L));

        verify(friendDAO, times(1)).deleteByPlayerId(1L);
        verify(playerDAO, times(1)).deleteById(1L);
        verify(gameRestClientService, times(1)).playerDataErazer(1L);
    }

    @Test
    void testUpdatePlayerScore() {
        PlayerScoreDTO playerScoreDTO = new PlayerScoreDTO(100);

        when(playerDAO.findById(1L)).thenReturn(player);
        when(playerDAO.save(any(Player.class))).thenReturn(player);

        PlayerScoreDTO result = playerService.updatePlayerScore(1L, playerScoreDTO);

        assertNotNull(result);
        assertEquals(100, result.getPlayerscore());
        verify(playerDAO, times(1)).findById(1L);
        verify(playerDAO, times(1)).save(any(Player.class));
    }

    @Test
    void testUpdatePlayer() {
        PlayerDTO playerDTO = new PlayerDTO(1L, "Jane Doe", "jdoe2", "jane.doe@example.com", 0, 0, null);

        when(playerDAO.findById(1L)).thenReturn(player);
        when(playerDAO.save(any(Player.class))).thenReturn(player);

        PlayerDTO result = playerService.updatePlayer(1L, playerDTO);

        assertNotNull(result);
        assertEquals("Jane Doe", result.getName());
        verify(playerDAO, times(1)).findById(1L);
        verify(playerDAO, times(1)).save(any(Player.class));
    }
}
