package com.example.playerservice;

import com.example.playerservice.Controller.PlayerController;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.DTO.PlayerScoreDTO;
import com.example.playerservice.DTO.newPlayerDTO;
import com.example.playerservice.Service.PlayerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PlayerController.class)
public class PlayerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PlayerService playerService;

    @Test
    void testAddPlayer() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO(1L, "John Doe", "jdoe", "john.doe@example.com", 1, 100, null);
        newPlayerDTO newPlayer = new newPlayerDTO("John Doe", "jdoe", "john.doe@example.com");

        when(playerService.addPlayer(any(newPlayerDTO.class))).thenReturn(playerDTO);

        mockMvc.perform(post("/players")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"John Doe\",\"pseudonym\":\"jdoe\",\"email\":\"john.doe@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.pseudonym").value("jdoe"));

        verify(playerService, times(1)).addPlayer(any(newPlayerDTO.class));
    }

    @Test
    void testGetPlayer() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO(1L, "John Doe", "jdoe", "john.doe@example.com", 1, 100, null);
        when(playerService.getPlayer(1L)).thenReturn(playerDTO);

        mockMvc.perform(get("/players/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("John Doe"));

        verify(playerService, times(1)).getPlayer(1L);
    }

    @Test
    void testListPlayers() throws Exception {
        PlayerDTO playerDTO = new PlayerDTO(1L, "John Doe", "jdoe", "john.doe@example.com", 1, 100, null);
        when(playerService.listPlayers()).thenReturn(List.of(playerDTO));

        mockMvc.perform(get("/players"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("John Doe"));

        verify(playerService, times(1)).listPlayers();
    }

    @Test
    void testUpdatePlayer() throws Exception {
        PlayerDTO updatedPlayer = new PlayerDTO(1L, "Jane Doe", "jdoe2", "jane.doe@example.com", 1, 100, null);
        when(playerService.updatePlayer(eq(1L), any(PlayerDTO.class))).thenReturn(updatedPlayer);

        mockMvc.perform(patch("/players/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Jane Doe\",\"pseudonym\":\"jdoe2\",\"email\":\"jane.doe@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Jane Doe"));

        verify(playerService, times(1)).updatePlayer(eq(1L), any(PlayerDTO.class));
    }

    @Test
    void testDeletePlayer() throws Exception {
        doNothing().when(playerService).deletePlayer(1L);

        mockMvc.perform(delete("/players/1"))
                .andExpect(status().isOk());

        verify(playerService, times(1)).deletePlayer(1L);
    }

    @Test
    void testUpdatePlayerScore() throws Exception {
        PlayerScoreDTO playerScoreDTO = new PlayerScoreDTO(100);
        when(playerService.updatePlayerScore(eq(1L), any(PlayerScoreDTO.class))).thenReturn(playerScoreDTO);

        mockMvc.perform(patch("/players/updatePlayerScore/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"playerscore\":100}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.playerscore").value(100));

        verify(playerService, times(1)).updatePlayerScore(eq(1L), any(PlayerScoreDTO.class));
    }
}
