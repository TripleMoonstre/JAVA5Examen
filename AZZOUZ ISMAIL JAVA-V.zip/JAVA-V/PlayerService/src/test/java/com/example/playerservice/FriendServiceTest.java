package com.example.playerservice;

import com.example.playerservice.DAO.FriendDAO;
import com.example.playerservice.DAO.PlayerDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.Entity.Friend;
import com.example.playerservice.Entity.Player;
import com.example.playerservice.Service.FriendService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FriendServiceTest {

    @Mock
    private PlayerDAO playerDAO;

    @Mock
    private FriendDAO friendDAO;

    @InjectMocks
    private FriendService friendService;

    private Player player;
    private Player friend;

    @BeforeEach
    void setUp() {
        player = new Player("John Doe", "jdoe", "john.doe@example.com");
        player.setId(1L);
        friend = new Player("Jane Smith", "jsmith", "jane.smith@example.com");
        friend.setId(2L);
    }

    @Test
    void testArePlayersFriends() {
        Friend friendship = new Friend(player, friend);
        List<Friend> friendsList = new ArrayList<>();
        friendsList.add(friendship);
        player.setFriends(friendsList);

        when(playerDAO.findById(1L)).thenReturn(player);

        boolean result = friendService.arePlayersFriends(1L, 2L);

        assertTrue(result);
        verify(playerDAO, times(1)).findById(1L);
    }

    @Test
    void testAddFriend() {
        when(playerDAO.findById(1L)).thenReturn(player);
        when(playerDAO.findById(2L)).thenReturn(friend);

        PlayerDTO result = friendService.addFriend(1L, 2L);

        assertNotNull(result);
        assertEquals(player.getName(), result.getName());

        // Vérifie que friendDAO.save() est appelé deux fois
        verify(friendDAO, times(2)).save(any(Friend.class));
    }

    @Test
    void testRemoveFriend() {
        when(playerDAO.findById(1L)).thenReturn(player);
        when(playerDAO.findById(2L)).thenReturn(friend);

        doNothing().when(friendDAO).removeFriend(1L, 2L);

        PlayerDTO result = friendService.removeFriend(1L, 2L);

        assertNotNull(result);
        assertEquals(player.getName(), result.getName());
        verify(friendDAO, times(1)).removeFriend(1L, 2L);
    }

    @Test
    void testGetPlayerFriendList() {
        Friend friendship = new Friend(player, friend);
        List<Friend> friendsList = new ArrayList<>();
        friendsList.add(friendship);
        player.setFriends(friendsList);

        when(playerDAO.findById(1L)).thenReturn(player);

        List<FriendDTO> result = friendService.getPlayerFriendList(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(friend.getName(), result.get(0).getName());
        verify(playerDAO, times(1)).findById(1L);
    }
}
