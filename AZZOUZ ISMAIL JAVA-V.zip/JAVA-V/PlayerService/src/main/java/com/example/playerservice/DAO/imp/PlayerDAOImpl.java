package com.example.playerservice.DAO.imp;

import com.example.playerservice.DAO.PlayerDAO;
import com.example.playerservice.Entity.Player;
import com.example.playerservice.Repository.PlayerRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

import lombok.AllArgsConstructor;
@AllArgsConstructor
@Repository
public class PlayerDAOImpl implements PlayerDAO {
    private final PlayerRepository playerRepository;

   

    @Override
    public Player findById(Long id) {
        return playerRepository.findById(id).orElseThrow();
    }

    @Override
    public List<Player> findAll() {
        return playerRepository.findAll();
    }

    @Override
    public Player save(Player player) {
        return playerRepository.save(player);
    }

    @Override
    public void deleteById(Long id) {
        playerRepository.deleteById(id);
    }
}
