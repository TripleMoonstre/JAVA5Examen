package com.example.playerservice.Entity;

import com.example.playerservice.DTO.FriendDTO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class Friend {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "player_id")
    @JsonIgnore
    private Player player;
    @ManyToOne
    @JoinColumn(name = "friend_id")
    private Player friend;
    public Friend(Player player, Player friend) {
        this.player = player;
        this.friend = friend;
    }
    @Override
    public String toString() {
        return "Friend{" +
                "id=" + id +
                ", player=" + player +
                ", friend=" + friend +
                '}';
    }
    public FriendDTO convertToDto(){
        return new FriendDTO(
                this.friend.getName(),
                this.friend.getEmail(),
                this.friend.getPseudonym(),
                this.friend.getLevel(),
                this.friend.getTotalPoints()
        );
    }
}
