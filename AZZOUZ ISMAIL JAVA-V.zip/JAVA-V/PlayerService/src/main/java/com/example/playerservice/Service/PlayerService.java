package com.example.playerservice.Service;

import com.example.playerservice.DAO.FriendDAO;
import com.example.playerservice.DAO.PlayerDAO;
import com.example.playerservice.DTO.*;
import com.example.playerservice.Entity.Player;
import com.example.playerservice.Service.GameApiService.GameRestClientService;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class PlayerService {
    private final PlayerDAO playerDAO;
    private final FriendDAO friendDAO;
    private final GameRestClientService gameRestClientService;

    public PlayerDTO addPlayer(newPlayerDTO newPlayerDTO) {
        if (newPlayerDTO == null) {
            throw new IllegalArgumentException("Player data cannot be null.");
        }
        if (newPlayerDTO.getName() == null || newPlayerDTO.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Player name cannot be null or empty.");
        }
        if (newPlayerDTO.getPseudonym() == null || newPlayerDTO.getPseudonym().trim().isEmpty()) {
            throw new IllegalArgumentException("Player pseudonym cannot be null or empty.");
        }
        if (newPlayerDTO.getEmail() == null || newPlayerDTO.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Player email cannot be null or empty.");
        }

        Player player = new Player(newPlayerDTO.getName(), newPlayerDTO.getPseudonym(), newPlayerDTO.getEmail());
        return playerDAO.save(player).convertToDto();
    }

    public PlayerDTO getPlayer(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }

        Player player = playerDAO.findById(id);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }


        return player.convertToDto();
    }

    public List<PlayerDTO> listPlayers() {
        List<Player> players = playerDAO.findAll();

        return players.stream()
                .map(Player::convertToDto).collect(Collectors.toList());
    }

    @Transactional
    public void deletePlayer(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }

        Player player = playerDAO.findById(id);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        friendDAO.deleteByPlayerId(id);
        playerDAO.deleteById(id);
        gameRestClientService.playerDataErazer(id);
    }

    @Transactional
    public PlayerDTO updatePlayer(Long id, PlayerDTO playerDTO) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }
        if (playerDTO == null) {
            throw new IllegalArgumentException("Player data cannot be null.");
        }

        Player player = playerDAO.findById(id);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        if (playerDTO.getName() != null && !playerDTO.getName().trim().isEmpty() && !playerDTO.getName().equals(player.getName())) {
            player.setName(playerDTO.getName());
        }
        if (playerDTO.getEmail() != null && !playerDTO.getEmail().trim().isEmpty() && !playerDTO.getEmail().equals(player.getEmail())) {
            player.setEmail(playerDTO.getEmail());
        }
        if (playerDTO.getPseudonym() != null && !playerDTO.getPseudonym().trim().isEmpty() && !playerDTO.getPseudonym().equals(player.getPseudonym())) {
            player.setPseudonym(playerDTO.getPseudonym());
        }

        return playerDAO.save(player).convertToDto();
    }

    public PlayerScoreDTO updatePlayerScore(Long playerId, PlayerScoreDTO playerScoreDTO) {
        if (playerId == null || playerId <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }
        if (playerScoreDTO == null) {
            throw new IllegalArgumentException("Score data cannot be null.");
        }
        if (playerScoreDTO.getPlayerscore() < 0) {
            throw new IllegalArgumentException("Score must be a non-negative value.");
        }

        Player player = playerDAO.findById(playerId);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        player.setTotalPoints(playerScoreDTO.getPlayerscore() + player.getTotalPoints());
        updatePlayerLevel(player);
        return new PlayerScoreDTO(player.getTotalPoints());
    }

    public void updatePlayerLevel(Player player) { //For when the leveling system will be added
        if (player.getTotalPoints() >= 1000) {
            player.setLevel(player.getLevel() + 1);
            player.setTotalPoints(0); // -> reset score to 0 or player will always levelUp
        }
        playerDAO.save(player);
    }

    public PlayerDTO updatePlayerPseudonym(Long id, UpdatePlayerPseudonymDTO updatePlayerPseudonymDTO) {
        Player player = playerDAO.findById(id);
        if (updatePlayerPseudonymDTO.getNewPseudonym().isBlank()) {
            throw new IllegalArgumentException("New pseudonym cannot be empty");
        }
        player.setPseudonym(updatePlayerPseudonymDTO.getNewPseudonym());
        playerDAO.save(player);

        return player.convertToDto();


    }

    public PlayerDTO updatePlayerEmail(Long id, UpdatedPlayerEmailDTO updatedPlayerEmailDTO) {
        Player player = playerDAO.findById(id);
        if (updatedPlayerEmailDTO.getNewemail().isBlank()) {
            throw new IllegalArgumentException("New email cannot be empty");
        }
        player.setEmail(updatedPlayerEmailDTO.getNewemail());
        playerDAO.save(player);

        return player.convertToDto();


    }

    public PlayerDTO updatePlayerName(Long id, UpdatePlayerNameDTO updatePlayerNameDTO) {
        Player player = playerDAO.findById(id);
        if (updatePlayerNameDTO.getNewName().isBlank()) {
            throw new IllegalArgumentException("New name cannot be empty");
        }
        player.setName(updatePlayerNameDTO.getNewName());
        playerDAO.save(player);

        return player.convertToDto();


    }
}
