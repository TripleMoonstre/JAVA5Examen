package com.example.playerservice.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdatePlayerNameDTO {
    @NotBlank(message = "New player name cannot be empty.")
    private String newName;
}
