package com.example.playerservice.DTO;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdatePlayerPseudonymDTO {
    @NotBlank(message = "New player pseudonym cannot be empty.")
    private String newPseudonym;
}
