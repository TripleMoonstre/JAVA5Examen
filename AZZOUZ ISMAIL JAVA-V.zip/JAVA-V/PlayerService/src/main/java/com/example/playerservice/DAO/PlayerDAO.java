    package com.example.playerservice.DAO;



    import com.example.playerservice.Entity.Player;
    import java.util.List;

    public interface PlayerDAO {
        Player findById(Long id);
        List<Player> findAll();
        Player save(Player player);
        void deleteById(Long id);
    }
