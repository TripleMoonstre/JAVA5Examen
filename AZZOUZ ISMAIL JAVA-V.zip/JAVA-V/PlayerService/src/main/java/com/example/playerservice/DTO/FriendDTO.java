package com.example.playerservice.DTO;
import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@Data
public class FriendDTO {
    private String name;
    private String email;
    private String pseudonym;
    private int level;
    private int totalPoints;
}
