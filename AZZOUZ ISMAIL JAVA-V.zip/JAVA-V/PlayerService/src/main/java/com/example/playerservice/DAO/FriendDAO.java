package com.example.playerservice.DAO;

import com.example.playerservice.Entity.Friend;
import java.util.List;

public interface FriendDAO {
    List<Friend> findByPlayerId(Long playerId);
    Friend save(Friend friend);
    void deleteByPlayerId(Long playerId);
    void removeFriend(Long playerId, Long friendId);
}

