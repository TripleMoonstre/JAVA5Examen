package com.example.playerservice.Controller;

import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.Entity.Player;
import com.example.playerservice.Service.FriendService;
import com.example.playerservice.Service.PlayerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
@AllArgsConstructor
@RestController
@RequestMapping("/friends")
public class FriendController {
    private final FriendService friendService;

    @PostMapping("/add/{playerId}/{friendId}")
    public PlayerDTO addFriend(@PathVariable Long playerId, @PathVariable Long friendId){
        return friendService.addFriend(playerId,friendId);
    }
    @GetMapping("/checkfriendship/{playerId}/{friendId}")
    public Boolean checkFriendShip(@PathVariable Long playerId, @PathVariable Long friendId){
        return friendService.arePlayersFriends(playerId,friendId);
    }
    @GetMapping("/friendslist/{playerId}")
    public List<FriendDTO> getFriendList(@PathVariable Long playerId){
        return friendService.getPlayerFriendList(playerId);
    }
    @PatchMapping("/endFriendShip/{playerId}/{friendId}")
    public PlayerDTO endFriendShip(@PathVariable Long playerId, @PathVariable Long friendId){
        return friendService.removeFriend(playerId,friendId);
    }

}
