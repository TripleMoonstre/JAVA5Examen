package com.example.playerservice.Controller;

import com.example.playerservice.DTO.*;
import com.example.playerservice.Service.PlayerService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/players")
public class PlayerController {
    private final PlayerService playerService;

    @PostMapping
    public PlayerDTO addPlayer(@RequestBody newPlayerDTO newplayer) {
        System.out.println("new player");
        System.out.println(newplayer);
        return playerService.addPlayer(newplayer);
    }

    @GetMapping("/{id}")
    public PlayerDTO getPlayer(@PathVariable Long id) {
        return playerService.getPlayer(id);
    }

    @GetMapping
    public List<PlayerDTO> listPlayers() {
        return playerService.listPlayers();
    }

    @PatchMapping("/{id}")
    public PlayerDTO updatePlayer(@PathVariable Long id, @RequestBody PlayerDTO playerDTO) {
        return playerService.updatePlayer(id, playerDTO);
    }

    @PatchMapping("updateplayerpseudonym/{id}")
    public PlayerDTO updatePlayerPseudo(@PathVariable Long id, @RequestBody UpdatePlayerPseudonymDTO updatePlayerPseudonymDTO) {
        return playerService.updatePlayerPseudonym(id, updatePlayerPseudonymDTO);
    }

    @PatchMapping("updateplayeremail/{id}")
    public PlayerDTO updatePlayerEmail(@PathVariable Long id, @RequestBody UpdatedPlayerEmailDTO updatedPlayerEmailDTO) {
        return playerService.updatePlayerEmail(id, updatedPlayerEmailDTO);
    }

    @PatchMapping("updateplayername/{id}")
    public PlayerDTO updatePlayerName(@PathVariable Long id, @RequestBody UpdatePlayerNameDTO updatePlayerNameDTO) {
        return playerService.updatePlayerName(id, updatePlayerNameDTO);
    }

    @DeleteMapping("/{id}")
    public void deletePlayer(@PathVariable Long id) {
        playerService.deletePlayer(id);

    }

    @PatchMapping("/updatePlayerScore/{playerId}")
    public PlayerScoreDTO updatePlayerScore(@PathVariable Long playerId, @RequestBody PlayerScoreDTO PlayerScoreDTO) {
        return playerService.updatePlayerScore(playerId, PlayerScoreDTO);
    }

}


