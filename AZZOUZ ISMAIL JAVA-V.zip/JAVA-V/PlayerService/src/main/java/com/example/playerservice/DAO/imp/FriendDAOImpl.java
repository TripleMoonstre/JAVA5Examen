package com.example.playerservice.DAO.imp;

import com.example.playerservice.DAO.FriendDAO;
import com.example.playerservice.Entity.Friend;
import com.example.playerservice.Repository.FriendRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import lombok.AllArgsConstructor;
@AllArgsConstructor
@Repository
public class FriendDAOImpl implements FriendDAO {
    private final FriendRepository friendRepository;



    @Override
    public List<Friend> findByPlayerId(Long playerId) {
        return friendRepository.findByPlayerId(playerId);
    }

    @Override
    public Friend save(Friend friend) {
        return friendRepository.save(friend);
    }

    @Override
    public void deleteByPlayerId(Long playerId) {
        friendRepository.deleteByFriendId(playerId); //supprimer si id dans friend id
        friendRepository.deleteByPlayerId(playerId); //supprimer si id dans player id
    }

    @Override
    public void removeFriend(Long playerId, Long friendId) {
        friendRepository.deleteByPlayerIdAndFriendId(playerId,friendId);
        friendRepository.deleteByPlayerIdAndFriendId(friendId,playerId);

    }
}
