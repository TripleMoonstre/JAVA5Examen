package com.example.playerservice.Repository;

import com.example.playerservice.Entity.Friend;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FriendRepository extends JpaRepository<Friend, Long> {
    void deleteByPlayerIdAndFriendId(Long playerId, Long friendId);
    void deleteByPlayerId(Long playerId);
    void deleteByFriendId(Long friendId);

     List<Friend> findByPlayerId(Long playerId);

    boolean existsByPlayerIdAndFriendId(Long playerId, Long friendId);

}
