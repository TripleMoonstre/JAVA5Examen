package com.example.playerservice.DTO;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdatedPlayerEmailDTO {
    @NotBlank(message = "Email cannot be empty.")
    @Email(message = "Email adress is not valid.")
    private String newemail;
}
