package com.example.playerservice.Entity;

import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Data
public class Player {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String pseudonym;
    private String email;
    private int level;
    private int totalPoints;
    @OneToMany(mappedBy = "player", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Friend> friends;

    public Player(String name, String pseudonym, String email) {

        this.name = name;
        this.pseudonym = pseudonym;
        this.email = email;
        this.level = 0;
        this.totalPoints = 0;
        this.friends = new ArrayList<>();
    }


    public Player() {
        this.level = 0;
        this.totalPoints = 0;
        this.friends = new ArrayList<>();

    }

    public PlayerDTO convertToDto() {
        return new PlayerDTO(this.getId(),
                this.getName(),
                this.getPseudonym(),
                this.getEmail(),
                this.getLevel(),
                this.getTotalPoints(),
                this.getFriends()
                        .stream()
                        .map(friend -> new FriendDTO(friend.getFriend().getName(),
                                friend.getFriend().getEmail(),
                                friend.getFriend().getPseudonym(),
                                friend.getFriend().getLevel(),
                                friend.getFriend().getTotalPoints())).collect(Collectors.toList())
        );
    }
}
