package com.example.playerservice.Service;

import com.example.playerservice.DAO.FriendDAO;
import com.example.playerservice.DAO.PlayerDAO;
import com.example.playerservice.DTO.FriendDTO;
import com.example.playerservice.DTO.PlayerDTO;
import com.example.playerservice.Entity.Friend;
import com.example.playerservice.Entity.Player;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class FriendService {
    private final PlayerDAO playerDAO;
    private final FriendDAO friendDAO;

    public boolean arePlayersFriends(Long playerId, Long friendId) {
        if (playerId == null || playerId <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }
        if (friendId == null || friendId <= 0) {
            throw new IllegalArgumentException("Friend ID must be a positive value.");
        }

        Player player = playerDAO.findById(playerId);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        List<Friend> playerFriendList = player.getFriends();
        return playerFriendList.stream()
                .anyMatch(friend -> friend.getFriend().getId().equals(friendId));
    }

    public PlayerDTO addFriend(Long playerId, Long friendId) {
        if (playerId == null || playerId <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }
        if (friendId == null || friendId <= 0) {
            throw new IllegalArgumentException("Friend ID must be a positive value.");
        }

        Player player = playerDAO.findById(playerId);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        Player friend = playerDAO.findById(friendId);
        if (friend == null) {
            throw new EntityNotFoundException("Friend not found.");
        }

        if (arePlayersFriends(playerId, friendId)) {
            throw new IllegalStateException("Players are already friends.");
        }

        friendDAO.save(new Friend(player, friend));
        friendDAO.save(new Friend(friend, player));

        return player.convertToDto();
    }

    @Transactional
    public PlayerDTO removeFriend(Long playerId, Long friendId) {
        if (playerId == null || playerId <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }
        if (friendId == null || friendId <= 0) {
            throw new IllegalArgumentException("Friend ID must be a positive value.");
        }

        Player player = playerDAO.findById(playerId);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        Player friend = playerDAO.findById(friendId);
        if (friend == null) {
            throw new EntityNotFoundException("Friend not found.");
        }

        friendDAO.removeFriend(playerId, friendId);
        friendDAO.removeFriend(friendId, playerId);

        return player.convertToDto();
    }

    public List<FriendDTO> getPlayerFriendList(Long playerId) {
        if (playerId == null || playerId <= 0) {
            throw new IllegalArgumentException("Player ID must be a positive value.");
        }

        Player player = playerDAO.findById(playerId);
        if (player == null) {
            throw new EntityNotFoundException("Player not found.");
        }

        return player.getFriends().stream()
                .map(Friend::convertToDto)
                .collect(Collectors.toList());
    }
}
