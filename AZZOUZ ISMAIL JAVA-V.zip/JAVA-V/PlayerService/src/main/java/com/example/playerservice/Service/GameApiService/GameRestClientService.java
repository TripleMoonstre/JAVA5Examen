package com.example.playerservice.Service.GameApiService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
@Service
public class GameRestClientService {
    @Autowired
    private RestTemplate restTemplate;
    private final String GAME_SERVICE_URL = "http://localhost:8888";
    public void playerDataErazer(Long playerId){
        String gameErazer_URL = GAME_SERVICE_URL + "/deleteAllPlayerGames/" + playerId;
        String participationsErazer_URL = GAME_SERVICE_URL + "/participation/" + playerId;
        try{
            restTemplate.delete(gameErazer_URL);
            restTemplate.delete(participationsErazer_URL);
        }catch (HttpClientErrorException e){
            throw new RuntimeException("Error while deleting player data from game and participation" + e.getMessage());
        }
    }
}
