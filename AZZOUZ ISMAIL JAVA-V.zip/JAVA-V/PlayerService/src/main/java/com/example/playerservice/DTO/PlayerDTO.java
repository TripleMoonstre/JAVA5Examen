package com.example.playerservice.DTO;

import lombok.Data;

import java.util.List;
import lombok.AllArgsConstructor;
@AllArgsConstructor
@Data
public class PlayerDTO {
    private Long id;
    private String name;
    private String pseudonym;
    private String email;
    private int level;
    private int totalPoints;
    private List<FriendDTO> friends;
}

