## Table of Contents

1. [Introduction](#introduction)

   - [Ports](#ports)

2. [PlayerController API Documentation](#playercontroller-api-documentation)

   - [Create a Player](#create-a-player)
   - [Retrieve a Player by ID](#retrieve-a-player-by-id)
   - [Update a Player](#update-a-player)
   - [Delete a Player](#delete-a-player)

3. [FriendController API Documentation](#friendcontroller-api-documentation)

   - [Add a Friend](#add-a-friend)
   - [Check Friendship](#check-friendship)
   - [Retrieve Friends List](#retrieve-friends-list)
   - [Remove a Friend](#remove-a-friend)

4. [GameController API Documentation](#gamecontroller-api-documentation)

   - [Create a Game](#create-a-game)
   - [Retrieve All Games](#retrieve-all-games)
   - [Retrieve a Specific Game by ID](#retrieve-a-specific-game-by-id)
   - [Retrieve All Games Hosted by a Specific Host](#retrieve-all-games-hosted-by-a-specific-host)
   - [Check if a Game is Finished](#check-if-a-game-is-finished)
   - [Mark a Game as Finished](#mark-a-game-as-finished)
   - [Delete a Game by ID](#delete-a-game-by-id)
   - [Delete All Games Hosted by a Specific Player](#delete-all-games-hosted-by-a-specific-player)
   - [Update the Maximum Score of a Game](#update-the-maximum-score-of-a-game)
   - [Update the Host of a Game](#update-the-host-of-a-game)

5. [ParticipationController API Documentation](#participationcontroller-api-documentation)

   - [Register a Participation](#register-a-participation)
   - [Update a Player's Score](#update-a-players-score)
   - [Update a Player's Victory Status](#update-a-players-victory-status)
   - [Retrieve All Participations of a Specific Player](#retrieve-all-participations-of-a-specific-player)
   - [Retrieve All Participations for a Specific Game](#retrieve-all-participations-for-a-specific-game)
   - [Delete a Participation for a Specific Player in a Specific Game](#delete-a-participation-for-a-specific-player-in-a-specific-game)
   - [Delete All Participations for a Specific Player](#delete-all-participations-for-a-specific-player)

6. [Business Logic](#business-logic)

7. [Database Schema](#database-schema)

   - [Database Choice](#database-choice)
   - [Microservices and Database Architecture](#microservices-and-database-architecture)
   - [SQL Script](#sql-script)

8. [Configuration](#configuration)

9. [Application Workflow](#application-workflow)

   - [Key Design Features](#key-design-features)

10. [Requirements](#requirements)
    - [Dependencies](#dependencies)
    - [Environment](#environment)
    - [Additional Notes](#additional-notes)

---

## 1. <a name='Introduction'></a>Introduction

This API suite supports a game management platform divided into two microservices:

1. **PlayerService**: Handles player creation, management, and friendships between players.
2. **GameService**: Manages games, participations, and scores.

Each service is independently deployed and interacts using REST APIs for scalability and modularity.

#### 1.1. <a name='Ports'></a>Ports

- PlayerService : `9999`
- GameService : `8888`

To modify these ports modify the line `server.port=8888` in `application.properties` for each services and modify the URL variables `PLAYER_SERVICE_URL` and `GAME_SERVICE_URL` in the both rest services `PlayerRestClientService.java (gameservice)` and `GameRestClientService.java (playerservice)`

---

### API Endpoints Recap

Below is a structured recap of the available API endpoints categorized by their respective controllers:

#### **PlayerController**

| **Action**              | **URL**                               | **Method** | **Description**                  |
| ----------------------- | ------------------------------------- | ---------- | -------------------------------- |
| Create a Player         | `/players`                            | POST       | Create a new player              |
| Retrieve a Player by ID | `/players/{id}`                       | GET        | Get details of a specific player |
| Update a Player         | `/players/{id}`                       | PATCH      | Update player details            |
| Update Player Pseudonym | `/players/updateplayerpseudonym/{id}` | PATCH      | Update a player's pseudonym      |
| Update Player Email     | `/players/updateplayeremail/{id}`     | PATCH      | Update a player's email          |
| Update Player Name      | `/players/updateplayername/{id}`      | PATCH      | Update a player's name           |
| Delete a Player         | `/players/{id}`                       | DELETE     | Delete a player by ID            |

---

#### **FriendController**

| **Action**            | **URL**                                          | **Method** | **Description**                      |
| --------------------- | ------------------------------------------------ | ---------- | ------------------------------------ |
| Add a Friend          | `/friends/add/{playerId}/{friendId}`             | POST       | Add a friend to a player's list      |
| Check Friendship      | `/friends/checkfriendship/{playerId}/{friendId}` | GET        | Check if two players are friends     |
| Retrieve Friends List | `/friends/friendslist/{playerId}`                | GET        | Get a list of a player's friends     |
| Remove a Friend       | `/friends/endFriendShip/{playerId}/{friendId}`   | PATCH      | Remove a friend from a player's list |

---

#### **GameController**

| **Action**                 | **URL**                                  | **Method** | **Description**                     |
| -------------------------- | ---------------------------------------- | ---------- | ----------------------------------- |
| Create a Game              | `/games/creategame`                      | POST       | Create a new game                   |
| Retrieve All Games         | `/games`                                 | GET        | Get a list of all games             |
| Retrieve a Game by ID      | `/games/{id}`                            | GET        | Get details of a specific game      |
| Retrieve All Games by Host | `/games/allplayergame/{hostId}`          | GET        | Get all games hosted by a player    |
| Check if Game is Finished  | `/games/isgamefinished/{gameId}`         | GET        | Check if a game is finished         |
| Mark a Game as Finished    | `/games/finishgame/{id}`                 | POST       | Mark a game as finished             |
| Delete a Game by ID        | `/games/deletegame/{id}`                 | DELETE     | Delete a specific game              |
| Delete All Games by Host   | `/games/deleteAllPlayerGames/{playerId}` | DELETE     | Delete all games hosted by a player |
| Update Game Max Score      | `/games/updategameMaxScore/{id}`         | PUT        | Update the maximum score of a game  |
| Update Game Host           | `/games/updateGameHost/{id}`             | PUT        | Change the host of a game           |

---

#### **ParticipationController**

| **Action**                                | **URL**                                            | **Method** | **Description**                           |
| ----------------------------------------- | -------------------------------------------------- | ---------- | ----------------------------------------- |
| Register a Participation                  | `/participation`                                   | POST       | Register a player in a game               |
| Update Player's Score                     | `/participation/setPlayerScore`                    | PATCH      | Update a player's score in a game         |
| Update Player's Victory Status            | `/participation/setPlayerWinner`                   | PATCH      | Mark a player as the winner               |
| Retrieve Player's Participations          | `/participation/getplayerparticipation/{playerId}` | GET        | Get all participations of a player        |
| Retrieve Game's Participations            | `/participation/getgameparticipation/{gameId}`     | GET        | Get all participations of a game          |
| Delete a Player's Participation in a Game | `/participation/{gameId}/{playerId}`               | DELETE     | Remove a player's participation in a game |
| Delete All Player's Participations        | `/participation/{playerId}`                        | DELETE     | Remove all participations of a player     |

---

### 1.1. <a name='PlayerControllerAPIDocumentation'></a>PlayerController API Documentation

The `PlayerController` provides a REST API for managing players. Below are the details of the available endpoints.

---

### 1.2. <a name='CreateaPlayer'></a>1. **Create a Player**

- **URL**: `/players`
- **Method**: POST
- **Request Body**:
  ```json
  {
    "name": "John Doe",
    "pseudonym": "jdoe",
    "email": "john.doe@example.com"
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John",
    "pseudonym": "test",
    "email": "tetete@tete.tetet",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

### 1.3. <a name='RetrieveaPlayerbyID'></a>2. **Retrieve a Player by ID**

- **URL**: `/players/{id}`
- **Method**: GET
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John",
    "pseudonym": "test",
    "email": "tetete@tete.tetet",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

### 1.4. <a name='UpdateaPlayer'></a>3. **Update a Player**

- **URL**: `/players/{id}`
- **Method**: PATCH
- **Request Body**:
  ```json
  {
    "name": "Jane Doe",
    "email": "jane.doe@example.com",
    "pseudonym": "newpseudo"
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "name": "Jane Doe",
    "pseudonym": "newpseudo",
    "email": "jane.doe@example.com",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

- **URL**: `/players/updateplayerpseudonym/{id}`
- **Method**: PATCH
- **Request Body**:
  ```json
  {
    "pseudonym": "newpseudo"
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John Doe",
    "pseudonym": "newpseudo",
    "email": "john.doe@example.com",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

- **URL**: `/players/updateplayeremail/{id}`
- **Method**: PATCH
- **Request Body**:
  ```json
  {
    "email": "new@email.ts"
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John Doe",
    "pseudonym": "newpseudo",
    "email": "new@email.ts",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

- **URL**: `/players/updateplayername/{id}`
- **Method**: PATCH
- **Request Body**:
  ```json
  {
    "newname": "newname"
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "name": "newname",
    "pseudonym": "johnpseudo",
    "email": "john.doe@example.com",
    "level": 0,
    "totalPoints": 0,
    "friends": []
  }
  ```

---

### 1.5. <a name='DeleteaPlayer'></a>4. **Delete a Player**

- **URL**: `/players/{id}`
- **Method**: DELETE

---

### 1.6. <a name='FriendControllerAPIDocumentation'></a>FriendController API Documentation

The `FriendController` provides a REST API for managing friendships between players. Below are the details of the available endpoints.

---

### 1.7. <a name='AddaFriend'></a>1. **Add a Friend**

- **URL**: `/friends/add/{playerId}/{friendId}`
- **Method**: POST
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John",
    "pseudonym": "johnpseudo",
    "email": "john.doe@example.com",
    "level": 0,
    "totalPoints": 0,
    "friends": [
      {
        "id": 2,
        "name": "Jane Smith",
        "pseudonym": "jsmith",
        "level": 1,
        "totalPoints": 555
      }
    ]
  }
  ```

---

### 1.8. <a name='CheckFriendship'></a>2. **Check Friendship**

- **URL**: `/friends/checkfriendship/{playerId}/{friendId}`
- **Method**: GET
- **Response**:
  ```json
  true OR false
  ```

---

### 1.9. <a name='RetrieveFriendsList'></a>3. **Retrieve Friends List**

- **URL**: `/friends/friendslist/{playerId}`
- **Method**: GET
- **Response**:
  ```json
  [
    {
      "id": 2,
      "name": "Jane Smith",
      "pseudonym": "jsmith",
      "level": 1,
      "totalPoints": 555
    },
    {
      "id": 3,
      "name": "Jane Smith",
      "pseudonym": "jsmith",
      "level": 1,
      "totalPoints": 555
    }
  ]
  ```

---

### 1.10. <a name='RemoveaFriend'></a>4. **Remove a Friend**

- **URL**: `/friends/endFriendShip/{playerId}/{friendId}`
- **Method**: PATCH
- **Response**:
  ```json
  {
    "id": 1,
    "name": "John",
    "pseudonym": "johnpseudo",
    "email": "john.doe@example.com",
    "level": 0,
    "totalPoints": 0,
    "friends": [
      {
        "id": 2,
        "name": "Jane Smith",
        "pseudonym": "jsmith",
        "level": 1,
        "totalPoints": 555
      }
    ]
  }
  ```

---

### 1.11. <a name='GameServiceEndpoints'></a>GameService Endpoints

### 1.12. <a name='GameControllerAPIDocumentation'></a>GameController API Documentation

The `GameController` provides a REST API for managing games. Below are the details of the available endpoints.

---

### 1.13. <a name='CreateaGame'></a>1. **Create a Game**

- **URL**: `/games/creategame`
- **Method**: POST
- **Parameters**:
  ```json
  {
    "gameType": "Chess",
    "maxScore": 100,
    "hostId": 1
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameType": "Chess",
    "maxScore": 100,
    "hostId": 1,
    "is_finished": false,
    "participations": []
  }
  ```

---

### 1.14. <a name='RetrieveAllGames'></a>2. **Retrieve All Games**

- **URL**: `/games`
- **Method**: GET
- **Response**:
  ```json
  [
    {
      "id": 1,
      "gameType": "Chess",
      "maxScore": 100,
      "hostId": 1,
      "is_finished": false,
      "participations": []
    }
  ]
  ```

---

### 1.15. <a name='RetrieveaSpecificGamebyID'></a>3. **Retrieve a Specific Game by ID**

- **URL**: `/games/{id}`
- **Method**: GET
- **Response**:
  ```json
  {
    "id": 1,
    "gameType": "Chess",
    "maxScore": 100,
    "hostId": 1,
    "is_finished": false,
    "participations": []
  }
  ```

---

### 1.16. <a name='RetrieveAllGamesHostedbyaSpecificHost'></a>4. **Retrieve All Games Hosted by a Specific Host**

- **URL**: `/games/allplayergame/{hostId}`
- **Method**: GET
- **Response**:
  ```json
  [
    {
      "id": 1,
      "gameType": "Chess",
      "maxScore": 100,
      "hostId": 1,
      "is_finished": false,
      "participations": []
    }
  ]
  ```

---

### 1.17. <a name='CheckifaGameisFinished'></a>5. **Check if a Game is Finished**

- **URL**: `/games/isgamefinished/{gameId}`
- **Method**: GET
- **Response**:
  ```json
  true OR false
  ```

---

### 1.18. <a name='MarkaGameasFinished'></a>6. **Mark a Game as Finished**

- **URL**: `/games/finishgame/{id}`
- **Method**: POST
- **Response**:
  ```json
  {
    "id": 1,
    "gameType": "Chess",
    "maxScore": 100,
    "hostId": 1,
    "is_finished": true,
    "participations": []
  }
  ```

---

### 1.19. <a name='DeleteaGamebyID'></a>7. **Delete a Game by ID**

- **URL**: `/games/deletegame/{id}`
- **Method**: DELETE
- **Response**:

  ```json

  ```

---

### 1.20. <a name='DeleteAllGamesHostedbyaSpecificPlayer'></a>8. **Delete All Games Hosted by a Specific Player**

- **URL**: `/games/deleteAllPlayerGames/{playerId}`
- **Method**: DELETE
- **Response**:

  ```json

  ```

---

### 1.21. <a name='UpdatetheMaximumScoreofaGame'></a>9. **Update the Maximum Score of a Game**

- **URL**: `/games/updategameMaxScore/{id}`
- **Method**: PUT
- **Parameters**:
  ```json
  {
    "newMaxScore": 200
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameType": "Chess",
    "maxScore": 200,
    "hostId": 1,
    "is_finished": false,
    "participations": []
  }
  ```

---

### 1.22. <a name='UpdatetheHostofaGame'></a>10. **Update the Host of a Game**

- **URL**: `/games/updateGameHost/{id}`
- **Method**: PUT
- **Parameters**:
  ```json
  {
    "newHostId": 2
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameType": "Chess",
    "maxScore": 100,
    "hostId": 2,
    "is_finished": false,
    "participations": []
  }
  ```

### 1.23. <a name='ParticipationControllerAPIDocumentation'></a>ParticipationController API Documentation

The `ParticipationController` provides a REST API for managing participations in games. Below are the details of the available endpoints.

---

### 1.24. <a name='RegisteraParticipation'></a>1. **Register a Participation**

- **URL**: `/participation`
- **Method**: POST
- **Parameters**:
  ```json
  {
    "gameId": 1,
    "playerId": 1,
    "score": 50
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameId": 1,
    "playerId": 1,
    "score": 50,
    "victory": false
  }
  ```

---

### 1.25. <a name='UpdateaPlayersScore'></a>2. **Update a Player's Score**

- **URL**: `/participation/setPlayerScore`
- **Method**: PATCH
- **Parameters**:
  ```json
  {
    "gameId": 1,
    "playerId": 1,
    "score": 75
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameId": 1,
    "playerId": 1,
    "score": 75,
    "victory": false
  }
  ```

---

### 1.26. <a name='UpdateaPlayersVictoryStatus'></a>3. **Update a Player's Victory Status**

- **URL**: `/participation/setPlayerWinner`
- **Method**: PATCH
- **Parameters**:
  ```json
  {
    "gameId": 1,
    "playerId": 1
  }
  ```
- **Response**:
  ```json
  {
    "id": 1,
    "gameId": 1,
    "playerId": 1,
    "score": 75,
    "victory": true
  }
  ```

---

### 1.27. <a name='RetrieveAllParticipationsofaSpecificPlayer'></a>4. **Retrieve All Participations of a Specific Player**

- **URL**: `/participation/getplayerparticipation/{playerId}`
- **Method**: GET
- **Response**:
  ```json
  [
    {
      "id": 1,
      "gameId": 1,
      "playerId": 1,
      "score": 75,
      "victory": false
    },
    {
      "id": 2,
      "gameId": 3,
      "playerId": 1,
      "score": 750,
      "victory": true
    }
  ]
  ```

---

### 1.28. <a name='RetrieveAllParticipationsforaSpecificGame'></a>5. **Retrieve All Participations for a Specific Game**

- **URL**: `/participation/getgameparticipation/{gameId}`
- **Method**: GET
- **Response**:
  ```json
  [
    {
      "id": 1,
      "gameId": 1,
      "playerId": 1,
      "score": 75,
      "victory": false
    },
    {
      "id": 5,
      "gameId": 1,
      "playerId": 3,
      "score": 5,
      "victory": true
    }
  ]
  ```

---

### 1.29. <a name='DeleteaParticipationforaSpecificPlayerinaSpecificGame'></a>6. **Delete a Participation for a Specific Player in a Specific Game**

- **URL**: `/participation/{gameId}/{playerId}`
- **Method**: DELETE
- **Response**:

  ```json

  ```

---

### 1.30. <a name='DeleteAllParticipationsforaSpecificPlayer'></a>7. **Delete All Participations for a Specific Player**

- **URL**: `/participation/{playerId}`
- **Method**: DELETE
- **Response**:

  ```json

  ```

---

## 2. <a name='BusinessLogic'></a>Business Logic

The application operates on two main axes:

- **Player Management**: Supports creating, modifying, and deleting players, as well as managing their friendships.
- **Game Management**: Encompasses creating games, recording participations, and tracking scores.

Each service is designed to be independent, enabling scalability and simplified maintenance.

---

## 3. <a name='DatabaseSchema'></a>Database Schema

![Database Schema](./DATABASESCHEMA.jpeg)

### 3.1. <a name='DatabaseChoice'></a>Database Choice

We selected **PostgreSQL** as our database due to its robust support for relational data, scalability, and rich feature set. PostgreSQL ensures ACID compliance and offers advanced data types, making it an ideal choice for our application needs.

### 3.2. <a name='MicroservicesandDatabaseArchitecture'></a>Microservices and Database Architecture

Both microservices, `PlayerService` and `GameService`, currently share the same database schema. This design simplifies data management and reduces complexity during development.

However, the architecture is flexible and allows each microservice to operate with its own database if needed. By isolating the services and their data, we can achieve:

1. **Improved Scalability**: Each service can scale independently based on its specific load.
2. **Enhanced Fault Tolerance**: Issues in one service's database will not impact the other.
3. **Data Isolation**: Prevents unintended cross-service data dependencies.

Transitioning to separate databases requires minimal refactoring, as the services are already designed with clear boundaries and communication through REST APIs.

### 3.3. <a name='SQLScript'></a>SQL Script

```sql
CREATE DATABASE java_V_database;
\c java_V_database;

CREATE TABLE players (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    pseudonym VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    level INT NOT NULL,
    total_points INT NOT NULL,

);

CREATE TABLE games (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    date date NOT NULL,
    game_type VARCHAR(255) NOT NULL,
    max_score INT NOT NULL,
    host_id BIGINT NOT NULL,
    is_finished BOOLEAN DEFAULT FALSE
);

CREATE TABLE friends (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    player_id BIGINT NOT NULL,
    friend_id BIGINT NOT NULL,
    FOREIGN KEY (player_id) REFERENCES players(id),
    FOREIGN KEY (friend_id) REFERENCES players(id)
);

CREATE TABLE participations (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    game_id BIGINT NOT NULL,
    player_id BIGINT NOT NULL,
    score INT NOT NULL,
    victory BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (game_id) REFERENCES games(id),
    FOREIGN KEY (player_id) REFERENCES players(id)
);
```

## 4. <a name='Configuration'></a>Configuration

- Ensure that the database name matches the one configured in the `application.properties` file for each service.
- Example configuration for PostgreSQL:
  ```properties
  spring.datasource.url=jdbc:postgresql://localhost:5432/java_V_database
  spring.datasource.username=your_username
  spring.datasource.password=your_password
  ```

---

## 5. <a name='ApplicationWorkflow'></a>Application Workflow

1. **Player Creation:**

   - The user sends a POST request to `/players` with the player's details.
   - The `PlayerService` validates the input and stores the player in the database.

2. **Game Creation:**

   - The user sends a POST request to `/games/creategame`.
   - The `GameService` verifies the host exists through the `PlayerRestClientService` before creating the game entry.

3. **Game Participation:**

   - The user registers a participation via a POST request to `/participation`.
   - The `ParticipationService` validates both the player and the game before recording the participation.

4. **Score Updates:**

   - A PATCH request to `/participation/setPlayerScore` updates a player's score for a specific game.

5. **Data Deletion:**

   - Games and participations can be deleted using their respective endpoints.

### 5.1. <a name='KeyDesignFeatures'></a>Key Design Features

- Each interaction between services relies on secure REST API calls and robust error handling.
- This ensures reliable communication and provides a foundation for future scalability and extensibility.

## 6. <a name='Requirements'></a>Requirements

### 6.1. <a name='Dependencies'></a>Dependencies

The project includes the following dependencies:

- **Spring Boot Starter Web**: Provides core web development features.

  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-web</artifactId>
  </dependency>
  ```

- **Spring Boot Starter JPA**: For database interactions using JPA.

  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-jpa</artifactId>
  </dependency>
  ```

- **PostgreSQL Driver**: Database driver for PostgreSQL.

  ```xml
  <dependency>
      <groupId>org.postgresql</groupId>
      <artifactId>postgresql</artifactId>
      <version>42.6.0</version>
  </dependency>
  ```

- **Spring Boot Starter Validation**: For request validation.

  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-validation</artifactId>
  </dependency>
  ```

- **Lombok**: Simplifies Java code with annotations (e.g., for getters, setters).

  ```xml
  <dependency>
      <groupId>org.projectlombok</groupId>
      <artifactId>lombok</artifactId>
      <scope>provided</scope>
  </dependency>
  ```

- **Hibernate Types**: Enhances Hibernate capabilities, such as JSONB and ARRAY support.

  ```xml
  <dependency>
      <groupId>com.vladmihalcea</groupId>
      <artifactId>hibernate-types-60</artifactId>
      <version>2.21.1</version>
  </dependency>
  ```

- **Spring Boot DevTools** (Optional): For live reload during development.

  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-devtools</artifactId>
      <scope>runtime</scope>
      <optional>true</optional>
  </dependency>
  ```

- **Spring Boot Starter Test**: Testing utilities and frameworks.

  ```xml
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
      <exclusions>
          <exclusion>
              <groupId>org.junit.vintage</groupId>
              <artifactId>junit-vintage-engine</artifactId>
          </exclusion>
      </exclusions>
  </dependency>
  ```

- **JUnit Jupiter (JUnit 5)**: For unit testing.
  ```xml
  <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <scope>test</scope>
  </dependency>
  ```

### 6.2. <a name='Environment'></a>Environment

- **Java Version**: Java 17
- **Testing Framework**: Uses JUnit 5 and Mocking utilities (e.g., Mockito).

### 6.3. <a name='AdditionalNotes'></a>Additional Notes

- Dependencies are managed in the `pom.xml` file for Maven.
- Ensure proper configuration of PostgreSQL credentials in the `application.properties` file to connect the database seamlessly.
- Development and testing tools such as Lombok and Spring DevTools can be optionally included to enhance the developer experience.
